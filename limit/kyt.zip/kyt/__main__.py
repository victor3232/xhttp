from kyt import *
from importlib import import_module
from kyt.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("kyt.modules." + module_name)

# ---- VPN STORE: background cek deposit otomatis ----
import asyncio


async def _store_poll_loop():
    from kyt.modules.deposit import cek_semua_pending
    while True:
        await asyncio.sleep(45)
        try:
            await cek_semua_pending()
        except Exception as e:
            logging.error("store poller: %s", e)


try:
    bot.loop.create_task(_store_poll_loop())
except Exception as e:
    logging.error("gagal start store poller: %s", e)

bot.run_until_disconnected()
