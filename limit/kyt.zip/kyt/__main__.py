from kyt import *
from importlib import import_module
from kyt.modules import ALL_MODULES
for module_name in ALL_MODULES:
        imported_module = import_module("kyt.modules." + module_name)

# ---- pasang handler tanya() SETELAH semua modul dimuat ----
# (supaya handler ini yang terakhir, tidak menyerobot handler menu)
try:
	from kyt import pasang_handler_tanya
	pasang_handler_tanya()
except Exception as e:
	logging.error("gagal pasang handler tanya: %s", e)

# ---- VPN STORE: background cek deposit otomatis ----
import asyncio


async def _store_poll_loop():
    from kyt.modules.deposit import cek_semua_pending
    while True:
        await asyncio.sleep(20)
        try:
            await cek_semua_pending()
        except Exception as e:
            logging.error("store poller: %s", e)


async def _notif_expired_loop():
    """Ingatkan pelanggan kalau akunnya mau habis / sudah habis."""
    from kyt.modules.notif import cek_expired
    await asyncio.sleep(60)
    while True:
        try:
            await cek_expired()
        except Exception as e:
            logging.error("notif expired: %s", e)
        await asyncio.sleep(600)


async def _backup_db_loop():
    """Backup database bot otomatis 1x per hari ke /root/backup."""
    from kyt.modules.backup import backup_db_harian
    await asyncio.sleep(120)
    while True:
        try:
            await asyncio.to_thread(backup_db_harian)
        except Exception as e:
            logging.error("backup db: %s", e)
        await asyncio.sleep(6 * 3600)


async def _connection_notif_loop():
    """Pantau perubahan koneksi SSH dan Xray untuk notifikasi admin."""
    from kyt.modules.conn_notif import cek_perubahan_koneksi
    await asyncio.sleep(20)
    while True:
        try:
            await cek_perubahan_koneksi()
        except Exception as e:
            logging.error("monitor koneksi: %s", e)
        await asyncio.sleep(5)

async def _node_health_loop():
    """Cek status semua server (multi-node) tiap 60 detik."""
    from kyt import node_lib as N
    await asyncio.sleep(20)
    while True:
        try:
            await asyncio.to_thread(N.check_all, 8)
        except Exception as e:
            logging.error("health node: %s", e)
        await asyncio.sleep(60)


try:
    bot.loop.create_task(_store_poll_loop())
except Exception as e:
    logging.error("gagal start store poller: %s", e)

try:
    bot.loop.create_task(_notif_expired_loop())
except Exception as e:
    logging.error("gagal start notif expired: %s", e)

try:
    bot.loop.create_task(_backup_db_loop())
except Exception as e:
    logging.error("gagal start backup db: %s", e)

try:
    bot.loop.create_task(_connection_notif_loop())
except Exception as e:
    logging.error("gagal start monitor koneksi: %s", e)

try:
    bot.loop.create_task(_node_health_loop())
except Exception as e:
    logging.error("gagal start health node: %s", e)

bot.run_until_disconnected()
