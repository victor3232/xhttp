from kyt import *
from kyt import store_lib as S

# ============================================================
#  RENEW XRAY (VMess / VLESS / Trojan / Shadowsocks)
#  Admin pilih nomor akun, bukan mengetik username.
# ============================================================

PROTO = {
    "vmess": {"label": "VMESS", "quota": True},
    "vless": {"label": "VLESS", "quota": True},
    "trojan": {"label": "TROJAN", "quota": True},
    "ss": {"label": "SHADOWSOCKS", "quota": False},
}


def _angka_atau(v, lama, nama, maks):
    """Kosong / '-' = tetap. Angka = nilai baru. Return (ok, nilai)."""
    t = (v or "").strip().replace(".", "").replace(",", "")
    if t in ("", "-"):
        return True, int(lama or 0)
    if not t.isdigit():
        return False, nama
    n = int(t)
    if n < 0 or n > maks:
        return False, nama
    return True, n


async def _renew(event, tipe):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    cfg = PROTO[tipe]
    label = cfg["label"]
    chat = event.chat_id
    sender = await event.get_sender()
    uid = sender.id

    daftar = S.daftar_xray_renew(tipe)
    if not daftar:
        await balas(event, "📋 Belum ada akun %s yang bisa direnew." % label,
                    buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        return

    baris = []
    for i, (akun, exp, quota, iplim) in enumerate(daftar, 1):
        q = ("%dGB" % quota) if quota else "Unli"
        ip = str(iplim) if iplim else "Unli"
        baris.append("%3d. %-18s %-10s Q:%-6s IP:%s"
                     % (i, akun, exp or "-", q, ip))
    await balas(event, "**PILIH AKUN %s**\n```\n%s\n```"
                % (label, "\n".join(baris)))

    nomor = await tanya_admin(event, "**Nomor akun yang mau direnew:**", chat, uid)
    if not nomor:
        return
    nomor = nomor.strip()
    if not nomor.isdigit() or not (1 <= int(nomor) <= len(daftar)):
        await balas(event, "❌ Nomor tidak valid. Pilih nomor 1 - %d." % len(daftar),
                    buttons=[[Button.inline(" RENEW %s " % label, "renew-" + tipe)]])
        return

    akun, exp_lama, quota_lama, ip_lama = daftar[int(nomor) - 1]

    hari = await hari_admin(event, chat, "**Tambah masa aktif %s**" % label)
    if not hari:
        return

    quota = int(quota_lama or 0)
    ip_limit = int(ip_lama or 0)
    if cfg["quota"]:
        q_txt = await tanya_admin(
            event,
            "**Quota (GB)** — kosong / `-` = tetap `%s`, `0` = unlimited:"
            % quota_lama,
            chat, uid)
        if q_txt is None:
            return
        ok_q, quota = _angka_atau(q_txt, quota_lama, "Quota", 10000)
        if not ok_q:
            await event.respond("❌ Quota harus angka 0 - 10000.")
            return

        ip_txt = await tanya_admin(
            event,
            "**Limit IP** — kosong / `-` = tetap `%s`, `0` = unlimited:"
            % ip_lama,
            chat, uid)
        if ip_txt is None:
            return
        ok_i, ip_limit = _angka_atau(ip_txt, ip_lama, "Limit IP", 100)
        if not ok_i:
            await event.respond("❌ Limit IP harus angka 0 - 100.")
            return

    try:
        sisa = (DT.datetime.strptime(exp_lama, "%Y-%m-%d").date()
                - DT.date.today()).days
    except Exception:
        sisa = 0

    await event.respond("`Memproses renew %s... mohon tunggu`" % label)
    ok, out, exp_baru = await asyncio.to_thread(
        S.renew_akun, tipe, akun, "", hari, sisa, quota, ip_limit)

    if not ok:
        await balas(event, "❌ **Gagal renew %s**\n```\n%s\n```"
                    % (label, (out or "")[-800:]),
                    buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
        return

    exp_tampil = exp_baru or S.baca_expired_panel(tipe, akun) or "-"
    if cfg["quota"]:
        info_quota = ("%d GB" % quota) if quota > 0 else "Unlimited"
        info_ip = ("%d IP" % ip_limit) if ip_limit > 0 else "Unlimited"
        tambahan = ("Quota      : %s\n"
                    "Limit IP   : %s\n" % (info_quota, info_ip))
    else:
        tambahan = "Quota/IP   : tidak diubah (reset pemakaian)\n"

    msg = ("✅ **%s BERHASIL DIRENEW**\n"
           "```\n"
           "User       : %s\n"
           "Expired    : %s\n"
           "Ditambah   : %d hari\n"
           "Expired baru: %s\n"
           "%s"
           "```" % (label, akun, exp_lama or "-", hari, exp_tampil, tambahan))
    await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def renew_vmess(event):
    await _renew(event, "vmess")


@bot.on(events.CallbackQuery(data=b'renew-vless'))
async def renew_vless(event):
    await _renew(event, "vless")


@bot.on(events.CallbackQuery(data=b'renew-trojan'))
async def renew_trojan(event):
    await _renew(event, "trojan")


@bot.on(events.CallbackQuery(data=b'renew-ss'))
async def renew_ss(event):
    await _renew(event, "ss")
