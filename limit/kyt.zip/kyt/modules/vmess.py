from kyt import *
from kyt import store_lib as S

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 HARI ","3"),
Button.inline(" 7 HARI ","7")],
[Button.inline(" 30 HARI ","30")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("`Memproses... mohon tunggu`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			linkku = "\n".join(S.link_berlabel(S.ambil_link(a, berlabel=False)))
			msg = f"""
**VMESS ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {z["ps"]}
Domain        : {z["add"]}
Xray DNS      : {HOST}
Quota         : {pw} GB
Expired       : {later}
━━━━━━━━━━━━━━━━━━━━━━━
UUID          : {z["id"]}
AlterId       : 0
Security      : auto
Network       : WS / gRPC
Path WS       : /vmess
Path gRPC     : vmess-grpc
Path Dynamic  : http://BUG.COM
Port TLS      : 222-1000
Port NTLS     : 80, 8080, 8081-9999
Port gRPC     : 443
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
OpenClash     : https://{DOMAIN}:81/vmess-{user}.txt
━━━━━━━━━━━━━━━━━━━━━━━
```
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("`Memproses... mohon tunggu`")
		cmd = f'printf "%s\n" "{exp}" | trialws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			b = [x.group() for x in re.finditer("vmess://(.*)",a)]
			print(b)
			linkku = "\n".join(S.link_berlabel(S.ambil_link(a, berlabel=False)))
			z = base64.b64decode(b[0].replace("vmess://","")).decode("ascii")
			z = json.loads(z)
			z1 = base64.b64decode(b[1].replace("vmess://","")).decode("ascii")
			z1 = json.loads(z1)
			msg = f"""
**VMESS ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {z["ps"]}
Domain        : {z["add"]}
Xray DNS      : {HOST}
Quota         : Unlimited
Expired       : {exp} Minutes
━━━━━━━━━━━━━━━━━━━━━━━
UUID          : {z["id"]}
AlterId       : 0
Security      : auto
Network       : WS / gRPC
Path WS       : /vmess
Path gRPC     : vmess-grpc
Path Dynamic  : http://BUG.COM
Port TLS      : 222-1000
Port NTLS     : 80, 8080, 8081-9999
Port gRPC     : 443
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
OpenClash     : https://{DOMAIN}:81/vmess-{z["ps"]}.txt
━━━━━━━━━━━━━━━━━━━━━━━
```
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK VMESS
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Vmess**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | delws'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" TRIAL VMESS ","trial-vmess"),
Button.inline(" CREATE VMESS ","create-vmess")],
[Button.inline(" CHECK VMESS ","cek-vmess"),
Button.inline(" DELETE VMESS ","delete-vmess")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**VMESS MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `VMESS`
Hostname/IP : `{DOMAIN}`
ISP         : `{z["isp"]}`
Country     : `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)