from kyt import *
from kyt import store_lib as S


# ============================================================
#  CREATE VMESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return

	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	ok_u, msg_u = cek_username(user)
	if not ok_u:
		await event.respond("❌ %s" % msg_u)
		return

	quota = await tanya_admin(event, "**Quota (GB)** — isi `0` untuk unlimited:", chat, uid)
	if quota is None:
		return
	quota = quota.strip().replace(".", "").replace(",", "")
	if not quota.isdigit():
		await event.respond("❌ Harus angka.")
		return

	exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
	if not exp:
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "addws",
	                                  [user, exp, quota, "0"],
	                                  45, lambda: S._akun_ada("vmess", user))
	if not ok or not S._akun_ada("vmess", user):
		await balas(event, "❌ **Gagal membuat akun VMess.**\n\n```\n%s\n```"
		            % (out or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	later = DT.date.today() + DT.timedelta(days=int(exp))
	b = [x.group() for x in re.finditer("vmess://(.*)", out)]
	z = {}
	try:
		z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))
	except Exception:
		pass
	linkku = "\n".join(S.link_berlabel(S.ambil_link(out, berlabel=False)))
	msg = f"""**VMESS ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {z.get("ps", user)}
Domain        : {z.get("add", DOMAIN)}
Xray DNS      : {HOST}
Quota         : {quota} GB
Expired       : {later.strftime("%d %b %Y")}
━━━━━━━━━━━━━━━━━━━━━━━
UUID          : {z.get("id", "-")}
AlterId       : 0
Security      : auto
Network       : WS / gRPC / HTTPUpgrade / XHTTP / TCP
Path WS       : /vmess
Path gRPC     : vmess-grpc
Port TLS      : 222-1000
Port NTLS     : 80, 8080, 8081-9999
Port gRPC     : 443
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
OpenClash     : https://{DOMAIN}:81/vmess-{user}.txt
━━━━━━━━━━━━━━━━━━━━━━━
```"""
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  TRIAL VMESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	menit = await tombol_admin(event, "**Pilih Masa Trial**", [
		[Button.inline("10 Menit", "10"), Button.inline("15 Menit", "15")],
		[Button.inline("30 Menit", "30"), Button.inline("60 Menit", "60")]],
		chat)
	if menit not in ("10", "15", "30", "60"):
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "trialws", [menit], 40)
	if not ok:
		await balas(event, "❌ **Gagal membuat trial.**\n```\n%s\n```" % (out or "")[-400:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	b = [x.group() for x in re.finditer("vmess://(.*)", out)]
	z = {}
	try:
		z = json.loads(base64.b64decode(b[0].replace("vmess://", "")).decode("ascii"))
	except Exception:
		pass
	linkku = "\n".join(S.link_berlabel(S.ambil_link(out, berlabel=False)))
	msg = f"""**VMESS TRIAL**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {z.get("ps", "-")}
Domain        : {z.get("add", DOMAIN)}
Quota         : Unlimited
Expired       : {menit} Menit
━━━━━━━━━━━━━━━━━━━━━━━
UUID          : {z.get("id", "-")}
Network       : WS / gRPC / HTTPUpgrade / XHTTP / TCP
Port TLS      : 222-1000
Port NTLS     : 80, 8080, 8081-9999
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
```"""
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  CEK LOGIN VMESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'cek-vmess'))
async def cek_vmess(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-cek-ws", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  HAPUS VMESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	user = await tanya_admin(event, "**Username yang mau dihapus:**", chat, sender.id)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("vmess", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	S._hapus_akun("vmess", user)
	await balas(event, "✅ Akun VMess `%s` sudah dihapus." % user,
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  MENU VMESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	inline = [
		[Button.inline(" TRIAL VMESS ", "trial-vmess"),
		 Button.inline(" CREATE VMESS ", "create-vmess")],
		[Button.inline(" CHECK VMESS ", "cek-vmess"),
		 Button.inline(" DELETE VMESS ", "delete-vmess")],
		[Button.inline("‹ Main Menu ›", "menu")]]
	try:
		z = requests.get("http://ip-api.com/json/?fields=country,isp",
		                 timeout=10).json()
	except Exception:
		z = {"isp": "-", "country": "-"}
	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**VMESS MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `VMESS`
Hostname/IP : `{DOMAIN}`
ISP         : `{z.get("isp", "-")}`
Country     : `{z.get("country", "-")}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send(event, msg, inline)
