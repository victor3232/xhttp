from kyt import *
from kyt import store_lib as S

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline("PANEL CREATE ACCOUNT","menu")],
[Button.url("TELEGRAM GROUP","https://t.me/myridtunnel"),
Button.url("ORDER SCRIPT","https://t.me/kytxz")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val != "true":
		# pelanggan (non-admin) -> menu STORE
		from kyt.modules.store import kirim_menu_store
		await kirim_menu_store(event, foto=True)
		return
	namaos = sh_out(" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").strip().replace('"', '')
	ipsaya = sh_out(" curl -s ipv4.icanhazip.com").strip()
	city = sh_out(" cat /etc/xray/city").strip()
	# DOMAIN dari var.txt; kalau kosong ambil dari berkas panel (/etc/xray/domain)
	dom = S.cfg("DOMAIN", "") or "-"

	# Jumlah akun: SATU sumber kebenaran — sinkron dgn server
	jml = await asyncio.to_thread(S.jumlah_akun)
	ssh = jml.get("ssh", 0); vms = jml.get("vmess", 0)
	vls = jml.get("vless", 0);  trj = jml.get("trojan", 0)
	ss  = jml.get("ss", 0);     l2t = jml.get("l2tp", 0)
	total = ssh + vms + vls + trj + ss + l2t

	# CATATAN: jangan menaruh `code` DI DALAM **bold** — Telegram menolak
	# nested formatting dan seluruh pesan jadi plain (tanda ** ` muncul mentah).
	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**PREMIUM PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━
OS       : `{namaos}`
City     : `{city}`
Domain   : `{dom}`
IP VPS   : `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━
SSH/OVPN    : **{ssh}**
VMess       : **{vms}**
VLESS       : **{vls}**
Trojan      : **{trj}**
Shadowsocks : **{ss}**
L2TP/IKEv2  : **{l2t}**
━━━━━━━━━━━━━━━━━━━━━━━
Total Akun : **{total}**
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send_photo(event, S.gambar_start(), msg, inline)
