from kyt import *
from kyt import store_lib as S

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline("PANEL CREATE ACCOUNT","menu")],
[Button.url("TELEGRAM GROUP","https://t.me/myridtunnel"),
Button.url("ORDER SCRIPT","https://t.me/kytxz")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val != "true":
		# pelanggan (non-admin) -> menu STORE
		from kyt.modules.store import kirim_menu_store
		await kirim_menu_store(event, foto=True)
		return
	ssh = sh_out(' cat /etc/ssh/.ssh.db | grep "###" | wc -l').strip() or "0"
	vms = sh_out(' cat /etc/vmess/.vmess.db | grep "###" | wc -l').strip() or "0"
	vls = sh_out(' cat /etc/vless/.vless.db | grep "###" | wc -l').strip() or "0"
	trj = sh_out(' cat /etc/trojan/.trojan.db | grep "###" | wc -l').strip() or "0"
	namaos = sh_out(" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").strip().replace('"', '')
	ipsaya = sh_out(" curl -s ipv4.icanhazip.com").strip()
	city = sh_out(" cat /etc/xray/city").strip()

	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**PREMIUM PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━
OS       : `{namaos}`
City     : `{city}`
Domain   : `{DOMAIN}`
IP VPS   : `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━
Akun     : SSH `{ssh}` | VMess `{vms}` | VLESS `{vls}` | Trojan `{trj}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send_photo(event, S.gambar_start(), msg, inline)
