# -*- coding: utf-8 -*-
# ============================================================
#  modules/l2tp.py - L2TP / IKEv2 MANAGER (admin)
#    Sebelumnya L2TP HANYA bisa dibeli buyer dari store;
#    admin TIDAK punya menu untuk membuat akun L2TP manual.
#    Modul ini melengkapinya:
#      - CREATE L2TP   (username + password + masa aktif)
#      - VIEW  L2TP    (daftar akun + sisa hari)
#      - DELETE L2TP   (dengan konfirmasi)
#      - RENEW L2TP    (tambah masa aktif)
#    Akun dibuat LANGSUNG oleh bot (S.buat_l2tp), bukan lewat
#    script panel "add-l2tp" yang menggantung / loop tanpa henti.
# ============================================================
from kyt import *
from kyt import store_lib as S


def cek_password_l2tp(teks):
    """Validasi password L2TP.

    Dipakai sebagai `validasi=` pada tanya() -> kalau salah, bot
    TANYA ULANG (tidak mati di tengah seperti sebelumnya).
    Aturan: `auto`/kosong = dibuatkan otomatis; selain itu bebas
    (L2TP/CHAP tidak mensyaratkan panjang), tapi tanpa spasi.
    """
    t = (teks or "").strip()
    if t.lower() in ("", "auto", "-"):
        return True, ""
    if len(t) < 3:
        return False, "Password minimal 3 karakter (atau ketik `auto`)."
    if len(t) > 32:
        return False, "Password maksimal 32 karakter."
    if any(c.isspace() for c in t):
        return False, "Password tidak boleh ada spasi."
    if ":" in t or "*" in t:
        return False, "Password tidak boleh mengandung `:` atau `*`."
    return True, ""


def _l2tp_daftar():
    """Baca /etc/l2tp/.l2tp.db -> [(username, exp_iso, password)]."""
    hasil = []
    try:
        with open(S.L2TP_DB) as f:
            for l in f:
                if not l.startswith("###"):
                    continue
                b = l.split()
                if len(b) < 2:
                    continue
                user = b[1]
                exp = b[2] if len(b) > 2 else "-"
                pw = b[3] if len(b) > 3 else "-"
                hasil.append((user, exp, pw))
    except Exception as e:
        logging.error("baca .l2tp.db: %s", e)
    return hasil


def _l2tp_ringkas(maks=30):
    """Daftar akun L2TP + sisa hari, siap ditampilkan.

    Urut: yang paling lama expired di atas (paling mendesak).
    """
    d = _l2tp_daftar()
    if not d:
        return None, 0
    hari_ini = DT.date.today()
    baris = []
    for user, exp, _pw in d:
        try:
            tgl = DT.datetime.strptime(exp, "%Y-%m-%d").date()
            sisa = (tgl - hari_ini).days
            tgl_txt = tgl.strftime("%d %b %Y")
        except Exception:
            sisa = None
            tgl_txt = exp or "-"
        if sisa is None:
            status, urut = "?", 99999
        elif sisa < 0:
            status, urut = "HABIS", -99999 + sisa
        elif sisa == 0:
            status, urut = "HARI INI", 0
        else:
            status, urut = "%d hari" % sisa, sisa
        baris.append((urut, user, tgl_txt, status))
    baris.sort(key=lambda x: x[0])

    aktif = sum(1 for b in baris if b[0] >= 0)
    teks = []
    for _u, user, tgl_txt, status in baris[:maks]:
        teks.append("`%s`\n   %s  |  %s" % (user, tgl_txt, status))
    if len(baris) > maks:
        teks.append("_... dan %d akun lainnya_" % (len(baris) - maks))
    return "\n".join(teks), aktif


def _menu_l2tp_teks():
    daftar, aktif = _l2tp_ringkas()
    total = len(_l2tp_daftar())
    isi = daftar if daftar else "_Belum ada akun L2TP._"
    return """
━━━━━━━━━━━━━━━━━━━━━━━
**L2TP / IKEv2 MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `L2TP / IKEv2`
Hostname/IP : `%s`
IPSec PSK   : `%s`
━━━━━━━━━━━━━━━━━━━━━━━
**Total akun : `%d`**  (aktif: `%d`)
━━━━━━━━━━━━━━━━━━━━━━━
%s
━━━━━━━━━━━━━━━━━━━━━━━
""" % (S.cfg("DOMAIN", "-"), S._l2tp_psk() or "(lihat di panel)",
       total, aktif, isi)


# ============================================================
#  MENU L2TP
# ============================================================
@bot.on(events.CallbackQuery(data=b'l2tp'))
async def menu_l2tp(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    inline = [
        [Button.inline(" CREATE L2TP ", "create-l2tp"),
         Button.inline(" VIEW L2TP ", "view-l2tp")],
        [Button.inline(" RENEW L2TP ", "renew-l2tp"),
         Button.inline(" DELETE L2TP ", "delete-l2tp")],
        [Button.inline("‹ Main Menu ›", "menu")]]
    await safe_send(event, _menu_l2tp_teks(), inline)


# ============================================================
#  CREATE L2TP
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-l2tp'))
async def create_l2tp(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    chat = event.chat_id
    sender = await event.get_sender()
    uid = sender.id
    user = await tanya_admin(event, "**Username L2TP:**\n"
                                    "contoh: `budi01` (atau kirim `-` untuk batal)",
                             chat, uid)
    if not user:
        return
    user = user.strip().lower()
    ok_u, msg_u = cek_username(user)
    if not ok_u:
        await event.respond("❌ %s" % msg_u)
        return

    # jangan sampai bentrok dengan akun L2TP yang sudah ada
    if S._akun_ada("l2tp", user):
        await balas(event, "❌ Username `%s` **sudah dipakai** akun L2TP.\n"
                           "Pakai username lain." % user,
                    buttons=[[Button.inline("‹ L2TP Manager ›", "l2tp")]])
        return

    pw = await tanya_admin(event, "**Password L2TP:**\n"
                                   "Ketik `auto` atau `-` untuk dibuatkan otomatis,\n"
                                   "atau ketik password sendiri (bebas, tanpa spasi).",
                            chat, uid)
    if pw is None:
        return
    pw = pw.strip()
    if pw.lower() in ("", "auto", "-"):
        pw = S._rand(8)

    exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
    if not exp:
        return

    await event.respond("`Memproses... mohon tunggu`")
    ok, out = await asyncio.to_thread(S.buat_l2tp, user, pw, exp)
    if not ok:
        await balas(event, "❌ **Gagal membuat akun L2TP.**\n\n```\n%s\n```"
                    % (out or "")[-500:],
                    buttons=[[Button.inline("‹ L2TP Manager ›", "l2tp")]])
        return

    later = DT.date.today() + DT.timedelta(days=int(exp))
    psk = S._l2tp_psk() or "(lihat di panel)"
    dom = S.cfg("DOMAIN", "-")
    msg = """**L2TP / IKEv2 ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : %s
Host / IP     : %s
Username      : %s
Password      : %s
IPSec PSK     : %s
Expired       : %s
━━━━━━━━━━━━━━━━━━━━━━━
Port L2TP     : 1701 (UDP)
Port IPSec    : 500, 4500 (UDP)
Port IKEv2    : 500, 4500 (UDP)
DNS           : 8.8.8.8, 1.1.1.1
━━━━━━━━━━━━━━━━━━━━━━━
Cara pakai    : buka Pengaturan HP -> VPN -> Tambah
                VPN L2TP/IPSec PSK -> isi Host, Username,
                Password, dan PSK di atas.
━━━━━━━━━━━━━━━━━━━━━━━
File profil   : https://%s:81/l2tp-%s.txt
━━━━━━━━━━━━━━━━━━━━━━━
```""" % (user, dom, user, pw, psk, later.strftime("%d %b %Y"), dom, user)
    await balas(event, msg, buttons=[
        [Button.inline("👁️ VIEW L2TP", "view-l2tp"),
         Button.inline("‹ L2TP Manager ›", "l2tp")]])


# ============================================================
#  VIEW / DAFTAR L2TP
# ============================================================
@bot.on(events.CallbackQuery(data=b'view-l2tp'))
async def view_l2tp(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    daftar, aktif = _l2tp_ringkas(maks=40)
    total = len(_l2tp_daftar())
    if not daftar:
        await balas(event, "📋 **DAFTAR AKUN L2TP**\n\n"
                           "_Belum ada akun L2TP di VPS ini._",
                    buttons=[[Button.inline("‹ L2TP Manager ›", "l2tp")]])
        return
    await balas(event, "📋 **DAFTAR AKUN L2TP**\n"
                       "Total `%d` (aktif `%d`)\n"
                       "━━━━━━━━━━━━━━━━━━━━━━━\n%s\n"
                       "━━━━━━━━━━━━━━━━━━━━━━━"
                % (total, aktif, daftar),
                buttons=[[Button.inline("‹ L2TP Manager ›", "l2tp")]])


# ============================================================
#  RENEW L2TP
# ============================================================
@bot.on(events.CallbackQuery(data=b'renew-l2tp'))
async def renew_l2tp_menu(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    chat = event.chat_id
    sender = await event.get_sender()
    user = await tanya_admin(event, "**Username L2TP yang mau diperpanjang:**",
                             chat, sender.id)
    if not user:
        return
    user = user.strip().lower()

    data = dict((u, (e, p)) for u, e, p in _l2tp_daftar())
    if user not in data:
        await balas(event, "❌ Akun L2TP `%s` tidak ditemukan." % user,
                    buttons=[[Button.inline("‹ L2TP Manager ›", "l2tp")]])
        return

    exp_lama, _pw = data[user]
    tambah = await hari_admin(event, chat, "**Tambah berapa hari?**")
    if not tambah:
        return

    # hitung dari tanggal expired yang ADA (kalau masih aktif),
    # atau dari hari ini (kalau sudah lewat) -> tidak hangus
    try:
        dasar = DT.datetime.strptime(exp_lama, "%Y-%m-%d").date()
    except Exception:
        dasar = DT.date.today()
    if dasar < DT.date.today():
        dasar = DT.date.today()
    exp_baru = dasar + DT.timedelta(days=int(tambah))

    ok = await asyncio.to_thread(S.renew_l2tp, user, exp_baru.strftime("%Y-%m-%d"))
    if not ok:
        await balas(event, "❌ Gagal memperpanjang akun `%s`." % user,
                    buttons=[[Button.inline("‹ L2TP Manager ›", "l2tp")]])
        return

    await balas(event, """✅ **L2TP DIPERPANJANG**
```
━━━━━━━━━━━━━━━━━━━━━━━
Username      : %s
Expired lama  : %s
Ditambah      : %d hari
Expired baru  : %s
━━━━━━━━━━━━━━━━━━━━━━━
```""" % (user, exp_lama, tambah, exp_baru.strftime("%d %b %Y")),
                buttons=[[Button.inline("👁️ VIEW L2TP", "view-l2tp"),
                          Button.inline("‹ L2TP Manager ›", "l2tp")]])


# ============================================================
#  DELETE L2TP (dengan konfirmasi)
# ============================================================
@bot.on(events.CallbackQuery(data=b'delete-l2tp'))
async def delete_l2tp_menu(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    chat = event.chat_id
    sender = await event.get_sender()
    user = await tanya_admin(event, "**Username L2TP yang mau dihapus:**",
                             chat, sender.id)
    if not user:
        return
    user = user.strip().lower()

    if not S._akun_ada("l2tp", user):
        await balas(event, "❌ Akun L2TP `%s` tidak ditemukan." % user,
                    buttons=[[Button.inline("‹ L2TP Manager ›", "l2tp")]])
        return

    await balas(event,
                "⚠️ **HAPUS AKUN L2TP**\n\n"
                "Akun `%s` akan dihapus permanen dari VPS\n"
                "(chap-secrets, ipsec.secrets, .l2tp.db).\n\n"
                "Lanjutkan?" % user,
                buttons=[[Button.inline("✅ Ya, Hapus", "delete-l2tp-go-%s" % user)],
                         [Button.inline("‹ Batal ›", "l2tp")]])


@bot.on(events.CallbackQuery(pattern=r'^delete-l2tp-go-'))
async def delete_l2tp_go(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    user = event.data.decode().replace("delete-l2tp-go-", "").strip().lower()
    if not S._akun_ada("l2tp", user):
        await event.answer("Akun sudah tidak ada.", alert=True)
        return
    await asyncio.to_thread(S.hapus_l2tp, user)
    if S._akun_ada("l2tp", user):
        await balas(event, "❌ Akun `%s` masih terdeteksi. Cek manual di VPS:\n"
                           "`cat /etc/l2tp/.l2tp.db`" % user,
                    buttons=[[Button.inline("‹ L2TP Manager ›", "l2tp")]])
        return
    await balas(event, "✅ Akun L2TP `%s` sudah dihapus." % user,
                buttons=[[Button.inline("👁️ VIEW L2TP", "view-l2tp"),
                          Button.inline("‹ L2TP Manager ›", "l2tp")]])
