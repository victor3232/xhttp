# -*- coding: utf-8 -*-
# ============================================================
#  modules/notif.py - notifikasi masa aktif akun pelanggan
#  - H-3 & H-1 : ingatkan akun akan expired
#  - H-0 / lewat: akun expired, wajib perpanjang kalau mau aktif
#  Dipanggil dari background loop (__main__.py)
# ============================================================
import asyncio

from kyt import *
from kyt import store_lib as S


# ---------------- pengaturan ----------------
def notif_aktif():
    return str(S.get_setting("notif_aktif", "1")).strip() != "0"


def notif_hari():
    """Daftar H- berapa saja yang dikirim (default 3 dan 1)."""
    raw = str(S.get_setting("notif_hari", "3,1") or "3,1")
    out = []
    for x in raw.replace(" ", ",").split(","):
        try:
            v = int(x)
            if v >= 0:
                out.append(v)
        except Exception:
            continue
    return sorted(set(out), reverse=True) or [3, 1]


def _tombol(p):
    return [[Button.inline("🔄 Perpanjang Sekarang", "store-renew-%s" % p["id"])]]


def _teks_akan(p, sisa):
    return (
        "⏰ **PENGINGAT MASA AKTIF**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "🧾 **Akun    :** `%s`\n"
        "📦 **Paket   :** `%s`\n"
        "🗓️ **Expired :** `%s`\n"
        "⏱️ **Sisa    :** `%d hari lagi`\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "Supaya akun **tetap aktif**, silakan perpanjang sekarang.\n"
        "_(sisa hari otomatis ditambahkan, tidak hangus)_\n"
        "━━━━━━━━━━━━━━━━━━━━━━━"
    ) % (p["akun"], p["nama_produk"], p["expired"], sisa)


def _teks_expired(p, sisa):
    return (
        "⛔ **AKUN SUDAH EXPIRED**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "🧾 **Akun    :** `%s`\n"
        "📦 **Paket   :** `%s`\n"
        "🗓️ **Expired :** `%s`\n"
        "⏱️ **Lewat   :** `%d hari`\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "Akun **tidak bisa dipakai** sampai diperpanjang.\n"
        "Silakan perpanjang untuk mengaktifkan kembali 👇\n"
        "━━━━━━━━━━━━━━━━━━━━━━━"
    ) % (p["akun"], p["nama_produk"], p["expired"], abs(sisa))


async def _kirim(uid, teks, buttons=None):
    try:
        await bot.send_message(int(uid), teks, buttons=buttons)
        return True
    except Exception as e:
        logging.error("notif ke %s gagal: %s", uid, e)
        return False


async def cek_expired():
    """Cek semua akun pelanggan, kirim pengingat yang belum pernah dikirim."""
    if not notif_aktif():
        return
    hari_list = notif_hari()
    h_min = min(hari_list) if hari_list else 1
    terkirim = 0
    for p in S.pesanan_aktif():
        if terkirim >= 40:      # jangan spam dalam satu putaran
            break
        sisa = S.sisa_hari(p)
        if sisa is None:
            continue

        # ---- sudah expired ----
        if sisa < 0:
            if S.sudah_notif(p, "exp"):
                continue
            if await _kirim(p["user_id"], _teks_expired(p, sisa), _tombol(p)):
                S.tandai_notif(p["id"], "exp")
                S.pesanan_set_status(p["id"], "EXPIRED")
                terkirim += 1
            continue

        # ---- mendekati expired ----
        # pakai ambang terkecil yang cocok, kirim sekali saja per akun
        cocok = [h for h in hari_list if sisa <= h]
        if not cocok:
            continue
        tag = "h%d" % h_min
        if S.sudah_notif(p, tag):
            continue
        if await _kirim(p["user_id"], _teks_akan(p, sisa), _tombol(p)):
            S.tandai_notif(p["id"], tag)
            terkirim += 1

    if terkirim:
        logging.info("notif expired terkirim: %d", terkirim)
