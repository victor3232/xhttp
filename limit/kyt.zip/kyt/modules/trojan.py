from kyt import *
from kyt import store_lib as S


# ============================================================
#  CREATE TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return

	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	ok_u, msg_u = cek_username(user)
	if not ok_u:
		await event.respond("❌ %s" % msg_u)
		return

	quota = await tanya_admin(event, "**Quota (GB)** — isi `0` untuk unlimited:", chat, uid)
	if quota is None:
		return
	quota = quota.strip().replace(".", "").replace(",", "")
	if not quota.isdigit():
		await event.respond("❌ Harus angka.")
		return

	iplimit = await tanya_admin(event, "**Limit IP** — isi `0` untuk unlimited:", chat, uid)
	if iplimit is None:
		return
	iplimit = iplimit.strip().replace(".", "").replace(",", "")
	if not iplimit.isdigit():
		await event.respond("❌ Harus angka.")
		return

	exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
	if not exp:
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "addtr",
	                                  [user, exp, quota, iplimit],
	                                  45, lambda: S._akun_ada("trojan", user))
	if not ok or not S._akun_ada("trojan", user):
		await balas(event, "❌ **Gagal membuat akun Trojan.**\n\n```\n%s\n```"
		            % (out or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	later = DT.date.today() + DT.timedelta(days=int(exp))
	b = [y.group() for y in re.finditer("trojan://(.*)", out)]
	domain, uuid = DOMAIN, "-"
	try:
		domain = re.search("@(.*?):", b[0]).group(1)
		uuid = re.search("trojan://(.*?)@", b[0]).group(1)
	except Exception:
		pass
	linkku = S.link_berlabel(S.ambil_link(out, berlabel=False))
	detail = S.detail_xray("trojan", user, uuid,
	                       expired=later.strftime("%d %b %Y"),
	                       quota=quota, iplimit=iplimit,
	                       links=linkku, remarks=user)
	msg = "**TROJAN ACCOUNT**\n```\n" + detail + "\n```"
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  TRIAL TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	await event.respond("`Memproses trial TROJAN... mohon tunggu`")
	data = await asyncio.to_thread(S.trial_create, "trojan")
	if not data.get("ok"):
		await balas(event, "❌ **Gagal membuat trial TROJAN.**\n```\n%s\n```" % (data.get("error") or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	out = data.get("output", "") or ""
	user = data.get("username", "-")
	uuid = "-"
	try:
		x = [y.group() for y in re.finditer("trojan://(.*)", out)]
		uuid = re.search("trojan://(.*?)@", x[0]).group(1)
	except Exception:
		pass
	linkku = S.link_berlabel(S.ambil_link(out, berlabel=False))
	detail = S.detail_xray("trojan", user, uuid,
	                       expired="%s Menit" % data.get("minutes", 0),
	                       quota=str(data.get("quota_gb", 0)),
	                       iplimit=str(data.get("ip_limit", 0)),
	                       links=linkku, remarks=user)
	msg = ("**TROJAN TRIAL**\n```\n" + detail + "\n```\n"
	       "Berakhir: `%s`" % data.get("expires_text", "-"))
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# ============================================================
#  CEK LOGIN TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-cek-tr", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  HAPUS TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'show-trojan'))
async def show_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	try:
		z = subprocess.check_output("bot-member-xray trojan", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	user = await tanya_admin(event, "**Username yang mau dihapus:**", chat, sender.id)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("trojan", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	S._hapus_akun("trojan", user)
	await balas(event, "✅ Akun Trojan `%s` sudah dihapus." % user,
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  MENU TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	inline = [
		[Button.inline(" TRIAL TROJAN ", "trial-trojan"),
		 Button.inline(" CREATE TROJAN ", "create-trojan")],
		[Button.inline(" CHECK TROJAN ", "cek-trojan"),
		 Button.inline(" DELETE TROJAN ", "delete-trojan")],
		[Button.inline(" SHOW ALL USER TROJAN ", "show-trojan")],
		[Button.inline("‹ Main Menu ›", "menu")]]
	try:
		z = requests.get("http://ip-api.com/json/?fields=country,isp",
		                 timeout=10).json()
	except Exception:
		z = {"isp": "-", "country": "-"}
	# DOMAIN: var.txt, kalau kosong ambil dari berkas panel
	dom = S.cfg("DOMAIN", "") or "-"

	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**TROJAN MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `TROJAN`
Hostname/IP : `{dom}`
ISP         : `{z.get("isp", "-")}`
Country     : `{z.get("country", "-")}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send(event, msg, inline)
