from kyt import *
from kyt import store_lib as S


# ============================================================
#  CREATE TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return

	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	ok_u, msg_u = cek_username(user)
	if not ok_u:
		await event.respond("❌ %s" % msg_u)
		return

	quota = await tanya_admin(event, "**Quota (GB)** — isi `0` untuk unlimited:", chat, uid)
	if quota is None:
		return
	quota = quota.strip().replace(".", "").replace(",", "")
	if not quota.isdigit():
		await event.respond("❌ Harus angka.")
		return

	exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
	if not exp:
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "addtr",
	                                  [user, exp, quota, "0"],
	                                  45, lambda: S._akun_ada("trojan", user))
	if not ok or not S._akun_ada("trojan", user):
		await balas(event, "❌ **Gagal membuat akun Trojan.**\n\n```\n%s\n```"
		            % (out or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	later = DT.date.today() + DT.timedelta(days=int(exp))
	b = [y.group() for y in re.finditer("trojan://(.*)", out)]
	domain, uuid = DOMAIN, "-"
	try:
		domain = re.search("@(.*?):", b[0]).group(1)
		uuid = re.search("trojan://(.*?)@", b[0]).group(1)
	except Exception:
		pass
	linkku = "\n".join(S.link_berlabel(S.ambil_link(out, berlabel=False)))
	msg = f"""**TROJAN ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {user}
Host          : {domain}
Xray DNS      : {HOST}
Quota         : {quota} GB
Expired       : {later.strftime("%d %b %Y")}
━━━━━━━━━━━━━━━━━━━━━━━
Password/UUID : {uuid}
Network       : WS / gRPC / HTTPUpgrade / XHTTP / TCP
Path WS       : /trojan-ws
Path gRPC     : trojan-grpc
Port TLS      : 222-1000
Port gRPC     : 443
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
OpenClash     : https://{domain}:81/trojan-{user}.txt
━━━━━━━━━━━━━━━━━━━━━━━
```"""
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  TRIAL TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	menit = await tombol_admin(event, "**Pilih Masa Trial**", [
		[Button.inline("10 Menit", "10"), Button.inline("15 Menit", "15")],
		[Button.inline("30 Menit", "30"), Button.inline("60 Menit", "60")]],
		chat)
	if menit not in ("10", "15", "30", "60"):
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "trialtr", [menit], 40)
	if not ok:
		await balas(event, "❌ **Gagal membuat trial.**\n```\n%s\n```" % (out or "")[-400:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	b = [y.group() for y in re.finditer("trojan://(.*)", out)]
	remarks, domain, uuid = "-", DOMAIN, "-"
	try:
		remarks = re.search("#(.*)", b[0]).group(1)
		domain = re.search("@(.*?):", b[0]).group(1)
		uuid = re.search("trojan://(.*?)@", b[0]).group(1)
	except Exception:
		pass
	linkku = "\n".join(S.link_berlabel(S.ambil_link(out, berlabel=False)))
	msg = f"""**TROJAN TRIAL**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {remarks}
Host          : {domain}
Quota         : Unlimited
Expired       : {menit} Menit
━━━━━━━━━━━━━━━━━━━━━━━
Password/UUID : {uuid}
Network       : WS / gRPC / HTTPUpgrade / XHTTP / TCP
Port TLS      : 222-1000
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
```"""
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  CEK LOGIN TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-cek-tr", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  HAPUS TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	user = await tanya_admin(event, "**Username yang mau dihapus:**", chat, sender.id)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("trojan", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	S._hapus_akun("trojan", user)
	await balas(event, "✅ Akun Trojan `%s` sudah dihapus." % user,
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  MENU TROJAN
# ============================================================
@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	inline = [
		[Button.inline(" TRIAL TROJAN ", "trial-trojan"),
		 Button.inline(" CREATE TROJAN ", "create-trojan")],
		[Button.inline(" CHECK TROJAN ", "cek-trojan"),
		 Button.inline(" DELETE TROJAN ", "delete-trojan")],
		[Button.inline("‹ Main Menu ›", "menu")]]
	try:
		z = requests.get("http://ip-api.com/json/?fields=country,isp",
		                 timeout=10).json()
	except Exception:
		z = {"isp": "-", "country": "-"}
	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**TROJAN MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `TROJAN`
Hostname/IP : `{DOMAIN}`
ISP         : `{z.get("isp", "-")}`
Country     : `{z.get("country", "-")}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send(event, msg, inline)
