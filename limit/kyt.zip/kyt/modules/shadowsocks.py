from kyt import *
from kyt import store_lib as S


# ============================================================
#  CREATE SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return

	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	ok_u, msg_u = cek_username(user)
	if not ok_u:
		await event.respond("❌ %s" % msg_u)
		return

	quota = await tanya_admin(event, "**Quota (GB)** — isi `0` untuk unlimited:", chat, uid)
	if quota is None:
		return
	quota = quota.strip().replace(".", "").replace(",", "")
	if not quota.isdigit():
		await event.respond("❌ Harus angka.")
		return

	exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
	if not exp:
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "addss",
	                                  [user, exp, quota],
	                                  45, lambda: S._akun_ada("ss", user))
	if not ok or not S._akun_ada("ss", user):
		await balas(event, "❌ **Gagal membuat akun Shadowsocks.**\n\n```\n%s\n```"
		            % (out or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	later = DT.date.today() + DT.timedelta(days=int(exp))
	x = [y.group() for y in re.finditer("ss://(.*)", out)]
	uuid = "-"
	try:
		uuid = re.search("ss://(.*?)@", x[0]).group(1)
	except Exception:
		pass
	linkku = "\n".join(S.link_berlabel(S.ambil_link(out, berlabel=False)))
	msg = f"""**SHADOWSOCKS ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {user}
Host          : {DOMAIN}
Xray DNS      : {HOST}
Quota         : {quota} GB
Expired       : {later.strftime("%d %b %Y")}
━━━━━━━━━━━━━━━━━━━━━━━
Password      : {uuid}
Cipher        : aes-128-gcm
Network       : WS / gRPC
Path WS       : /ss-ws
Path gRPC     : ss-grpc
Port TLS      : 222-1000
Port NTLS     : 80, 8080, 8081-9999
Port gRPC     : 443
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
Link JSON     : https://{DOMAIN}:81/ss-{user}.txt
━━━━━━━━━━━━━━━━━━━━━━━
```"""
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  TRIAL SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	menit = await tombol_admin(event, "**Pilih Masa Trial**", [
		[Button.inline("10 Menit", "10"), Button.inline("15 Menit", "15")],
		[Button.inline("30 Menit", "30"), Button.inline("60 Menit", "60")]],
		chat)
	if menit not in ("10", "15", "30", "60"):
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S.buat_trial_xray, "ss", int(menit))
	if not ok:
		await balas(event, "❌ **Gagal membuat trial.**\n```\n%s\n```" % (out or "")[-400:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	x = [y.group() for y in re.finditer("ss://(.*)", out)]
	remarks, uuid = "-", "-"
	try:
		remarks = re.search("#(.*)", x[0]).group(1)
		uuid = re.search("ss://(.*?)@", x[0]).group(1)
	except Exception:
		pass
	linkku = "\n".join(S.link_berlabel(S.ambil_link(out, berlabel=False)))
	msg = f"""**SHADOWSOCKS TRIAL**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {remarks}
Host          : {DOMAIN}
Quota         : Unlimited
Expired       : {menit} Menit
━━━━━━━━━━━━━━━━━━━━━━━
Password      : {uuid}
Cipher        : aes-128-gcm
Network       : WS / gRPC
Port TLS      : 222-1000
Port NTLS     : 80, 8080, 8081-9999
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
```"""
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  CEK LOGIN SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-cek-ss", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  HAPUS SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	user = await tanya_admin(event, "**Username yang mau dihapus:**", chat, sender.id)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("ss", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	S._hapus_akun("ss", user)
	await balas(event, "✅ Akun Shadowsocks `%s` sudah dihapus." % user,
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  MENU SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	inline = [
		[Button.inline(" TRIAL SHADOWSOCKS ", "trial-shadowsocks"),
		 Button.inline(" CREATE SHADOWSOCKS ", "create-shadowsocks")],
		[Button.inline(" CHECK SHADOWSOCKS ", "cek-shadowsocks"),
		 Button.inline(" DELETE SHADOWSOCKS ", "delete-shadowsocks")],
		[Button.inline("‹ Main Menu ›", "menu")]]
	try:
		z = requests.get("http://ip-api.com/json/?fields=country,isp",
		                 timeout=10).json()
	except Exception:
		z = {"isp": "-", "country": "-"}
	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**SHADOWSOCKS MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `SHADOWSOCKS`
Hostname/IP : `{DOMAIN}`
ISP         : `{z.get("isp", "-")}`
Country     : `{z.get("country", "-")}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send(event, msg, inline)
