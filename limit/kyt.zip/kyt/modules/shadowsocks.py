from kyt import *
from kyt import store_lib as S


# ============================================================
#  CREATE SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return

	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	ok_u, msg_u = cek_username(user)
	if not ok_u:
		await event.respond("❌ %s" % msg_u)
		return

	quota = await tanya_admin(event, "**Quota (GB)** — isi `0` untuk unlimited:", chat, uid)
	if quota is None:
		return
	quota = quota.strip().replace(".", "").replace(",", "")
	if not quota.isdigit():
		await event.respond("❌ Harus angka.")
		return

	exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
	if not exp:
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "addss",
	                                  [user, exp, quota],
	                                  45, lambda: S._akun_ada("ss", user))
	if not ok or not S._akun_ada("ss", user):
		await balas(event, "❌ **Gagal membuat akun Shadowsocks.**\n\n```\n%s\n```"
		            % (out or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	later = DT.date.today() + DT.timedelta(days=int(exp))
	x = [y.group() for y in re.finditer("ss://(.*)", out)]
	uuid = "-"
	try:
		uuid = re.search("ss://(.*?)@", x[0]).group(1)
	except Exception:
		pass
	linkku = S.link_berlabel(S.ambil_link(out, berlabel=False))
	detail = S.detail_xray("ss", user, uuid,
	                       expired=later.strftime("%d %b %Y"),
	                       quota=quota, iplimit="0",
	                       links=linkku, remarks=user)
	msg = "**SHADOWSOCKS ACCOUNT**\n```\n" + detail + "\n```"
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  TRIAL SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	await event.respond("`Memproses trial SHADOWSOCKS... mohon tunggu`")
	data = await asyncio.to_thread(S.trial_create, "shadowsocks")
	if not data.get("ok"):
		await balas(event, "❌ **Gagal membuat trial SHADOWSOCKS.**\n```\n%s\n```" % (data.get("error") or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	out = data.get("output", "") or ""
	user = data.get("username", "-")
	uuid = "-"
	try:
		x = [y.group() for y in re.finditer("ss://(.*)", out)]
		uuid = re.search("ss://(.*?)@", x[0]).group(1)
	except Exception:
		pass
	linkku = S.link_berlabel(S.ambil_link(out, berlabel=False))
	detail = S.detail_xray("shadowsocks", user, uuid,
	                       expired="%s Menit" % data.get("minutes", 0),
	                       quota=str(data.get("quota_gb", 0)),
	                       iplimit=str(data.get("ip_limit", 0)),
	                       links=linkku, remarks=user)
	msg = ("**SHADOWSOCKS TRIAL**\n```\n" + detail + "\n```\n"
	       "Berakhir: `%s`" % data.get("expires_text", "-"))
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# ============================================================
#  CEK LOGIN SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-cek-ss", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  HAPUS SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	user = await tanya_admin(event, "**Username yang mau dihapus:**", chat, sender.id)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("ss", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	S._hapus_akun("ss", user)
	await balas(event, "✅ Akun Shadowsocks `%s` sudah dihapus." % user,
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  MENU SHADOWSOCKS
# ============================================================
@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	inline = [
		[Button.inline(" TRIAL SHADOWSOCKS ", "trial-shadowsocks"),
		 Button.inline(" CREATE SHADOWSOCKS ", "create-shadowsocks")],
		[Button.inline(" CHECK SHADOWSOCKS ", "cek-shadowsocks"),
		 Button.inline(" DELETE SHADOWSOCKS ", "delete-shadowsocks")],
		[Button.inline("‹ Main Menu ›", "menu")]]
	try:
		z = requests.get("http://ip-api.com/json/?fields=country,isp",
		                 timeout=10).json()
	except Exception:
		z = {"isp": "-", "country": "-"}
	# DOMAIN: var.txt, kalau kosong ambil dari berkas panel
	dom = S.cfg("DOMAIN", "") or "-"

	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**SHADOWSOCKS MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `SHADOWSOCKS`
Hostname/IP : `{dom}`
ISP         : `{z.get("isp", "-")}`
Country     : `{z.get("country", "-")}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send(event, msg, inline)
