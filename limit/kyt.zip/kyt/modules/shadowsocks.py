from kyt import *
from kyt import store_lib as S

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
	async def create_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Quota:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 HARI ","3"),
Button.inline(" 7 HARI ","7")],
[Button.inline(" 30 HARI ","30")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("`Memproses... mohon tunggu`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			linkku = "\n".join(S.link_berlabel(S.ambil_link(a, berlabel=False)))
			msg = f"""
**SHADOWSOCKS ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {user}
Host          : {DOMAIN}
Xray DNS      : {HOST}
Quota         : Unlimited
Expired       : {later}
━━━━━━━━━━━━━━━━━━━━━━━
Password      : {uuid}
Cipher        : aes-128-gcm
Network       : WS / gRPC
Path WS       : /ss-ws
Path gRPC     : ss-grpc
Port TLS      : 222-1000
Port NTLS     : 80, 8080, 8081-9999
Port gRPC     : 443
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
Link JSON     : https://{DOMAIN}:81/ss-{user}.txt
━━━━━━━━━━━━━━━━━━━━━━━
```
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
	async def cek_shadowsocks_(event):
		cmd = 'bot-cek-ss'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**Shows Logged In Users Shadowsocks**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_shadowsocks_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
	async def delete_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | del-ss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
	async def trial_shadowsocks_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 Menit ","10"),
Button.inline(" 15 Menit ","15")],
[Button.inline(" 30 Menit ","30"),
Button.inline(" 60 Menit ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("`Memproses... mohon tunggu`")
		cmd = f'printf "%s\n" "{exp}" | trialss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			linkku = "\n".join(S.link_berlabel(S.ambil_link(a, berlabel=False)))
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
**SHADOWSOCKS ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Remarks       : {remarks}
Host          : {DOMAIN}
Xray DNS      : {HOST}
Quota         : Unlimited
Expired       : {exp} Minutes
━━━━━━━━━━━━━━━━━━━━━━━
Password      : {uuid}
Cipher        : aes-128-gcm
Network       : WS / gRPC
Path WS       : /ss-ws
Path gRPC     : ss-grpc
Port TLS      : 222-1000
Port NTLS     : 80, 8080, 8081-9999
Port gRPC     : 443
Pub Key       : {PUB}
━━━━━━━━━━━━━━━━━━━━━━━
{linkku}
━━━━━━━━━━━━━━━━━━━━━━━
Link JSON     : https://{DOMAIN}:81/ss-{remarks}.txt
━━━━━━━━━━━━━━━━━━━━━━━
```
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
	async def shadowsocks_(event):
		inline = [
[Button.inline(" TRIAL SHDWSCSK ","trial-shadowsocks"),
Button.inline(" CREATE SHDWSCSK ","create-shadowsocks")],
[Button.inline(" CHECK SHDWSCSK ","cek-shadowsocks"),
Button.inline(" DELETE SHDWSCSK ","delete-shadowsocks")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**SHADOWSOCKS MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `SHADOWSOCKS`
Hostname/IP : `{DOMAIN}`
ISP         : `{z["isp"]}`
Country     : `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await shadowsocks_(event)
	else:
		await event.answer("Access Denied",alert=True)
