from kyt import *
from kyt import store_lib as S


# ============================================================
#  CREATE VLESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return

	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	ok_u, msg_u = cek_username(user)
	if not ok_u:
		await event.respond("❌ %s" % msg_u)
		return

	quota = await tanya_admin(event, "**Quota (GB)** — isi `0` untuk unlimited:", chat, uid)
	if quota is None:
		return
	quota = quota.strip().replace(".", "").replace(",", "")
	if not quota.isdigit():
		await event.respond("❌ Harus angka.")
		return

	iplimit = await tanya_admin(event, "**Limit IP** — isi `0` untuk unlimited:", chat, uid)
	if iplimit is None:
		return
	iplimit = iplimit.strip().replace(".", "").replace(",", "")
	if not iplimit.isdigit():
		await event.respond("❌ Harus angka.")
		return

	exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
	if not exp:
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "addvless",
	                                  [user, exp, quota, iplimit],
	                                  45, lambda: S._akun_ada("vless", user))
	if not ok or not S._akun_ada("vless", user):
		await balas(event, "❌ **Gagal membuat akun VLESS.**\n\n```\n%s\n```"
		            % (out or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	later = DT.date.today() + DT.timedelta(days=int(exp))
	x = [y.group() for y in re.finditer("vless://(.*)", out)]
	uuid = "-"
	try:
		uuid = re.search("vless://(.*?)@", x[0]).group(1)
	except Exception:
		pass
	linkku = S.link_berlabel(S.ambil_link(out, berlabel=False))
	detail = S.detail_xray("vless", user, uuid,
	                       expired=later.strftime("%d %b %Y"),
	                       quota=quota, iplimit=iplimit,
	                       links=linkku, remarks=user)
	msg = "**VLESS ACCOUNT**\n```\n" + detail + "\n```"
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  TRIAL VLESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	menit = await tombol_admin(event, "**Pilih Masa Trial**", [
		[Button.inline("10 Menit", "10"), Button.inline("15 Menit", "15")],
		[Button.inline("30 Menit", "30"), Button.inline("60 Menit", "60")]],
		chat)
	if menit not in ("10", "15", "30", "60"):
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S.buat_trial_xray, "vless", int(menit))
	if not ok:
		await balas(event, "❌ **Gagal membuat trial.**\n```\n%s\n```" % (out or "")[-400:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	x = [y.group() for y in re.finditer("vless://(.*)", out)]
	remarks, uuid = "-", "-"
	try:
		remarks = re.search("#(.*)", x[0]).group(1)
		uuid = re.search("vless://(.*?)@", x[0]).group(1)
	except Exception:
		pass
	linkku = S.link_berlabel(S.ambil_link(out, berlabel=False))
	# UI sama dgn akun reguler (seragam), hanya judul & expired yg beda
	detail = S.detail_xray("vless", remarks, uuid,
	                       expired="%s Menit" % menit,
	                       quota="0", iplimit="0",
	                       links=linkku, remarks=remarks)
	msg = "**VLESS TRIAL**\n```\n" + detail + "\n```"
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  CEK LOGIN VLESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'cek-vless'))
async def cek_vless(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-cek-vless", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  HAPUS VLESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	user = await tanya_admin(event, "**Username yang mau dihapus:**", chat, sender.id)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("vless", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	S._hapus_akun("vless", user)
	await balas(event, "✅ Akun VLESS `%s` sudah dihapus." % user,
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  MENU VLESS
# ============================================================
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	inline = [
		[Button.inline(" TRIAL VLESS ", "trial-vless"),
		 Button.inline(" CREATE VLESS ", "create-vless")],
		[Button.inline(" CHECK VLESS ", "cek-vless"),
		 Button.inline(" DELETE VLESS ", "delete-vless")],
		[Button.inline("‹ Main Menu ›", "menu")]]
	try:
		z = requests.get("http://ip-api.com/json/?fields=country,isp",
		                 timeout=10).json()
	except Exception:
		z = {"isp": "-", "country": "-"}
	# DOMAIN: var.txt, kalau kosong ambil dari berkas panel
	dom = S.cfg("DOMAIN", "") or "-"

	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**VLESS MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `VLESS`
Hostname/IP : `{dom}`
ISP         : `{z.get("isp", "-")}`
Country     : `{z.get("country", "-")}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send(event, msg, inline)
