from kyt import *
from kyt import store_lib as S


@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
	async def rebooot_(event):
		await event.edit("`Merestart server...`")
		try:
			subprocess.check_output("reboot", shell=True)
		except Exception:
			pass
		await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━
**REBOOT SERVER**
━━━━━━━━━━━━━━━━━━━━━━━
Perintah reboot sudah dikirim.
Server akan restart sebentar lagi.
━━━━━━━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rebooot_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
	async def resx_(event):
		await event.edit("`Merestart service...`")
		try:
			subprocess.check_output(
				"systemctl restart xray; systemctl restart nginx; systemctl restart haproxy",
				shell=True)
		except Exception:
			pass
		await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━
**RESTART SERVICE**
━━━━━━━━━━━━━━━━━━━━━━━
Xray     : di-restart
Nginx    : di-restart
Haproxy  : di-restart
━━━━━━━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await resx_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
	async def speedtest_(event):
		await event.edit("`Menjalankan speedtest...`")
		try:
			z = subprocess.check_output("speedtest-cli --share", shell=True,
			                            stderr=subprocess.STDOUT).decode("utf-8")
		except Exception as e:
			z = "Gagal menjalankan speedtest: %s" % e
		await event.respond(f"""
━━━━━━━━━━━━━━━━━━━━━━━
**SPEEDTEST**
━━━━━━━━━━━━━━━━━━━━━━━
```
{z}
```
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await speedtest_(event)
	else:
		await event.answer("Access Denied",alert=True)


# ---------- backup & restore (modul modules/backup.py) ----------
@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
	from kyt.modules.backup import bk_vps
	await bk_vps(event)


@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
	from kyt.modules.backup import rs_menu
	await rs_menu(event)


@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline(" SPEEDTEST","speedtest"),
Button.inline(" BACKUP & RESTORE","backer")],
[Button.inline(" REBOOT SERVER","reboot"),
Button.inline(" RESTART SERVICE","resx")],
[Button.inline("‹ Main Menu ›","menu")]]
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**OTHER SETTING**
━━━━━━━━━━━━━━━━━━━━━━━
Hostname/IP : `{DOMAIN}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
		await safe_send(event, msg, inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("Access Denied",alert=True)
