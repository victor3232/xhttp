# -*- coding: utf-8 -*-
# ============================================================
#  modules/backup.py - BACKUP & RESTORE
#   1) Backup VPS  : config + akun + database bot -> 1 file .zip
#   2) Backup DB   : database bot saja (saldo/pesanan/deposit)
#   3) Restore     : upload kembali file-nya ke bot
#  Tidak butuh rclone / Google Drive / email.
# ============================================================
import os
import glob
import shutil
import zipfile
import tempfile
import datetime as DT

from kyt import *
from kyt import store_lib as S

BACKUP_DIR = "/root/backup"


def _db_bot():
    """Lokasi database bot (ikut WorkingDirectory service /usr/bin)."""
    p = os.path.abspath(S.DB_PATH)
    if os.path.isfile(p):
        return p
    if os.path.isfile("/usr/bin/kyt/database.db"):
        return "/usr/bin/kyt/database.db"
    return p


def _var_bot():
    return os.path.join(os.path.dirname(_db_bot()), "var.txt")

# berkas penting yang ikut di-backup
BERKAS = [
    "/etc/xray/config.json",
    "/etc/xray/domain", "/etc/xray/city", "/etc/xray/isp", "/etc/xray/dns",
    "/etc/passwd", "/etc/group", "/etc/shadow", "/etc/gshadow",
    "/etc/ssh/.ssh.db",
    "/etc/vmess/.vmess.db",
    "/etc/vless/.vless.db",
    "/etc/trojan/.trojan.db",
    "/etc/shadowsocks/.shadowsocks.db",
    "/etc/l2tp/.l2tp.db", "/etc/l2tp/psk",
    "/root/akun/vless/.vless.conf",
    "/root/akun/trojan/.trojan.conf",
    "/root/akun/shadowsocks/.shadowsocks.conf",
]


# folder yang ikut di-backup (rekursif)
FOLDER = ["/root/akun"]

# hanya path dengan awalan ini yang boleh ditulis saat restore (anti zip-slip)
IZIN = ("etc/xray/", "etc/ssh/", "etc/vmess/", "etc/vless/", "etc/trojan/",
        "etc/shadowsocks/", "etc/l2tp/", "root/akun/", "usr/bin/kyt/")
IZIN_TEPAT = ("etc/passwd", "etc/group", "etc/shadow", "etc/gshadow")


def _izin(arc):
    return arc in IZIN_TEPAT or arc.startswith(IZIN)


# ---------------- backup ----------------
def buat_backup_vps():
    """Bikin 1 file zip berisi semua data penting. Return (path, jumlah_file)."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    nama = "kyt-backup-%s.zip" % DT.datetime.now().strftime("%Y%m%d-%H%M%S")
    path = os.path.join(BACKUP_DIR, nama)
    n = 0
    pasangan = [(f, f.lstrip("/")) for f in BERKAS]
    # database & var bot selalu disimpan dengan nama tetap
    pasangan.append((_db_bot(), "usr/bin/kyt/database.db"))
    pasangan.append((_var_bot(), "usr/bin/kyt/var.txt"))
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for f, arc in pasangan:
            if os.path.isfile(f):
                z.write(f, arc)
                n += 1
        for d in FOLDER:
            if not os.path.isdir(d):
                continue
            for root, _dirs, files in os.walk(d):
                for fn in files:
                    p = os.path.join(root, fn)
                    z.write(p, p.lstrip("/"))
                    n += 1
    return path, n


def buat_backup_db():
    """Copy database bot -> /root/backup. Return path."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if not os.path.isfile(_db_bot()):
        return None
    nama = "kyt-db-%s.db" % DT.datetime.now().strftime("%Y%m%d-%H%M%S")
    path = os.path.join(BACKUP_DIR, nama)
    shutil.copy2(_db_bot(), path)
    return path


def backup_db_harian(simpan=10):
    """Backup otomatis 1x per hari (dipanggil dari loop background)."""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        if not os.path.isfile(_db_bot()):
            return None
        dst = os.path.join(BACKUP_DIR, "kyt-db-%s.db" % DT.date.today().strftime("%Y%m%d"))
        if not os.path.exists(dst):
            shutil.copy2(_db_bot(), dst)
        for f in sorted(glob.glob(os.path.join(BACKUP_DIR, "kyt-db-*.db")))[:-simpan]:
            try:
                os.remove(f)
            except Exception:
                pass
        return dst
    except Exception as e:
        logging.error("backup db harian: %s", e)
        return None


def ringkasan():
    """Info jumlah data di database bot."""
    try:
        x = S.db()
        u = x.execute("SELECT COUNT(*) c FROM store_user").fetchone()["c"]
        p = x.execute("SELECT COUNT(*) c FROM pesanan").fetchone()["c"]
        d = x.execute("SELECT COUNT(*) c FROM deposit").fetchone()["c"]
        s = x.execute("SELECT COALESCE(SUM(saldo),0) s FROM store_user").fetchone()["s"]
        x.close()
        ukuran = os.path.getsize(_db_bot()) if os.path.isfile(_db_bot()) else 0
        return ("user: %d | akun terjual: %d | deposit: %d | total saldo: %s | ukuran db: %.1f KB"
                % (u, p, d, S.rupiah(s), ukuran / 1024.0))
    except Exception as e:
        return "tidak bisa dibaca: %s" % e


# ---------------- restore ----------------
def restore_vps(path_zip):
    """Terapkan isi file zip ke sistem. Return (ok, pesan)."""
    if not os.path.isfile(path_zip):
        return False, "File tidak ditemukan."
    tmp = tempfile.mkdtemp(prefix="kytrestore-")
    try:
        with zipfile.ZipFile(path_zip) as z:
            z.extractall(tmp)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return False, "Zip rusak / tidak bisa dibuka: %s" % e

    # cadangkan database bot yang sekarang
    try:
        if os.path.isfile(_db_bot()):
            shutil.copy2(_db_bot(), _db_bot() + ".sebelum-restore")
    except Exception:
        pass

    dipulihkan, dilewati = 0, 0
    for root, _dirs, files in os.walk(tmp):
        for fn in files:
            src = os.path.join(root, fn)
            arc = os.path.relpath(src, tmp).replace("\\", "/")
            if not _izin(arc):
                dilewati += 1
                continue
            dst = "/" + arc
            try:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                dipulihkan += 1
            except Exception as e:
                logging.error("restore %s: %s", dst, e)
                dilewati += 1
    shutil.rmtree(tmp, ignore_errors=True)

    # hak akses penting
    for f, mode in (("/etc/shadow", 0o640), ("/etc/gshadow", 0o640)):
        try:
            os.chmod(f, mode)
        except Exception:
            pass

    # restart service
    for svc in ("xray", "kyt"):
        try:
            subprocess.run("systemctl restart %s" % svc, shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
        except Exception:
            pass

    return (dipulihkan > 0,
            "%d file dipulihkan, %d dilewati." % (dipulihkan, dilewati))


def restore_db(path_file):
    """Pulihkan database bot dari file .db atau .zip. Return (ok, pesan)."""
    if not os.path.isfile(path_file):
        return False, "File tidak ditemukan."
    sumber = path_file
    tmp = None

    if zipfile.is_zipfile(path_file):
        tmp = tempfile.mkdtemp(prefix="kytdb-")
        try:
            with zipfile.ZipFile(path_file) as z:
                kandidat = [n for n in z.namelist()
                            if n.endswith("database.db") or n.endswith(".db")]
                if not kandidat:
                    shutil.rmtree(tmp, ignore_errors=True)
                    return False, "Di dalam zip tidak ada file database.db"
                z.extractall(tmp)
            sumber = os.path.join(tmp, kandidat[0])
        except Exception as e:
            shutil.rmtree(tmp, ignore_errors=True)
            return False, "Zip rusak: %s" % e

    # pastikan ini sqlite yang benar
    try:
        with open(sumber, "rb") as f:
            if f.read(16) != b"SQLite format 3\x00":
                if tmp:
                    shutil.rmtree(tmp, ignore_errors=True)
                return False, "Bukan file database SQLite yang sah."
    except Exception as e:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
        return False, "Gagal membaca file: %s" % e

    try:
        if os.path.isfile(_db_bot()):
            shutil.copy2(_db_bot(), _db_bot() + ".sebelum-restore")
        os.makedirs(os.path.dirname(_db_bot()), exist_ok=True)
        shutil.copy2(sumber, _db_bot())
    except Exception as e:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
        return False, "Gagal menulis database: %s" % e
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)

    try:
        S.init_store()      # pastikan tabel & produk lengkap
    except Exception:
        pass
    return True, "Database bot berhasil dipulihkan."


# ---------------- helper kirim/terima file ----------------
async def _kirim_file(chat, path, caption=""):
    try:
        await bot.send_file(chat, path, caption=caption, force_document=True)
        return True
    except Exception as e:
        logging.error("kirim file gagal: %s", e)
        return False


async def _minta_file(event, judul):
    """Tunggu user mengirim file (untuk restore)."""
    await balas(event, judul)
    m = None
    try:
        async with bot.conversation(event.chat_id, exclusive=False,
                                    timeout=300) as conv:
            m = await conv.get_response(timeout=300)
    except asyncio.TimeoutError:
        await balas(event, "⏱️ Waktu habis. Silakan ulangi dari menu.")
        return None
    except Exception as e:
        logging.error("minta file gagal: %s", e)
        await balas(event, "❌ Gagal menerima file: %s" % e)
        return None
    if m is None:
        return None
    if (m.raw_text or "").strip() == "-":
        await balas(event, "Dibatalkan.")
        return None
    if not getattr(m, "file", None):
        await balas(event, "❌ Itu bukan file. Kirim sebagai **dokumen** (.zip/.db).")
        return None
    nama = getattr(m.file, "name", None) or "upload.bin"
    path = os.path.join("/tmp", "kytupload-%s-%s" % (DT.datetime.now().strftime("%H%M%S"), nama))
    try:
        await m.download_media(path)
    except Exception as e:
        logging.error("download upload gagal: %s", e)
        await balas(event, "❌ Gagal mengunduh file: %s" % e)
        return None
    return path


def _adm_ok(event):
    return valid(str(event.sender_id)) == "true"


# ---------------- menu ----------------
@bot.on(events.CallbackQuery(data=b'backer'))
async def backer(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        ada = len(glob.glob(os.path.join(BACKUP_DIR, "kyt-db-*.db")))
    except Exception:
        ada = 0
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**BACKUP & RESTORE**
━━━━━━━━━━━━━━━━━━━━━━━
Database bot : `{_db_bot()}`
Isi database : {ringkasan()}
Backup db di server : `{ada}` file ({BACKUP_DIR})

**Backup VPS** = config + semua akun + database bot (1 file .zip)
**Backup Database** = database bot saja (saldo/pesanan/deposit)

File dikirim ke chat ini, simpan baik-baik.
Kalau pindah VPS: install ulang panel + bot, lalu pakai **Restore**.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("💾 Backup VPS (lengkap)", "bk-vps")],
        [Button.inline("💾 Backup Database Bot", "bk-db"),
         Button.inline("♻️ Restore", "rs-menu")],
        [Button.inline("‹ Store ›", "storeadmin"),
         Button.inline("‹ Main Menu ›", "menu")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'bk-vps'))
async def bk_vps(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await safe_send(event, "⏳ **Membuat backup VPS...**\nMohon tunggu.")
    try:
        path, n = await __import__('asyncio').to_thread(buat_backup_vps)
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    ukuran = os.path.getsize(path) / 1024.0 / 1024.0
    okk = await _kirim_file(event.chat_id, path,
                            "💾 **BACKUP VPS**\n%d file • %.2f MB\n%s\n\n"
                            "Simpan file ini. Untuk pindah VPS -> menu Restore."
                            % (n, ukuran, DT.datetime.now().strftime("%d-%m-%Y %H:%M")))
    try:
        os.remove(path)
    except Exception:
        pass
    if not okk:
        await safe_send(event, "❌ File backup gagal dikirim ke Telegram.",
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])


@bot.on(events.CallbackQuery(data=b'bk-db'))
async def bk_db(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    try:
        path = await __import__('asyncio').to_thread(buat_backup_db)
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    if not path:
        await safe_send(event, "❌ Database bot belum ada.",
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    okk = await _kirim_file(event.chat_id, path,
                            "💾 **BACKUP DATABASE BOT**\n%s\n\n"
                            "Berisi: saldo user, riwayat pesanan, deposit, pengaturan."
                            % DT.datetime.now().strftime("%d-%m-%Y %H:%M"))
    if not okk:
        await safe_send(event, "❌ File gagal dikirim.",
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])


@bot.on(events.CallbackQuery(data=b'rs-menu'))
async def rs_menu(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    teks = """
━━━━━━━━━━━━━━━━━━━━━━━
**RESTORE**
━━━━━━━━━━━━━━━━━━━━━━━
Kirim **file** hasil backup ke bot ini (dokumen .zip / .db),
bot akan memulihkannya otomatis.

⚠️ Data yang sekarang akan DITIMPA.
   (database bot yang sekarang tetap disimpan sebagai
    `database.db.sebelum-restore`)
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("♻️ Restore VPS (zip)", "rs-vps")],
        [Button.inline("♻️ Restore Database Bot", "rs-db")],
        [Button.inline("‹ Backup ›", "backer")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'rs-vps'))
async def rs_vps(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    path = await _minta_file(event,
                             "📤 **Kirim file backup VPS (.zip)** ke chat ini.\n"
                             "Kirim `-` untuk batal.")
    if not path:
        await event.reply("❌ Tidak ada file yang diterima.",
                          buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    okk, pesan = await __import__('asyncio').to_thread(restore_vps, path)
    try:
        os.remove(path)
    except Exception:
        pass
    await safe_send(event,
                    ("✅ **RESTORE SELESAI**\n%s\n\nService xray & bot sudah di-restart."
                     % pesan) if okk else ("❌ **GAGAL:** %s" % pesan),
                    buttons=[[Button.inline("‹ Backup ›", "backer")]])


@bot.on(events.CallbackQuery(data=b'rs-db'))
async def rs_db(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    path = await _minta_file(event,
                             "📤 **Kirim file database bot** (.db atau .zip) ke chat ini.\n"
                             "Kirim `-` untuk batal.")
    if not path:
        await event.reply("❌ Tidak ada file yang diterima.",
                          buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    okk, pesan = await __import__('asyncio').to_thread(restore_db, path)
    try:
        os.remove(path)
    except Exception:
        pass
    await safe_send(event,
                    ("✅ **RESTORE DATABASE SELESAI**\n%s\n\nIsi sekarang:\n%s"
                     % (pesan, ringkasan())) if okk else ("❌ **GAGAL:** %s" % pesan),
                    buttons=[[Button.inline("‹ Backup ›", "backer")]])
