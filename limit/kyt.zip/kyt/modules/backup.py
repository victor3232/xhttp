# -*- coding: utf-8 -*-
# ============================================================
#  modules/backup.py - BACKUP & RESTORE
#   1) Backup VPS  : config + akun + database bot -> 1 file .zip
#   2) Backup DB   : database bot saja (saldo/pesanan/deposit)
#   3) Restore     : upload kembali file-nya ke bot
#  Tidak butuh rclone / Google Drive / email.
# ============================================================
import os
import glob
import shutil
import zipfile
import tempfile
import datetime as DT

import requests

from kyt import *
from kyt import store_lib as S

BACKUP_DIR = "/root/backup"


def _db_bot():
    """Lokasi database bot (ikut WorkingDirectory service /usr/bin)."""
    p = os.path.abspath(S.DB_PATH)
    if os.path.isfile(p):
        return p
    if os.path.isfile("/usr/bin/kyt/database.db"):
        return "/usr/bin/kyt/database.db"
    return p


def _var_bot():
    return os.path.join(os.path.dirname(_db_bot()), "var.txt")

# berkas penting yang ikut di-backup
BERKAS = [
    # ---- akun VPN (data buyer) ----
    "/etc/passwd", "/etc/group", "/etc/shadow", "/etc/gshadow",
    "/etc/ssh/.ssh.db", "/etc/ssh/sshd_config",
    "/etc/vmess/.vmess.db",
    "/etc/vless/.vless.db",
    "/etc/trojan/.trojan.db",
    "/etc/shadowsocks/.shadowsocks.db",
    "/etc/l2tp/.l2tp.db", "/etc/l2tp/psk",
    "/etc/ppp/chap-secrets",        # akun L2TP (CHAP)
    "/etc/ipsec.secrets",           # akun IKEv2 (EAP)
    # ---- konfigurasi service ----
    "/etc/xray/config.json",
    "/etc/xray/domain", "/etc/xray/city", "/etc/xray/isp", "/etc/xray/dns",
    "/etc/xray/xray.crt", "/etc/xray/xray.key",   # sertifikat TLS Xray
    "/etc/haproxy/haproxy.cfg", "/etc/haproxy/hap.pem",
    "/etc/nginx/nginx.conf", "/etc/nginx/conf.d/xray.conf",
    "/etc/default/dropbear",
    "/etc/kyt.txt",
    # ---- profil akun (file .txt yang dibagikan ke buyer) ----
    "/var/www/html/ssh-80.txt",
]

# folder yang ikut di-backup (rekursif)
# File di dalam FOLDER yang lebih besar dari ini akan DILEWATI.
# (data akun & profil hampir selalu < 100 KB)
BATAS_FILE = 8 * 1024 * 1024   # 8 MB

# CATATAN PENTING: /usr/local/share/xray SENGAJA TIDAK di-backup.
# Isinya geoip.dat (~16 MB) + geosite.dat (~11 MB) = ~27 MB data
# routing yang diunduh otomatis oleh installer premi.sh.
# Bukan data buyer -> kalau ikut, file backup jadi besar tanpa guna.
FOLDER = [
    "/root/akun",          # config akun xray
    "/var/www/html",       # profil akun buyer (.txt)
    "/etc/openvpn",        # sertifikat & config OVPN
    "/etc/letsencrypt",    # sertifikat SSL
]

# hanya path dengan awalan ini yang boleh ditulis saat restore (anti zip-slip)
IZIN = ("etc/xray/", "etc/ssh/", "etc/vmess/", "etc/vless/", "etc/trojan/",
        "etc/shadowsocks/", "etc/l2tp/", "etc/ppp/", "etc/haproxy/",
        "etc/nginx/", "etc/openvpn/", "etc/letsencrypt/",
        "etc/default/", "root/akun/", "usr/bin/kyt/",
        "var/www/html/", "usr/local/share/xray/")
IZIN_TEPAT = ("etc/passwd", "etc/group", "etc/shadow", "etc/gshadow",
              "etc/ipsec.secrets", "etc/kyt.txt")


def _izin(arc):
    return arc in IZIN_TEPAT or arc.startswith(IZIN)


# ---------------- backup ----------------
def buat_backup_vps():
    """Bikin 1 file zip berisi semua data penting. Return (path, jumlah_file)."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    nama = "kyt-backup-%s.zip" % DT.datetime.now().strftime("%Y%m%d-%H%M%S")
    path = os.path.join(BACKUP_DIR, nama)
    n = 0
    dilewati_besar = []
    pasangan = [(f, f.lstrip("/")) for f in BERKAS]
    # database & var bot selalu disimpan dengan nama tetap
    pasangan.append((_db_bot(), "usr/bin/kyt/database.db"))
    pasangan.append((_var_bot(), "usr/bin/kyt/var.txt"))
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for f, arc in pasangan:
            if os.path.isfile(f):
                z.write(f, arc)
                n += 1
        for d in FOLDER:
            if not os.path.isdir(d):
                continue
            for root, _dirs, files in os.walk(d):
                for fn in files:
                    p = os.path.join(root, fn)
                    try:
                        if os.path.getsize(p) > BATAS_FILE:
                            dilewati_besar.append("%s (%.1f MB)"
                                                  % (p, os.path.getsize(p) / 1048576.0))
                            continue
                    except Exception:
                        pass
                    z.write(p, p.lstrip("/"))
                    n += 1
    if dilewati_besar:
        logging.info("backup: %d file besar dilewati", len(dilewati_besar))
    return path, n


def buat_backup_db():
    """Copy database bot -> /root/backup. Return path."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if not os.path.isfile(_db_bot()):
        return None
    nama = "kyt-db-%s.db" % DT.datetime.now().strftime("%Y%m%d-%H%M%S")
    path = os.path.join(BACKUP_DIR, nama)
    shutil.copy2(_db_bot(), path)
    return path


def backup_db_harian(simpan=10):
    """Backup otomatis 1x per hari (dipanggil dari loop background)."""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        if not os.path.isfile(_db_bot()):
            return None
        dst = os.path.join(BACKUP_DIR, "kyt-db-%s.db" % DT.date.today().strftime("%Y%m%d"))
        if not os.path.exists(dst):
            shutil.copy2(_db_bot(), dst)
        for f in sorted(glob.glob(os.path.join(BACKUP_DIR, "kyt-db-*.db")))[:-simpan]:
            try:
                os.remove(f)
            except Exception:
                pass
        return dst
    except Exception as e:
        logging.error("backup db harian: %s", e)
        return None


def ringkasan():
    """Info jumlah data di database bot."""
    try:
        x = S.db()
        u = x.execute("SELECT COUNT(*) c FROM store_user").fetchone()["c"]
        p = x.execute("SELECT COUNT(*) c FROM pesanan").fetchone()["c"]
        d = x.execute("SELECT COUNT(*) c FROM deposit").fetchone()["c"]
        s = x.execute("SELECT COALESCE(SUM(saldo),0) s FROM store_user").fetchone()["s"]
        x.close()
        ukuran = os.path.getsize(_db_bot()) if os.path.isfile(_db_bot()) else 0
        return ("user: %d | akun terjual: %d | deposit: %d | total saldo: %s | ukuran db: %.1f KB"
                % (u, p, d, S.rupiah(s), ukuran / 1024.0))
    except Exception as e:
        return "tidak bisa dibaca: %s" % e


# ---------------- restore ----------------
# berkas yang WAJIB ada di dalam zip backup (kalau tidak, restore ditolak)
WAJIB_BACKUP = [
    "usr/bin/kyt/database.db",
    "etc/xray/config.json",
    "etc/passwd",
]


def cek_backup(path_zip):
    """Periksa isi zip backup sebelum dipulihkan.
    Return (ok, pesan, daftar_file_penting)."""
    if not os.path.isfile(path_zip):
        return False, "File tidak ditemukan.", []
    try:
        with zipfile.ZipFile(path_zip) as z:
            nama = z.namelist()
    except Exception as e:
        return False, "Zip rusak / tidak bisa dibuka: %s" % e, []
    if not nama:
        return False, "Zip kosong.", []

    ada = set(nama)
    hilang = [w for w in WAJIB_BACKUP if w not in ada]
    penting = [n for n in nama if n in (
        "usr/bin/kyt/database.db", "etc/xray/config.json", "etc/passwd",
        "etc/shadow", "etc/vmess/.vmess.db", "etc/vless/.vless.db",
        "etc/trojan/.trojan.db", "etc/shadowsocks/.shadowsocks.db",
        "etc/l2tp/.l2tp.db", "etc/ppp/chap-secrets", "etc/ipsec.secrets",
        "etc/xray/xray.crt", "etc/haproxy/hap.pem",
    )]
    if hilang:
        return False, ("Backup tidak lengkap. Tidak ada: %s"
                       % ", ".join(hilang)), penting
    return True, "Backup lengkap (%d file)." % len(nama), penting


# geoip/geosite TIDAK di-backup (besar), tapi DIBUTUHKAN Xray.
# Kalau hilang (VPS baru), unduh ulang otomatis.
GEO = [
    ("/usr/local/share/xray/geoip.dat",
     "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geoip.dat"),
    ("/usr/local/share/xray/geosite.dat",
     "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat"),
]


def pastikan_geo():
    """Pastikan geoip.dat & geosite.dat ada. Return (ok, pesan)."""
    kurang = [(p, u) for p, u in GEO if not os.path.isfile(p)]
    if not kurang:
        return True, ""
    gagal = []
    for path, url in kurang:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            r = requests.get(url, timeout=180, stream=True,
                             headers={"User-Agent": "Mozilla/5.0"})
            if r.status_code == 200 and r.content and len(r.content) > 100000:
                with open(path, "wb") as f:
                    f.write(r.content)
                logging.info("geo diunduh: %s (%.1f MB)",
                             path, len(r.content) / 1048576.0)
            else:
                gagal.append(os.path.basename(path))
        except Exception as e:
            logging.error("unduh %s gagal: %s", path, e)
            gagal.append(os.path.basename(path))
    if gagal:
        return False, ("geoip/geosite belum ada: %s.\n"
                       "Jalankan installer panel (premi.sh) atau unduh manual:\n"
                       "`wget -O /usr/local/share/xray/geoip.dat %s`"
                       % (", ".join(gagal), GEO[0][1]))
    return True, "geoip/geosite diunduh ulang."


def restore_vps(path_zip):
    """Terapkan isi file zip ke sistem. Return (ok, pesan)."""
    ok_cek, pesan_cek, _p = cek_backup(path_zip)
    if not ok_cek:
        return False, pesan_cek

    tmp = tempfile.mkdtemp(prefix="kytrestore-")
    try:
        with zipfile.ZipFile(path_zip) as z:
            z.extractall(tmp)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return False, "Zip rusak / tidak bisa dibuka: %s" % e

    # ---- cadangkan berkas sistem yang sekarang (jaring pengaman) ----
    cadangan = "/root/backup/sebelum-restore-%s" % DT.datetime.now().strftime("%Y%m%d-%H%M%S")
    for f in ("/etc/passwd", "/etc/shadow", "/etc/group", "/etc/gshadow",
              "/etc/xray/config.json", "/etc/l2tp/.l2tp.db",
              "/etc/ppp/chap-secrets", "/etc/ipsec.secrets"):
        try:
            if os.path.isfile(f):
                os.makedirs(cadangan + os.path.dirname(f), exist_ok=True)
                shutil.copy2(f, cadangan + f)
        except Exception:
            pass
    try:
        if os.path.isfile(_db_bot()):
            shutil.copy2(_db_bot(), _db_bot() + ".sebelum-restore")
    except Exception:
        pass

    dipulihkan, dilewati = 0, 0
    for root, _dirs, files in os.walk(tmp):
        for fn in files:
            src = os.path.join(root, fn)
            arc = os.path.relpath(src, tmp).replace("\\", "/")
            if not _izin(arc):
                dilewati += 1
                continue
            dst = "/" + arc
            try:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                dipulihkan += 1
            except Exception as e:
                logging.error("restore %s: %s", dst, e)
                dilewati += 1
    shutil.rmtree(tmp, ignore_errors=True)

    # ---- jangan sampai root terkunci ----
    try:
        with open("/etc/shadow") as f:
            isi = f.read()
        if not any(l.startswith("root:") for l in isi.splitlines()):
            logging.error("shadow hasil restore tidak punya root -> dibatalkan")
            for f in ("/etc/shadow", "/etc/gshadow"):
                b = cadangan + f
                if os.path.isfile(b):
                    shutil.copy2(b, f)
            return False, ("Restore dibatalkan: file shadow tidak berisi user "
                           "root (bisa mengunci akses VPS).")
    except Exception as e:
        logging.error("cek shadow: %s", e)

    # hak akses penting
    for f, mode in (("/etc/shadow", 0o640), ("/etc/gshadow", 0o640),
                    ("/etc/ipsec.secrets", 0o600),
                    ("/etc/ppp/chap-secrets", 0o600),
                    ("/etc/xray/xray.key", 0o600),
                    ("/etc/haproxy/hap.pem", 0o600)):
        try:
            os.chmod(f, mode)
        except Exception:
            pass

    # pastikan database bot punya tabel lengkap
    try:
        S.init_store()
    except Exception:
        pass

    # geoip/geosite wajib ada untuk Xray (tidak ikut di-backup)
    geo_ok, geo_pesan = pastikan_geo()

    # restart semua service VPN
    gagal_svc = []
    for svc in ("xray", "haproxy", "nginx", "xl2tpd", "ipsec", "kyt"):
        try:
            r = subprocess.run("systemctl restart %s" % svc, shell=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=90)
            if r.returncode not in (0, 5):
                gagal_svc.append(svc)
        except Exception:
            gagal_svc.append(svc)

    pesan = "%d file dipulihkan, %d dilewati.\nCadangan lama: `%s`" % (
        dipulihkan, dilewati, cadangan)
    if geo_pesan:
        pesan += "\n\n" + ("✅ " if geo_ok else "⚠️ ") + geo_pesan
    if gagal_svc:
        pesan += ("\n\n⚠️ Service gagal restart: %s\n"
                  "Cek: `systemctl status %s`"
                  % (", ".join(gagal_svc), gagal_svc[0]))
    else:
        pesan += "\n✅ Semua service VPN sudah di-restart."

    # ringkasan akun hasil restore
    try:
        a = S.hitung_akun_sistem()
        pesan += ("\n\n**Akun terbaca di VPS:**\n"
                  "SSH `%d` | VMess `%d` | VLESS `%d` | Trojan `%d` | SS `%d` | L2TP `%d`"
                  % (a["ssh"], a["vmess"], a["vless"], a["trojan"], a["ss"], a["l2tp"]))
    except Exception:
        pass

    return (dipulihkan > 0, pesan)


def restore_db(path_file):
    """Pulihkan database bot dari file .db atau .zip. Return (ok, pesan)."""
    if not os.path.isfile(path_file):
        return False, "File tidak ditemukan."
    sumber = path_file
    tmp = None

    if zipfile.is_zipfile(path_file):
        tmp = tempfile.mkdtemp(prefix="kytdb-")
        try:
            with zipfile.ZipFile(path_file) as z:
                kandidat = [n for n in z.namelist()
                            if n.endswith("database.db") or n.endswith(".db")]
                if not kandidat:
                    shutil.rmtree(tmp, ignore_errors=True)
                    return False, "Di dalam zip tidak ada file database.db"
                z.extractall(tmp)
            sumber = os.path.join(tmp, kandidat[0])
        except Exception as e:
            shutil.rmtree(tmp, ignore_errors=True)
            return False, "Zip rusak: %s" % e

    # pastikan ini sqlite yang benar
    try:
        with open(sumber, "rb") as f:
            if f.read(16) != b"SQLite format 3\x00":
                if tmp:
                    shutil.rmtree(tmp, ignore_errors=True)
                return False, "Bukan file database SQLite yang sah."
    except Exception as e:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
        return False, "Gagal membaca file: %s" % e

    try:
        if os.path.isfile(_db_bot()):
            shutil.copy2(_db_bot(), _db_bot() + ".sebelum-restore")
        os.makedirs(os.path.dirname(_db_bot()), exist_ok=True)
        shutil.copy2(sumber, _db_bot())
    except Exception as e:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
        return False, "Gagal menulis database: %s" % e
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)

    try:
        S.init_store()      # pastikan tabel & produk lengkap
    except Exception:
        pass
    return True, "Database bot berhasil dipulihkan."


# ---------------- helper kirim/terima file ----------------
async def _kirim_file(chat, path, caption=""):
    try:
        await bot.send_file(chat, path, caption=caption, force_document=True)
        return True
    except Exception as e:
        logging.error("kirim file gagal: %s", e)
        return False


async def _minta_file(event, judul):
    """Tunggu user mengirim file (untuk restore).

    PENTING: pertanyaan dikirim DARI DALAM conversation.
    Kalau dikirim di luar, conv.get_response() error
    "No message was sent previously".
    """
    m = None
    try:
        async with bot.conversation(event.chat_id, exclusive=False,
                                    timeout=300) as conv:
            await conv.send_message(judul)
            m = await conv.get_response(timeout=300)
    except asyncio.TimeoutError:
        await balas(event, "⏱️ Waktu habis. Silakan ulangi dari menu.")
        return None
    except Exception as e:
        logging.error("minta file gagal: %s", e)
        await balas(event, "❌ Gagal menerima file: %s" % e)
        return None
    if m is None:
        return None
    if (m.raw_text or "").strip() == "-":
        await balas(event, "Dibatalkan.")
        return None
    if not getattr(m, "file", None):
        await balas(event, "❌ Itu bukan file. Kirim sebagai **dokumen** (.zip/.db).")
        return None
    nama = getattr(m.file, "name", None) or "upload.bin"
    path = os.path.join("/tmp", "kytupload-%s-%s" % (DT.datetime.now().strftime("%H%M%S"), nama))
    try:
        await m.download_media(path)
    except Exception as e:
        logging.error("download upload gagal: %s", e)
        await balas(event, "❌ Gagal mengunduh file: %s" % e)
        return None
    return path


def _adm_ok(event):
    return valid(str(event.sender_id)) == "true"


# ---------------- menu ----------------
@bot.on(events.CallbackQuery(data=b'backer'))
async def backer(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        ada = len(glob.glob(os.path.join(BACKUP_DIR, "kyt-db-*.db")))
    except Exception:
        ada = 0
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**BACKUP & RESTORE**
━━━━━━━━━━━━━━━━━━━━━━━
Database bot : `{_db_bot()}`
Isi database : {ringkasan()}
Backup db di server : `{ada}` file ({BACKUP_DIR})

**💾 Backup VPS** (1 file .zip) berisi:
  • Akun buyer: SSH, VMess, VLESS, Trojan, Shadowsocks, L2TP/IKEv2
    (passwd, shadow, .vmess.db, .vless.db, .trojan.db,
     .shadowsocks.db, .l2tp.db, chap-secrets, ipsec.secrets)
  • Config: xray, haproxy, nginx, openvpn, dropbear
  • Sertifikat TLS: xray.crt/key, hap.pem, letsencrypt
  • Profil akun (/var/www/html) & /root/akun
  • **Database bot** (saldo, pesanan, deposit, pengaturan)

**💾 Backup Database** = database bot saja (kecil & cepat)

File dikirim ke chat ini, simpan baik-baik.
Kalau pindah VPS: install ulang panel + bot, lalu pakai **Restore**.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("💾 Backup VPS (lengkap)", "bk-vps")],
        [Button.inline("💾 Backup Database Bot", "bk-db"),
         Button.inline("♻️ Restore", "rs-menu")],
        [Button.inline("‹ Store ›", "storeadmin"),
         Button.inline("‹ Main Menu ›", "menu")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'bk-vps'))
async def bk_vps(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await safe_send(event, "⏳ **Membuat backup VPS...**\nMohon tunggu.")
    try:
        path, n = await __import__('asyncio').to_thread(buat_backup_vps)
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    ukuran = os.path.getsize(path) / 1024.0 / 1024.0
    if ukuran < 1:
        besar = "%.0f KB" % (ukuran * 1024)
    else:
        besar = "%.2f MB" % ukuran
    catatan = ""
    if ukuran > 20:
        catatan = ("\n\n⚠️ Ukuran cukup besar. Kalau tidak wajar, cek isi "
                   "/var/www/html atau /etc/openvpn (mungkin ada file besar).")
    elif ukuran < 0.05:
        catatan = "\n\n⚠️ Ukuran sangat kecil — pastikan akun memang belum banyak."
    okk = await _kirim_file(event.chat_id, path,
                            "💾 **BACKUP VPS**\n%d file • %s\n%s\n\n"
                            "Isi: akun buyer (SSH/VMess/VLESS/Trojan/SS/L2TP) + "
                            "config + sertifikat + database bot.\n"
                            "geoip/geosite TIDAK ikut (bisa diunduh ulang installer).\n\n"
                            "Simpan file ini. Untuk pindah VPS -> menu Restore.%s"
                            % (n, besar, DT.datetime.now().strftime("%d-%m-%Y %H:%M"),
                               catatan))
    try:
        os.remove(path)
    except Exception:
        pass
    if not okk:
        await safe_send(event, "❌ File backup gagal dikirim ke Telegram.",
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])


@bot.on(events.CallbackQuery(data=b'bk-db'))
async def bk_db(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    try:
        path = await __import__('asyncio').to_thread(buat_backup_db)
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    if not path:
        await safe_send(event, "❌ Database bot belum ada.",
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    okk = await _kirim_file(event.chat_id, path,
                            "💾 **BACKUP DATABASE BOT**\n%s\n\n"
                            "Berisi: saldo user, riwayat pesanan, deposit, pengaturan."
                            % DT.datetime.now().strftime("%d-%m-%Y %H:%M"))
    if not okk:
        await safe_send(event, "❌ File gagal dikirim.",
                        buttons=[[Button.inline("‹ Backup ›", "backer")]])


@bot.on(events.CallbackQuery(data=b'rs-menu'))
async def rs_menu(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    teks = """
━━━━━━━━━━━━━━━━━━━━━━━
**RESTORE**
━━━━━━━━━━━━━━━━━━━━━━━
Kirim **file** hasil backup ke bot ini (dokumen .zip / .db),
bot akan memulihkannya otomatis.

⚠️ Data yang sekarang akan DITIMPA.
   (database bot yang sekarang tetap disimpan sebagai
    `database.db.sebelum-restore`)
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("♻️ Restore VPS (zip)", "rs-vps")],
        [Button.inline("♻️ Restore Database Bot", "rs-db")],
        [Button.inline("‹ Backup ›", "backer")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'rs-vps'))
async def rs_vps(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    path = await _minta_file(event,
                             "📤 **Kirim file backup VPS (.zip)** ke chat ini.\n"
                             "Kirim `-` untuk batal.")
    if not path:
        await balas(event, "❌ Tidak ada file yang diterima.",
                    buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return

    # ---- periksa dulu isi backup ----
    ok_cek, pesan_cek, penting = await __import__('asyncio').to_thread(cek_backup, path)
    if not ok_cek:
        try:
            os.remove(path)
        except Exception:
            pass
        await balas(event, "❌ **Backup ditolak.**\n\n%s" % pesan_cek,
                    buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return

    rinci = "\n".join("  • `%s`" % x for x in penting[:12])
    await balas(event,
                "✅ **Backup valid**\n%s\n\n**Isi penting:**\n%s\n\n"
                "⚠️ Data yang sekarang akan DITIMPA.\n"
                "Cadangan otomatis dibuat di `/root/backup/sebelum-restore-*`.\n\n"
                "Lanjutkan restore?" % (pesan_cek, rinci),
                buttons=[[Button.inline("✅ Ya, Restore Sekarang", "rs-vps-go-%s" % os.path.basename(path))],
                         [Button.inline("‹ Batal ›", "backer")]])


@bot.on(events.CallbackQuery(pattern=r'^rs-vps-go-'))
async def rs_vps_go(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    nama = event.data.decode().replace("rs-vps-go-", "")
    path = os.path.join("/tmp", nama)
    if not os.path.isfile(path):
        await event.answer("File sudah tidak ada. Ulangi dari menu.", alert=True)
        return
    await balas(event, "⏳ **Memulihkan...** mohon tunggu (bisa 1-2 menit).")
    okk, pesan = await __import__('asyncio').to_thread(restore_vps, path)
    try:
        os.remove(path)
    except Exception:
        pass
    await balas(event,
                ("✅ **RESTORE SELESAI**\n\n%s" % pesan) if okk
                else ("❌ **GAGAL:** %s" % pesan),
                buttons=[[Button.inline("🔄 Hitung Ulang Akun", "sa-stat"),
                          Button.inline("‹ Backup ›", "backer")]])


@bot.on(events.CallbackQuery(data=b'rs-db'))
async def rs_db(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    path = await _minta_file(event,
                             "📤 **Kirim file database bot** (.db atau .zip) ke chat ini.\n"
                             "Kirim `-` untuk batal.")
    if not path:
        await event.reply("❌ Tidak ada file yang diterima.",
                          buttons=[[Button.inline("‹ Backup ›", "backer")]])
        return
    okk, pesan = await __import__('asyncio').to_thread(restore_db, path)
    try:
        os.remove(path)
    except Exception:
        pass
    await safe_send(event,
                    ("✅ **RESTORE DATABASE SELESAI**\n%s\n\nIsi sekarang:\n%s"
                     % (pesan, ringkasan())) if okk else ("❌ **GAGAL:** %s" % pesan),
                    buttons=[[Button.inline("‹ Backup ›", "backer")]])
