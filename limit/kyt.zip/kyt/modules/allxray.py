# -*- coding: utf-8 -*-
# ============================================================
#  modules/allxray.py - MENU "ALL XRAY"
#
#  Satu kali input -> VMess, VLESS, Trojan, Shadowsocks, L2TP/IKEv2
#  dibuat otomatis dengan username & masa aktif yang SAMA.
#  Menggunakan S.buat_allxray() yang memanggil /usr/local/sbin/add-allxray
#  (sudah dilengkapi grep shim sehingga tidak bentrok antar-protokol).
# ============================================================
from kyt import *
from kyt import store_lib as S

URUTAN = [
    ("vmess", "VMess"),
    ("vless", "VLESS"),
    ("trojan", "Trojan"),
    ("ss", "Shadowsocks"),
    ("l2tp", "L2TP / IKEv2"),
]


def _teks_menu():
    baris = "\n".join("   • %s" % nama for _t, nama in URUTAN)
    dom = S.cfg("DOMAIN", "") or "-"
    return """
━━━━━━━━━━━━━━━━━━━━━━━
**ALL XRAY — BUAT SEMUA AKUN**
━━━━━━━━━━━━━━━━━━━━━━━
Satu kali input, akun berikut dibuat otomatis
dengan username & masa aktif yang SAMA:

%s

━━━━━━━━━━━━━━━━━━━━━━━
Hostname : `%s`
━━━━━━━━━━━━━━━━━━━━━━━
""" % (baris, dom)


# ============================================================
#  MENU
# ============================================================
@bot.on(events.CallbackQuery(data=b'allxray'))
async def menu_allxray(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    inline = [
        [Button.inline("🚀 BUAT SEMUA SEKARANG", "allxray-create")],
        [Button.inline("‹ Main Menu ›", "menu")]]
    await safe_send(event, _teks_menu(), inline)


# ============================================================
#  BUAT SEMUA
# ============================================================
@bot.on(events.CallbackQuery(data=b'allxray-create'))
async def create_allxray(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    chat = event.chat_id
    sender = await event.get_sender()
    uid = sender.id

    user = await tanya_admin(event, "**Username (sama untuk semua akun):**", chat, uid)
    if not user:
        return
    user = user.strip().lower()
    ok_u, msg_u = cek_username(user)
    if not ok_u:
        await event.respond("❌ %s" % msg_u)
        return

    # Cek apakah username sudah ada di salah satu protokol
    ada = []
    for tipe, nama in URUTAN:
        try:
            if S._akun_ada(tipe, user):
                ada.append(nama)
        except Exception:
            pass
    if ada:
        await balas(event,
                    "⚠️ Username `%s` **sudah ada** di:\n%s\n\n"
                    "Pakai username lain supaya tidak bentrok."
                    % (user, "\n".join("   • " + x for x in ada)),
                    buttons=[[Button.inline("‹ All Xray ›", "allxray")]])
        return

    pw = await tanya_admin(event, "**Password L2TP** — ketik `-` untuk otomatis:", chat, uid)
    if pw is None:
        return
    pw = pw.strip()
    if pw in ("", "-", "auto"):
        pw = S._rand(8)

    quota = await tanya_admin(event, "**Quota (GB)** — isi `0` untuk unlimited:", chat, uid)
    if quota is None:
        return
    quota = quota.strip().replace(".", "").replace(",", "")
    if not quota.isdigit():
        await event.respond("❌ Harus angka.")
        return

    iplimit = await tanya_admin(event, "**Limit IP** — isi `0` untuk unlimited:", chat, uid)
    if iplimit is None:
        return
    iplimit = iplimit.strip().replace(".", "").replace(",", "")
    if not iplimit.isdigit():
        await event.respond("❌ Harus angka.")
        return

    exp = await hari_admin(event, chat, "**Pilih Masa Aktif (untuk SEMUA akun)**")
    if not exp:
        return

    await balas(event,
                "⏳ **Membuat SEMUA akun Xray & L2TP...**\n"
                "Username: `%s` • %s hari • Quota %s GB\n\n"
                "Mohon tunggu ~15 detik..."
                % (user, exp, quota))

    berhasil, gagal, out, links_dict, psk = await asyncio.to_thread(
        S.buat_allxray, user, pw, exp, quota, iplimit)

    # Bila semua gagal
    if not berhasil:
        await balas(event,
                    "❌ **Gagal membuat akun All Xray.**\n\n```\n%s\n```"
                    % (out or "")[-400:],
                    buttons=[[Button.inline("‹ All Xray ›", "allxray")]])
        return

    # Format detail seragam dibagi 2 bagian agar tidak ditolak Telegram (> 4096 char)
    part1, part2 = S.detail_allxray_parts(user, pw, exp, quota, iplimit, links_dict, psk)

    if gagal:
        catatan = "\n\n⚠️ **Catatan gagal:** %s" % ", ".join(gagal)
        tombol = [
            [Button.inline("🗑️ Hapus Yang Berhasil", "allxray-undo-%s" % user)],
            [Button.inline("‹ All Xray ›", "allxray"),
             Button.inline("‹ Main Menu ›", "menu")]]
    else:
        catatan = ""
        tombol = [[Button.inline("‹ All Xray ›", "allxray"),
                   Button.inline("‹ Main Menu ›", "menu")]]

    # Kirim Bagian 1 (VMess & VLESS) — tanpa judul ganda di luar blok code
    await balas(event, "```\n" + part1 + "\n```")
    await asyncio.sleep(0.5)
    # Kirim Bagian 2 (Trojan, SS, L2TP, OpenClash) beserta tombol menu
    await balas(event, "```\n" + part2 + "\n```" + catatan,
                buttons=tombol)


# ============================================================
#  BATAL / HAPUS yang tadi dibuat (kalau sebagian gagal / mau dibatalkan)
# ============================================================
@bot.on(events.CallbackQuery(pattern=r'^allxray-undo-'))
async def undo_allxray(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    user = event.data.decode().replace("allxray-undo-", "").strip().lower()
    if not user:
        await event.answer("Username kosong.", alert=True)
        return

    await balas(event,
                "⚠️ **HAPUS SEMUA AKUN %s?**\n\n"
                "Yang dihapus: %s\n"
                "Tindakan ini tidak bisa dibatalkan."
                % (user, ", ".join(n for _t, n in URUTAN)),
                buttons=[[Button.inline("✅ Ya, Hapus Semua",
                                        "allxray-undo-go-%s" % user)],
                         [Button.inline("‹ Batal ›", "allxray")]])


@bot.on(events.CallbackQuery(pattern=r'^allxray-undo-go-'))
async def undo_allxray_go(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    user = event.data.decode().replace("allxray-undo-go-", "").strip().lower()

    dihapus, sisa = [], []
    for tipe, nama in URUTAN:
        try:
            if not S._akun_ada(tipe, user):
                continue
            await asyncio.to_thread(S._hapus_akun, tipe, user)
            if S._akun_ada(tipe, user):
                sisa.append(nama)
            else:
                dihapus.append(nama)
        except Exception as e:
            logging.error("undo allxray %s: %s", tipe, repr(e))
            sisa.append(nama)

    pesan = "🗑️ **Dihapus:** %s" % (", ".join(dihapus) or "-")
    if sisa:
        pesan += "\n⚠️ **Masih ada (cek manual):** %s" % ", ".join(sisa)
    await balas(event, pesan,
                buttons=[[Button.inline("‹ All Xray ›", "allxray"),
                          Button.inline("‹ Main Menu ›", "menu")]])
