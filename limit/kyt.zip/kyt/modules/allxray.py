# -*- coding: utf-8 -*-
# ============================================================
#  modules/allxray.py - MENU "ALL XRAY"
#
#  Tujuan: sekali input -> SEMUA akun xray dibuat otomatis
#  dengan username + masa aktif + quota yang SAMA:
#      VMess, VLESS, Trojan, Shadowsocks, L2TP/IKEv2
#
#  PENTING: modul ini TIDAK mengubah fungsi akun yang sudah ada.
#  Dia hanya MEMANGGIL fungsi yang sudah terbukti:
#      S.buat_akun(tipe, user, hari, quota, iplimit, password)
#      S.buat_l2tp(user, password, hari)
#      S.ambil_link(out) / S.link_berlabel(...)
#      S.detail_l2tp(user, pw) / S._l2tp_psk()
#      S._hapus_akun(tipe, user)      (untuk batal kalau gagal)
#  Jadi pembuatan akun single (menu lama) tetap 100% sama.
# ============================================================
from kyt import *
from kyt import store_lib as S

# Urutan pembuatan + label yang dipakai di ringkasan
URUTAN = [
    ("vmess", "VMess"),
    ("vless", "VLESS"),
    ("trojan", "Trojan"),
    ("ss", "Shadowsocks"),
    ("l2tp", "L2TP / IKEv2"),
]


def _teks_menu():
    baris = "\n".join("   • %s" % nama for _t, nama in URUTAN)
    return """
━━━━━━━━━━━━━━━━━━━━━━━
**ALL XRAY — BUAT SEMUA AKUN**
━━━━━━━━━━━━━━━━━━━━━━━
Satu kali input, akun berikut dibuat otomatis
dengan username & masa aktif yang SAMA:

%s

━━━━━━━━━━━━━━━━━━━━━━━
Hostname : `%s`
━━━━━━━━━━━━━━━━━━━━━━━
""" % (baris, S.cfg("DOMAIN", "-"))


def _ringkasan_berhasil(hasil, user, pw, hari, quota):
    """Bikin kartu akun gabungan dari hasil pembuatan."""
    exp = DT.date.today() + DT.timedelta(days=int(hari))
    bagian = []

    # ---- xray (link) ----
    for tipe in ("vmess", "vless", "trojan", "ss"):
        if tipe not in hasil or not hasil[tipe][0]:
            continue
        out = hasil[tipe][1] or ""
        links = S.ambil_link(out, berlabel=False)
        label = dict(URUTAN).get(tipe, tipe)
        bagian.append("▸ **%s**" % label)
        if links:
            for l in links:
                bagian.append("`%s`" % l)
        else:
            bagian.append("(akun dibuat, link tidak terbaca dari script)")
        bagian.append("")

    # ---- L2TP (username/password) ----
    if "l2tp" in hasil and hasil["l2tp"][0]:
        psk = S._l2tp_psk() or "(lihat di panel)"
        bagian.append("▸ **L2TP / IKEv2**")
        bagian.append("Username : `%s`" % user)
        bagian.append("Password : `%s`" % pw)
        bagian.append("IPSec PSK: `%s`" % psk)
        bagian.append("Port     : 1701 / 500 / 4500 (UDP)")
        bagian.append("")

    return """**ALL XRAY ACCOUNT**
```
━━━━━━━━━━━━━━━━━━━━━━━
Username      : %s
Password      : %s
Host          : %s
Quota         : %s GB
Expired       : %s
━━━━━━━━━━━━━━━━━━━━━━━
```
%s""" % (user, pw, S.cfg("DOMAIN", "-"), quota,
         exp.strftime("%d %b %Y"), "\n".join(bagian))


# ============================================================
#  MENU
# ============================================================
@bot.on(events.CallbackQuery(data=b'allxray'))
async def menu_allxray(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    inline = [
        [Button.inline("🚀 BUAT SEMUA SEKARANG", "allxray-create")],
        [Button.inline("‹ Main Menu ›", "menu")]]
    await safe_send(event, _teks_menu(), inline)


# ============================================================
#  BUAT SEMUA
# ============================================================
@bot.on(events.CallbackQuery(data=b'allxray-create'))
async def create_allxray(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    user = await tanya(event, "**Username (dipakai untuk SEMUA akun):**",
                       validasi=cek_username)
    if not user:
        return
    user = user.strip().lower()

    # kalau sudah ada, tanya dulu (jangan timpa tanpa sadar)
    ada = []
    for tipe, nama in URUTAN:
        try:
            if S._akun_ada(tipe, user):
                ada.append(nama)
        except Exception:
            pass
    if ada:
        await balas(event,
                    "⚠️ Username `%s` **sudah ada** di:\n%s\n\n"
                    "Pakai username lain supaya tidak bentrok."
                    % (user, "\n".join("   • " + x for x in ada)),
                    buttons=[[Button.inline("‹ All Xray ›", "allxray")]])
        return

    pw = await tanya(event, "**Password (untuk L2TP):**\n"
                            "Ketik `auto` atau `-` untuk dibuatkan otomatis.",
                       pakai_strip=False)
    if pw is None:
        return
    pw = pw.strip()
    if pw in ("", "-", "auto"):
        pw = S._rand(8)

    quota = await tanya(event, "**Quota (GB)** — isi `0` untuk unlimited:",
                        validasi=cek_angka)
    if quota is None:
        return
    quota = quota.strip().replace(".", "").replace(",", "")

    hari = await pilih_hari(event, "**Pilih Masa Aktif (untuk SEMUA akun)**")
    if not hari:
        return

    # ---- info awal ----
    await balas(event,
                "⏳ **Membuat %d akun sekaligus...**\n"
                "Username: `%s` • %s hari • Quota %s GB\n\n"
                "Mohon tunggu, jangan kirim apa pun dulu."
                % (len(URUTAN), user, hari, quota))

    hasil = {}          # tipe -> (ok, out)
    gagal = []

    # ---- buat satu per satu (pakai fungsi yang SUDAH ADA) ----
    for tipe, nama in URUTAN:
        try:
            if tipe == "l2tp":
                ok, out = await asyncio.to_thread(S.buat_l2tp, user, pw, hari)
            else:
                ok, out = await asyncio.to_thread(
                    S.buat_akun, tipe, user, hari, quota, "0", pw)
        except Exception as e:
            logging.error("allxray %s: %s\n%s", tipe, repr(e),
                          __import__("traceback").format_exc())
            ok, out = False, "%s: %s" % (type(e).__name__, e)

        # verifikasi (jangan percaya begitu saja)
        try:
            benar = S._akun_ada(tipe, user)
        except Exception:
            benar = ok
        if not ok or not benar:
            gagal.append(nama)
            logging.error("allxray gagal %s: %s", tipe, (out or "")[:200])
        hasil[tipe] = (bool(ok and benar), out or "")

        # kabar progres
        try:
            await bot.send_message(event.chat_id, "• %s ... %s"
                                   % (nama, "OK" if hasil[tipe][0] else "GAGAL"))
        except Exception:
            pass

    berhasil = [dict(URUTAN)[t] for t in hasil if hasil[t][0]]

    # ---- semua gagal ----
    if not berhasil:
        detail = "\n".join("• %s: %s" % (dict(URUTAN)[t],
                                         (hasil[t][1] or "-")[-160:].replace("\n", " "))
                           for t in hasil)
        await balas(event,
                    "❌ **SEMUA GAGAL dibuat.**\n\n"
                    "Username: `%s`\n\n```\n%s\n```" % (user, detail),
                    buttons=[[Button.inline("‹ All Xray ›", "allxray")]])
        return

    # ---- sebagian gagal ----
    if gagal:
        catatan = ("\n\n⚠️ **Gagal:** %s\n"
                   "Akun yang berhasil TETAP ada. Cek di VPS kalau perlu."
                   % ", ".join(gagal))
        tombol = [
            [Button.inline("🗑️ Hapus Yang Berhasil", "allxray-undo-%s" % user)],
            [Button.inline("‹ All Xray ›", "allxray"),
             Button.inline("‹ Main Menu ›", "menu")]]
    else:
        catatan = "\n\n✅ Semua %d akun berhasil dibuat." % len(berhasil)
        tombol = [[Button.inline("‹ All Xray ›", "allxray"),
                   Button.inline("‹ Main Menu ›", "menu")]]

    await balas(event, _ringkasan_berhasil(hasil, user, pw, hari, quota) + catatan,
                buttons=tombol)


# ============================================================
#  BATAL / HAPUS yang tadi dibuat (kalau sebagian gagal)
# ============================================================
@bot.on(events.CallbackQuery(pattern=r'^allxray-undo-'))
async def undo_allxray(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    user = event.data.decode().replace("allxray-undo-", "").strip().lower()
    if not user:
        await event.answer("Username kosong.", alert=True)
        return

    await balas(event,
                "⚠️ **HAPUS SEMUA AKUN %s?**\n\n"
                "Yang dihapus: %s\n"
                "Tindakan ini tidak bisa dibatalkan."
                % (user, ", ".join(n for _t, n in URUTAN)),
                buttons=[[Button.inline("✅ Ya, Hapus Semua",
                                        "allxray-undo-go-%s" % user)],
                         [Button.inline("‹ Batal ›", "allxray")]])


@bot.on(events.CallbackQuery(pattern=r'^allxray-undo-go-'))
async def undo_allxray_go(event):
    if valid(str(event.sender_id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    user = event.data.decode().replace("allxray-undo-go-", "").strip().lower()

    dihapus, sisa = [], []
    for tipe, nama in URUTAN:
        try:
            if not S._akun_ada(tipe, user):
                continue
            await asyncio.to_thread(S._hapus_akun, tipe, user)
            if S._akun_ada(tipe, user):
                sisa.append(nama)
            else:
                dihapus.append(nama)
        except Exception as e:
            logging.error("undo allxray %s: %s", tipe, repr(e))
            sisa.append(nama)

    pesan = "🗑️ **Dihapus:** %s" % (", ".join(dihapus) or "-")
    if sisa:
        pesan += "\n⚠️ **Masih ada (cek manual):** %s" % ", ".join(sisa)
    await balas(event, pesan,
                buttons=[[Button.inline("‹ All Xray ›", "allxray"),
                          Button.inline("‹ Main Menu ›", "menu")]])
