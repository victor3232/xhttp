# -*- coding: utf-8 -*-
# ============================================================
#  modules/store.py - menu & pembelian untuk PELANGGAN (non-admin)
# ============================================================
from kyt import *
from kyt import store_lib as S


# ---------- helper tampilan ----------
def _menu_teks(u):
    return f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🛒 VPN STORE**
━━━━━━━━━━━━━━━━━━━━━━━
👤 **Akun  :** `{u['nama'] or u['user_id']}`
💰 **Saldo :** `{S.rupiah(u['saldo'])}`
━━━━━━━━━━━━━━━━━━━━━━━
Silakan pilih menu 👇
"""


def _menu_buttons():
    return [
        [Button.inline("🛍️ Beli Akun", "store-beli")],
        [Button.inline("💰 Deposit", "depo"),
         Button.inline("🧾 Riwayat", "store-riwayat")],
        [Button.inline("📄 Akun Saya", "store-akun"),
         Button.inline("❓ Bantuan", "store-bantu")],
    ]


async def kirim_menu_store(event, edit=False):
    sender = await event.get_sender()
    nama = getattr(sender, "first_name", "") or ""
    u = S.get_or_create_user(event.sender_id, getattr(sender, "username", "") or "", nama)
    teks = _menu_teks(u)
    if edit:
        try:
            await safe_send(event, teks, buttons=_menu_buttons())
            return
        except Exception:
            pass
    await event.reply(teks, buttons=_menu_buttons())


def _pesan_akun(p):
    head = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**✅ AKUN AKTIF**
━━━━━━━━━━━━━━━━━━━━━━━
📦 **Paket   :** `{p['nama_produk']}`
🗓️ **Expired :** `{p['expired']}`
🧾 **Order   :** `{p['order_id']}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    d = (p["detail"] or "").strip()
    if p["tipe"] in ("vmess", "vless", "trojan", "ss"):
        body = "**🔗 Link akun:**\n"
        for l in d.split("\n"):
            if l.strip():
                body += "\n`%s`\n" % l.strip()
    else:
        body = "```\n%s\n```" % d
    return head + body + "\n━━━━━━━━━━━━━━━━━━━━━━━\n🤖 **VPN STORE**"


# ---------- menu utama ----------
@bot.on(events.CallbackQuery(data=b'store'))
async def store_home(event):
    await kirim_menu_store(event, edit=True)


@bot.on(events.CallbackQuery(data=b'store-bantu'))
async def store_bantu(event):
    dom = S.cfg("DOMAIN", "-")
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**❓ BANTUAN**
━━━━━━━━━━━━━━━━━━━━━━━
1️⃣ **Deposit** dulu: menu 💰 Deposit → pilih nominal → pilih metode → bayar.
2️⃣ Saldo otomatis masuk setelah pembayaran terdeteksi (otomatis dicek tiap ±20 detik).
3️⃣ **Beli Akun** → pilih tipe & paket → akun langsung dibuat.
4️⃣ Lihat akun di menu 📄 **Akun Saya**.
━━━━━━━━━━━━━━━━━━━━━━━
🌐 Domain : `{dom}`
💬 Kalau saldo tidak masuk >10 menit, hubungi admin.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[[Button.inline("‹ Menu Utama ›", "store")]])


# ---------- beli akun ----------
@bot.on(events.CallbackQuery(data=b'store-beli'))
async def store_beli(event):
    tipe_ada = S.produk_tipe_tersedia()
    if not tipe_ada:
        await event.answer("Belum ada produk tersedia.", alert=True)
        return
    rows, buf = [], []
    for t in tipe_ada:
        buf.append(Button.inline(S.TIPE_LABEL.get(t, t), "store-tipe-%s" % t))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    teks = """
━━━━━━━━━━━━━━━━━━━━━━━
**🛍️ BELI AKUN**
━━━━━━━━━━━━━━━━━━━━━━━
Pilih jenis akun yang mau dibeli 👇
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-tipe-'))
async def store_tipe(event):
    tipe = event.data.decode().replace("store-tipe-", "")
    prods = S.produk_by_tipe(tipe)
    if not prods:
        await event.answer("Produk kosong.", alert=True)
        return
    rows = []
    for p in prods:
        rows.append([Button.inline("%s — %s" % (p["nama"], S.rupiah(p["harga"])),
                                   "store-buy-%s" % p["kode"])])
    rows.append([Button.inline("‹ Kembali ›", "store-beli")])
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🛍️ {S.TIPE_LABEL.get(tipe, tipe).upper()}**
━━━━━━━━━━━━━━━━━━━━━━━
Pilih paket 👇
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-buy-'))
async def store_buy(event):
    kode = event.data.decode().replace("store-buy-", "")
    p = S.produk_by_kode(kode)
    if not p:
        await event.answer("Produk tidak ditemukan.", alert=True)
        return
    u = S.get_user(event.sender_id)
    saldo = u["saldo"] if u else 0
    cukup = saldo >= p["harga"]
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🧾 KONFIRMASI PEMBELIAN**
━━━━━━━━━━━━━━━━━━━━━━━
📦 **Paket    :** `{p['nama']}`
🗓️ **Masa     :** `{p['hari']} hari`
💵 **Harga    :** `{S.rupiah(p['harga'])}`
💰 **Saldo    :** `{S.rupiah(saldo)}`
━━━━━━━━━━━━━━━━━━━━━━━
{'✅ Saldo cukup, lanjutkan?' if cukup else '❌ Saldo kurang. Silakan deposit dulu.'}
"""
    rows = []
    if cukup:
        rows.append([Button.inline("✅ Beli Sekarang", "store-buyok-%s" % kode)])
    else:
        rows.append([Button.inline("💰 Deposit Sekarang", "depo")])
    rows.append([Button.inline("‹ Kembali ›", "store-tipe-%s" % p["tipe"])])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-buyok-'))
async def store_buyok(event):
    kode = event.data.decode().replace("store-buyok-", "")
    p = S.produk_by_kode(kode)
    if not p:
        await event.answer("Produk tidak ditemukan.", alert=True)
        return
    u = S.get_or_create_user(event.sender_id)
    if u["saldo"] < p["harga"]:
        await event.answer("Saldo kurang.", alert=True)
        return
    if not S.saldo_kurang(event.sender_id, p["harga"]):
        await event.answer("Gagal potong saldo (saldo kurang).", alert=True)
        return

    await safe_send(event, "⏳ **Membuat akun...**\nMohon tunggu sebentar.")
    user = S.buat_username(p["tipe"])
    order_id = "TRX-%s-%s" % (DT.datetime.now().strftime("%y%m%d%H%M%S"), S._rand(3))
    pw = S._rand(8)
    ok, out = S.buat_akun(p["tipe"], user, p["hari"], p["quota"], p["iplimit"], pw)

    if not ok:
        S.saldo_tambah(event.sender_id, p["harga"])
        await safe_send(event, 
            "❌ **Gagal membuat akun.**\nSaldo dikembalikan.\n\n```\n%s\n```" % (out or "")[-800:],
            buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return

    if p["tipe"] in ("ssh", "ovpn"):
        detail = S.detail_ssh(user, pw)
    elif p["tipe"] == "l2tp":
        detail = S.detail_l2tp(user, pw)
    else:
        detail = "\n".join(S.ambil_link(out))

    exp = (DT.date.today() + DT.timedelta(days=int(p["hari"]))).strftime("%d %b %Y")
    S.pesanan_baru(order_id, event.sender_id, p, user, pw, detail, exp)
    row = S.db().execute("SELECT * FROM pesanan WHERE order_id=?", (order_id,)).fetchone()

    await safe_send(event, _pesan_akun(row), buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
    # notifikasi ke admin
    try:
        admin = S.admin_id()
        u2 = S.get_user(event.sender_id)
        if admin:
            await bot.send_message(int(admin),
                "🛒 **PENJUALAN BARU**\n\n"
                "👤 User : `%s`\n📦 Paket : `%s`\n💵 Harga : `%s`\n🆔 Order : `%s`\n"
                "🧾 Akun : `%s`\n💰 Sisa saldo user: `%s`" % (
                    event.sender_id, p["nama"], S.rupiah(p["harga"]), order_id,
                    user, S.rupiah(u2["saldo"] if u2 else 0)))
    except Exception:
        pass


# ---------- riwayat & akun ----------
@bot.on(events.CallbackQuery(data=b'store-riwayat'))
async def store_riwayat(event):
    ps = S.pesanan_user(event.sender_id, 10)
    dep = S.deposit_riwayat(event.sender_id, 5)
    teks = "━━━━━━━━━━━━━━━━━━━━━━━\n**🧾 RIWAYAT**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
    teks += "**— Pembelian —**\n"
    if not ps:
        teks += "_belum ada_\n"
    for p in ps:
        teks += "• `%s` — %s (%s)\n" % (p["akun"], p["nama_produk"], p["created"])
    teks += "\n**— Deposit —**\n"
    if not dep:
        teks += "_belum ada_\n"
    for d in dep:
        icon = {"PAID": "✅", "PENDING": "⏳", "EXPIRED": "⌛", "FAILED": "❌"}.get(d["status"], "•")
        teks += "%s %s — %s\n" % (icon, S.rupiah(d["amount"]), d["status"])
    teks += "━━━━━━━━━━━━━━━━━━━━━━━"
    await safe_send(event, teks, buttons=[[Button.inline("‹ Menu Utama ›", "store")]])


@bot.on(events.CallbackQuery(data=b'store-akun'))
async def store_akun(event):
    ps = S.pesanan_user(event.sender_id, 10)
    if not ps:
        await safe_send(event, "📄 **Belum ada akun.**\nSilakan beli akun dulu.",
                         buttons=[[Button.inline("🛍️ Beli Akun", "store-beli")],
                                  [Button.inline("‹ Menu Utama ›", "store")]])
        return
    rows = []
    for p in ps:
        rows.append([Button.inline("%s — %s" % (p["akun"], p["nama_produk"]), "store-det-%s" % p["id"])])
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    await safe_send(event, "━━━━━━━━━━━━━━━━━━━━━━━\n**📄 AKUN SAYA**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
                     "Pilih akun untuk lihat detail 👇",
                     buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-det-'))
async def store_det(event):
    pid = event.data.decode().replace("store-det-", "")
    p = S.pesanan_by_id(pid)
    if not p or str(p["user_id"]) != str(event.sender_id):
        await event.answer("Tidak ditemukan.", alert=True)
        return
    await safe_send(event, _pesan_akun(p), buttons=[[Button.inline("‹ Akun Saya ›", "store-akun")]])


# ---------- tombol start untuk pelanggan ----------
@bot.on(events.NewMessage(pattern=r"^/(store|shop|toko)$"))
async def store_cmd(event):
    await kirim_menu_store(event)
