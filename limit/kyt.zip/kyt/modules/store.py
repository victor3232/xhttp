# -*- coding: utf-8 -*-
# ============================================================
#  modules/store.py - menu & pembelian untuk PELANGGAN (non-admin)
# ============================================================
from kyt import *
from kyt import store_lib as S
from kyt import node_lib as N

# ---------- helper multi-server ----------
def _home():
    return N.home_server()

def _sid_order(p):
    try:
        sid = int(p["server_id"] or 0)
    except Exception:
        sid = 0
    if sid <= 0:
        h = _home()
        sid = int(h["id"]) if h else 0
    return sid

def _server_order(p):
    sid = _sid_order(p)
    if sid <= 0:
        return _home()
    return N.server_by_id(sid)

def _label_server(s):
    if not s:
        return "Server"
    return str(s["name"])

def _label_order(p):
    s = _server_order(p)
    if s:
        return _label_server(s)
    try:
        return str(p["server_name"] or "Server dihapus")
    except Exception:
        return "Server dihapus"

def _produk_untuk(sid, tipe, hari):
    """Produk satu server. Harga/limit ikut setting node."""
    try:
        sp = N.server_product(sid, tipe, hari)
    except Exception:
        sp = None
    if sp and int(sp["aktif"] or 0):
        return {
            "kode": "%s-%d" % (tipe, int(hari)),
            "nama": "%s %d Hari" % (S.TIPE_LABEL.get(tipe, tipe), int(hari)),
            "tipe": tipe, "harga": int(sp["harga"]), "hari": int(hari),
            "quota": str(sp["quota"] or "0"), "iplimit": str(sp["iplimit"] or "0"),
        }
    gp = S.produk_by_tipe_hari(tipe, hari)
    if gp and int(gp["aktif"] or 0):
        return {
            "kode": gp["kode"], "nama": gp["nama"], "tipe": gp["tipe"],
            "harga": int(gp["harga"]), "hari": int(gp["hari"]),
            "quota": str(gp["quota"] or "0"), "iplimit": str(gp["iplimit"] or "0"),
        }
    return None

def _server_untuk_tipe(tipe):
    """Server premium yang punya produk aktif untuk tipe ini."""
    out = []
    for s in N.servers(only_active=True):
        if not int(s["premium_enabled"] or 0):
            continue
        prods = [p for p in N.server_products(int(s["id"]), only_active=True)
                 if p["tipe"] == tipe]
        if prods:
            out.append((s, prods))
    return out

def _hari_server(sid, tipe):
    return [p for p in N.server_products(int(sid), only_active=True)
            if p["tipe"] == tipe]

def _username_remote(tipe):
    """Agent node wajib username 8-15 karakter, diawali huruf."""
    pre = {"ssh": "ssh", "vmess": "vm", "vless": "vl", "trojan": "tr"}.get(tipe, "us")
    panjang = 6 if len(pre) + 5 < 8 else 5
    return pre + S._rand(panjang)

# ---------- helper tampilan ----------
def _banner():
    brand = (S.get_setting("store_name", "") or "VPN STORE").strip()[:24]
    sub = "Akun Premium • Multi Server"
    lebar = 30

    def baris(t):
        t = t[:lebar]
        kiri = max(0, (lebar - len(t)) // 2)
        kanan = max(0, lebar - len(t) - kiri)
        return "│" + " " * kiri + t + " " * kanan + "│"

    return "\n".join([
        "┌" + "─" * lebar + "┐",
        baris("⚡ " + brand),
        baris(sub),
        "└" + "─" * lebar + "┘",
    ])

def _batas30():
    return (DT.datetime.now() - DT.timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")

def _stat_server():
    try:
        return sum(1 for s in N.servers(only_active=True) if N.server_online(s))
    except Exception:
        return 0

def _stat_user():
    try:
        x = S.db()
        n = x.execute("SELECT COUNT(*) c FROM store_user").fetchone()["c"]
        x.close()
        return int(n)
    except Exception:
        return 0

def _stat_order30():
    try:
        x = S.db()
        n = x.execute("SELECT COUNT(*) c FROM pesanan WHERE created>=?",
                      (_batas30(),)).fetchone()["c"]
        x.close()
        return int(n)
    except Exception:
        return 0

def _stat_global():
    total = 0
    try:
        for s in N.servers(only_active=True):
            d = N.akun_server(s)
            if not d and not str(s["base_url"] or "").strip():
                try:
                    d = S.jumlah_akun()
                except Exception:
                    d = {}
            for k in ("ssh", "vmess", "vless", "trojan"):
                try:
                    total += int(d.get(k, 0) or 0)
                except Exception:
                    pass
    except Exception:
        pass
    return total

def _stat_top3():
    out = []
    try:
        x = S.db()
        rows = x.execute(
            "SELECT user_id,COUNT(*) n FROM pesanan WHERE created>=? "
            "GROUP BY user_id ORDER BY n DESC LIMIT 3", (_batas30(),)).fetchall()
        x.close()
        for r in rows:
            ur = S.get_user(r["user_id"])
            nama = ""
            if ur:
                nama = (ur["username"] or "").strip()
                if not nama:
                    nama = (ur["nama"] or "").strip()
            out.append((nama or "Tanpa username", int(r["n"])))
    except Exception:
        pass
    return out

def _peringatan(uid):
    expired = 0
    soon = 0
    try:
        for p in S.pesanan_user(uid, 50):
            s = S.sisa_hari(p)
            if s is None:
                continue
            if s < 0:
                expired += 1
            elif s <= 3:
                soon += 1
    except Exception:
        pass
    return expired, soon

def _menu_teks(u):
    uid = u["user_id"]
    uname = (u["username"] or "").strip()
    nama = (u["nama"] or "").strip() or str(uid)
    peran = "🛡️ Admin" if valid(str(uid)) == "true" else "👤 Member"
    expired, soon = _peringatan(uid)

    teks = _banner() + f"""

👋 **{nama}**
🆔 ID      : `{uid}`
🏅 Status  : {peran}
💳 Saldo   : `{S.rupiah(u['saldo'])}`
""" + (("📛 Username: `@" + uname + "`\n") if uname else "") + f"""
▰▰▰ **INFO PANEL** ▰▰▰
🌐 Server aktif : `{_stat_server()}`
👥 Pengguna     : `{_stat_user()}`
📦 Order 30 hari: `{_stat_order30()}`
🌍 Akun global  : `{_stat_global()}`
"""
    if expired or soon:
        teks += "\n▰▰▰ **PERINGATAN** ▰▰▰\n"
        if expired:
            teks += "⚠️ `%d` akun sudah expired\n" % expired
        if soon:
            teks += "⏳ `%d` akun habis dalam ≤3 hari\n" % soon
        teks += "Buka **Akun Saya** untuk perpanjang.\n"

    teks += "\n▰▰▰ **TOP 3 PEMBELI** ▰▰▰\n🏆 30 hari terakhir\n"
    top = _stat_top3()
    if top:
        medal = ("🥇", "🥈", "🥉")
        for i, (nama_top, n) in enumerate(top):
            teks += "%s %s — `%d` akun\n" % (medal[i], nama_top, n)
    else:
        teks += "Belum ada data.\n"

    teks += "\nSilakan pilih menu di bawah 👇"
    return teks

def _menu_buttons():
    rows = [
        [Button.inline("🛍️ Beli Akun", "store-beli"),
         Button.inline("📄 Akun Saya", "store-akun")],
        [Button.inline("💰 Deposit", "depo"),
         Button.inline("📑 Invoice", "store-invoice")],
        [Button.inline("🧾 Riwayat Akun", "store-riwayat")],
    ]
    try:
        aktif = [s for s in N.servers(only_active=True) if N.server_online(s)]
        if len(aktif) > 1:
            rows.append([Button.inline("🌐 Server", "store-server"),
                         Button.inline("❓ Bantuan", "store-bantu")])
        else:
            rows.append([Button.inline("❓ Bantuan", "store-bantu")])
    except Exception:
        rows.append([Button.inline("❓ Bantuan", "store-bantu")])
    return rows


async def _bersih_qr(event):
    """Hapus gambar QRIS yang masih nempel saat user pindah menu."""
    try:
        from kyt.modules.deposit import hapus_qr_pending
        await hapus_qr_pending(event.chat_id, event.sender_id)
    except Exception as e:
        logging.error("bersih qr menu: %s", e)

async def kirim_menu_store(event, edit=False, foto=False):
    sender = await event.get_sender()
    nama = getattr(sender, "first_name", "") or ""
    u = S.get_or_create_user(event.sender_id, getattr(sender, "username", "") or "", nama)
    # Dashboard teks (bukan foto) supaya muat semua info.
    await safe_send(event, _menu_teks(u), _menu_buttons())
    # Kirim menu dulu, baru hapus QR lama (kalau QR adalah pesan yang diklik,
    # menghapusnya lebih dulu bisa membuat balasan menu gagal terkirim).
    await _bersih_qr(event)

def _detail_rapi(d):
    """Rapikan detail akun. Kalau masih link mentah (pesanan lama),
    sekarang diberi label (WS TLS / gRPC / HTTPUpgrade / XHTTP / TCP)."""
    d = (d or "").strip()
    if not d:
        return ""
    if "Link 1 :" in d:
        return d
    if re.search(r"(vmess|vless|trojan|ss)://", d):
        berlabel = S.ambil_link(d)
        if berlabel:
            return "\n".join(berlabel)
    return d


def _pesan_akun(p):
    st = S.status_masa(p)
    body = "\n".join(l.strip() for l in _detail_rapi(p["detail"]).split("\n") if l.strip())
    # Buang output ONERING lama (kalau fitur dimatikan / bug dihapus).
    body = "\n".join(
        l for l in body.splitlines()
        if "ONERING" not in l.upper()
        and "onering:" not in l.lower()
        and "onering%3a" not in l.lower())
    if p["tipe"] in ("vmess", "vless", "trojan"):
        kred = S.uuid_dari_output(p["tipe"], p["detail"])
        if not kred or kred == "-":
            m = re.search(r"(?:UUID|User ID|Password|id)\s*:\s*"
                          r"([0-9a-fA-F][0-9a-fA-F-]{15,})", body)
            kred = m.group(1) if m else ""
        if kred and kred != "-":
            onl = S.onering_links(p["tipe"], p["akun"], kred)
            if onl:
                body += "\n\nBUG SNI / ONERING\n" + "\n".join(
                    "%-16s: %s" % (nama, link) for nama, link in onl)
    judul = S.TIPE_LABEL.get(p["tipe"], p["tipe"]).replace(" / ", "/").upper()
    # SSH & L2TP sudah ada Username/Password di detailnya -> jangan dobel
    akun_baris = "" if p["tipe"] in ("ssh", "ovpn", "l2tp") else \
        "Username     : %s\n" % p["akun"]
    server_baris = "Server       : %s\n" % _label_order(p)
    return (
        "**%s ACCOUNT**\n"
        "```\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "Paket        : %s\n"
        "%s"
        "%s"
        "Expired      : %s\n"
        "Status       : %s\n"
        "Order        : %s\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "%s\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "```"
    ) % (judul, p["nama_produk"], server_baris, akun_baris, p["expired"], st,
         p["order_id"], body)


def _tombol_akun(p, kembali="store-akun"):
    return [
        [Button.inline("🔄 Perpanjang Masa Aktif", "store-renew-%s" % p["id"])],
        [Button.inline("‹ Kembali ›", kembali)],
    ]


def _produk_renew(p, kode):
    """Produk perpanjangan, harga mengikuti server order."""
    pr = S.produk_by_kode(kode)
    if not pr:
        return None
    d = {k: pr[k] for k in pr.keys()}
    sid = _sid_order(p)
    sp = N.server_product(sid, p["tipe"], int(pr["hari"]))
    if sp and int(sp["aktif"] or 0):
        d["harga"] = int(sp["harga"])
        d["quota"] = str(sp["quota"] or "0")
        d["iplimit"] = str(sp["iplimit"] or "0")
    return d

def _tombol_perpanjang(p):
    """Pilihan masa aktif 3/7/30 hari (seragam semua tipe)."""
    rows = []
    for pr in S.produk_by_tipe(p["tipe"]):
        d = _produk_renew(p, pr["kode"]) or pr
        rows.append([Button.inline("🗓️ %d Hari — %s" % (d["hari"], S.rupiah(d["harga"])),
                                   "store-renewok-%s-%s" % (p["id"], pr["kode"]))])
    rows.append([Button.inline("‹ Batal ›", "store-det-%s" % p["id"])])
    st = S.status_masa(p)
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🔄 PERPANJANG MASA AKTIF**
━━━━━━━━━━━━━━━━━━━━━━━
🌐 **Server  :** `{_label_order(p)}`
📦 **Paket   :** `{p['nama_produk']}`
🧾 **Akun    :** `{p['akun']}`
🗓️ **Expired :** `{p['expired']}`
⏱️ **Status  :** `{st}`
💰 **Saldo   :** `{S.rupiah((S.get_user(p['user_id']) or {'saldo': 0})['saldo'])}`
━━━━━━━━━━━━━━━━━━━━━━━
Pilih lama perpanjangan 👇
(sisa hari otomatis ditambahkan, tidak hangus)
"""
    return teks, rows


# ---------- menu utama ----------
@bot.on(events.CallbackQuery(data=b'store'))
async def store_home(event):
    await kirim_menu_store(event, edit=True)

@bot.on(events.CallbackQuery(data=b'store-server'))
async def store_server_pub(event):
    teks = "▰▰▰ **DAFTAR SERVER** ▰▰▰\n\n"
    n = 0
    for s in N.servers(only_active=True):
        if not int(s["premium_enabled"] or 0):
            continue
        n += 1
        online = N.server_online(s)
        teks += ("%d. **%s**\n   %s\n" %
                 (n, s["name"], "Online" if online else "Offline"))
    if not n:
        teks += "Belum ada server aktif.\n"
    teks += ("\nServer dipilih saat membeli akun.\n"
             "Harga tiap server bisa berbeda.")
    await safe_send(event, teks, buttons=[
        [Button.inline("🛍️ Beli Akun", "store-beli")],
        [Button.inline("‹ Menu Utama ›", "store")]])

@bot.on(events.CallbackQuery(data=b'store-bantu'))
async def store_bantu(event):
    dom = S.cfg("DOMAIN", "-")
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**❓ BANTUAN**
━━━━━━━━━━━━━━━━━━━━━━━
1️⃣ **Deposit** dulu: menu 💰 Deposit → pilih nominal → **scan QR** yang muncul.
2️⃣ Saldo otomatis masuk setelah pembayaran terdeteksi (±45 detik).
3️⃣ **Beli Akun** → pilih jenis akun → pilih masa aktif **3 / 7 / 30 hari**.
4️⃣ Lihat akun di menu 📄 **Akun Saya**.
5️⃣ Akun mau habis? Bot akan **mengingatkan otomatis** (H-3 & H-1).
   Supaya tetap aktif → 📄 Akun Saya → 🔄 **Perpanjang Masa Aktif**.
   (sisa hari otomatis ditambahkan, tidak hangus)
━━━━━━━━━━━━━━━━━━━━━━━
🌐 Domain : `{dom}`
💬 Kalau saldo tidak masuk >10 menit, hubungi admin.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[[Button.inline("‹ Menu Utama ›", "store")]])


# ---------- beli akun ----------
def _tipe_tersedia():
    out = []
    for tipe in N.TIPE_JUAL:
        for s in N.servers(only_active=True):
            if not int(s["premium_enabled"] or 0):
                continue
            if any(p["tipe"] == tipe for p in
                   N.server_products(int(s["id"]), only_active=True)):
                out.append(tipe)
                break
    return out

@bot.on(events.CallbackQuery(data=b'store-beli'))
async def store_beli(event):
    await _bersih_qr(event)
    tipe_ada = _tipe_tersedia()
    if not tipe_ada:
        await event.answer("Belum ada produk tersedia.", alert=True)
        return
    rows, buf = [], []
    for t in tipe_ada:
        buf.append(Button.inline(S.TIPE_LABEL.get(t, t), "store-tipe-%s" % t))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    teks = """
━━━━━━━━━━━━━━━━━━━━━━━
**🛍️ BELI AKUN**
━━━━━━━━━━━━━━━━━━━━━━━
Pilih jenis akun yang mau dibeli 👇
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-tipe-'))
async def store_tipe(event):
    tipe = event.data.decode().replace("store-tipe-", "")
    pilihan = _server_untuk_tipe(tipe)
    if not pilihan:
        await event.answer("Belum ada server yang menjual tipe ini.", alert=True)
        return
    rows = []
    for s, prods in pilihan:
        online = N.server_online(s)
        label = s["name"][:30]
        if not online:
            label += " (offline)"
        rows.append([Button.inline(label, "store-srv-%s-%d" % (tipe, int(s["id"])))])
    rows.append([Button.inline("‹ Kembali ›", "store-beli")])
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🛍️ {S.TIPE_LABEL.get(tipe, tipe).upper()}**
━━━━━━━━━━━━━━━━━━━━━━━
Pilih server tempat akun dibuat 👇
Harga muncul di langkah berikutnya.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=rows)

@bot.on(events.CallbackQuery(pattern=r'^store-srv-([a-z]+)-(\d+)$'))
async def store_srv(event):
    tipe = event.pattern_match.group(1)
    if isinstance(tipe, (bytes, bytearray)):
        tipe = tipe.decode("ascii", "ignore")
    sid = int(event.pattern_match.group(2))
    s = N.server_by_id(sid)
    if not s:
        await event.answer("Server tidak ada.", alert=True)
        return
    if not int(s["premium_enabled"] or 0):
        await event.answer("Premium di server ini sedang ditutup.", alert=True)
        return
    if not N.server_online(s):
        await event.answer("Server sedang offline. Pilih server lain.", alert=True)
        return
    prods = _hari_server(sid, tipe)
    if not prods:
        await event.answer("Produk di server ini kosong.", alert=True)
        return
    rows = []
    for p in prods:
        rows.append([Button.inline("🗓️ %d Hari — %s" % (int(p["hari"]),
                                                       S.rupiah(int(p["harga"]))),
                                   "store-buy-%s-%d-%d" % (tipe, sid, int(p["hari"])))])
    rows.append([Button.inline("‹ Pilih Server ›", "store-tipe-%s" % tipe)])
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🛍️ {S.TIPE_LABEL.get(tipe, tipe).upper()}**
━━━━━━━━━━━━━━━━━━━━━━━
🌐 **Server :** `{_label_server(s)}`
📶 **Status :** `{'ONLINE' if N.server_online(s) else 'OFFLINE'}`
━━━━━━━━━━━━━━━━━━━━━━━
Pilih masa aktif 👇
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=rows)

def _parse_beli(raw):
    """Baru: tipe-sid-hari. Lama: kode (mis. ssh-3)."""
    b = (raw or "").split("-")
    if len(b) == 3 and b[0] in N.TIPE_JUAL and b[1].isdigit() and b[2].isdigit():
        return b[0], int(b[1]), int(b[2]), None
    if len(b) == 2:
        return None, None, None, raw
    return None, None, None, None


@bot.on(events.CallbackQuery(pattern=r'^store-buy-'))
async def store_buy(event):
    raw = event.data.decode().replace("store-buy-", "")
    tipe, sid, hari, kode = _parse_beli(raw)
    if kode:
        gp = S.produk_by_kode(kode)
        if not gp:
            await event.answer("Produk tidak ditemukan.", alert=True)
            return
        tipe, hari = gp["tipe"], int(gp["hari"])
        h = _home()
        sid = int(h["id"]) if h else 0
    if not tipe or not hari:
        await event.answer("Produk tidak valid.", alert=True)
        return
    s = N.server_by_id(sid) or _home()
    p = _produk_untuk(sid, tipe, hari)
    if not p or not s:
        await event.answer("Produk di server ini tidak tersedia.", alert=True)
        return
    if not N.server_online(s):
        await event.answer("Server sedang offline. Pilih server lain.", alert=True)
        return
    u = S.get_user(event.sender_id)
    saldo = u["saldo"] if u else 0
    cukup = saldo >= p["harga"]
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🧾 KONFIRMASI PEMBELIAN**
━━━━━━━━━━━━━━━━━━━━━━━
🌐 **Server   :** `{_label_server(s)}`
📦 **Paket    :** `{p['nama']}`
🗓️ **Masa     :** `{p['hari']} hari`
💵 **Harga    :** `{S.rupiah(p['harga'])}`
💰 **Saldo    :** `{S.rupiah(saldo)}`
━━━━━━━━━━━━━━━━━━━━━━━
{'✅ Saldo cukup, lanjutkan?' if cukup else '❌ Saldo kurang. Silakan deposit dulu.'}
"""
    rows = []
    if cukup:
        if kode:
            cb = "store-buyok-%s" % kode
        else:
            cb = "store-buyok-%s-%d-%d" % (tipe, sid, hari)
        rows.append([Button.inline("✅ Beli Sekarang", cb)])
    else:
        rows.append([Button.inline("💰 Deposit Sekarang", "depo")])
    if kode:
        rows.append([Button.inline("‹ Kembali ›", "store-tipe-%s" % tipe)])
    else:
        rows.append([Button.inline("‹ Kembali ›", "store-srv-%s-%d" % (tipe, sid))])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-buyok-'))
async def store_buyok(event):
    raw = event.data.decode().replace("store-buyok-", "")
    tipe, sid, hari, kode = _parse_beli(raw)
    if kode:
        gp = S.produk_by_kode(kode)
        if not gp:
            await event.answer("Produk tidak ditemukan.", alert=True)
            return
        tipe, hari = gp["tipe"], int(gp["hari"])
        h = _home()
        sid = int(h["id"]) if h else 0
    if not tipe or not hari:
        await event.answer("Produk tidak valid.", alert=True)
        return
    s = N.server_by_id(sid) or _home()
    p = _produk_untuk(sid, tipe, hari)
    if not p or not s:
        await event.answer("Produk tidak tersedia.", alert=True)
        return
    if not N.server_online(s):
        await event.answer("Server sedang offline.", alert=True)
        return
    u = S.get_or_create_user(event.sender_id)
    if u["saldo"] < p["harga"]:
        await event.answer("Saldo kurang.", alert=True)
        return
    if not S.saldo_kurang(event.sender_id, p["harga"]):
        await event.answer("Gagal potong saldo (saldo kurang).", alert=True)
        return

    await safe_send(event, "⏳ **Membuat akun di %s...**\nMohon tunggu sebentar."
                    % _label_server(s))
    order_id = "TRX-%s-%s" % (DT.datetime.now().strftime("%y%m%d%H%M%S"), S._rand(3))
    lokal = not str(s["base_url"] or "").strip()

    if lokal:
        user = S.buat_username(tipe)
        pw = S._rand(8)
        ok, out = await asyncio.to_thread(
            S.buat_akun, tipe, user, hari, p["quota"], p["iplimit"], pw)
        if not ok:
            S.saldo_tambah(event.sender_id, p["harga"])
            await safe_send(
                event,
                "❌ **Gagal membuat akun.**\nSaldo dikembalikan.\n\n```\n%s\n```"
                % (out or "")[-800:],
                buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
            return
        password = pw
        exp_date = DT.date.today() + DT.timedelta(days=int(hari))
        exp_iso = exp_date.strftime("%Y-%m-%d")
        exp = exp_date.strftime("%d %b %Y")
        if tipe == "ssh":
            detail = S.detail_ssh(user, pw, expired=exp,
                                  quota=p["quota"], iplimit=p["iplimit"])
        else:
            uuid = S.uuid_dari_output(tipe, out)
            links = S.link_berlabel(S.ambil_link(out, berlabel=False))
            detail = S.detail_xray(tipe, user, uuid, expired=exp,
                                   quota=p["quota"], iplimit=p["iplimit"],
                                   links=links, remarks=user)
    else:
        data = None
        pesan = ""
        for _coba in range(4):
            user = _username_remote(tipe)
            try:
                data = await asyncio.to_thread(
                    N.create_account, s, tipe, user, hari,
                    p["quota"], p["iplimit"], order_id)
            except Exception as exc:
                pesan = str(exc)
                data = None
                break
            if data.get("ok"):
                break
            pesan = str(data.get("error") or "gagal")
            if str(data.get("code") or "") != "exists":
                break
            data = None
        if not data or not data.get("ok"):
            S.saldo_tambah(event.sender_id, p["harga"])
            await safe_send(
                event,
                "❌ **Gagal membuat akun di server.**\nSaldo dikembalikan.\n\n"
                "```\n%s\n```" % (pesan or "")[-800:],
                buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
            return
        profile = str(data.get("profile") or "")
        password = str(data.get("password") or "")
        try:
            ts = int(data.get("expires_at") or 0)
        except Exception:
            ts = 0
        if ts > 0:
            exp_iso = DT.datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
        else:
            exp_iso = (DT.date.today() +
                       DT.timedelta(days=int(hari))).strftime("%Y-%m-%d")
        exp = DT.datetime.strptime(exp_iso, "%Y-%m-%d").strftime("%d %b %Y")
        dns_node = data.get("dns") or {}
        if tipe == "ssh":
            detail = profile
            dns_info = N.dns_info_from(dns_node, "ssh")
            if dns_info and "Host Slowdns" not in detail:
                detail += ("\n" + "\n".join("%-15s: %s" % (k, v)
                                            for k, v in dns_info))
        else:
            detail = S.ringkas_profile(
                tipe, user, profile, expired=exp, quota=p["quota"],
                iplimit=p["iplimit"],
                dns_info=N.dns_info_from(dns_node, "xray"))

    S.pesanan_baru(order_id, event.sender_id, p, user, password, detail, exp,
                   exp_iso=exp_iso, server_id=int(s["id"]),
                   server_code=str(s["code"]), server_name=str(s["name"]))
    x = S.db()
    row = x.execute("SELECT * FROM pesanan WHERE order_id=?", (order_id,)).fetchone()
    x.close()

    judul_lengkap = (
        "VMESS ACCOUNT", "VLESS ACCOUNT", "TROJAN ACCOUNT",
        "SHADOWSOCKS ACCOUNT", "SSH OVPN ACCOUNT",
    )
    kepala = str(detail or "")[:300]
    if (any(t in kepala for t in judul_lengkap)
            or "SSH OVPN Account" in kepala):
        teks_akun = (detail + "\n\nServer : `%s`\nOrder  : `%s`"
                     % (_label_server(s), order_id))
    else:
        teks_akun = _pesan_akun(row)
    await safe_send(event, teks_akun, buttons=_tombol_akun(row))
    try:
        admin = S.admin_id()
        u2 = S.get_user(event.sender_id)
        if admin:
            await bot.send_message(int(admin),
                "🛒 **PENJUALAN BARU**\n\n"
                "👤 User : `%s`\n🌐 Server : `%s`\n📦 Paket : `%s`\n"
                "💵 Harga : `%s`\n🆔 Order : `%s`\n"
                "🧾 Akun : `%s`\n💰 Sisa saldo user: `%s`" % (
                    event.sender_id, _label_server(s), p["nama"],
                    S.rupiah(p["harga"]), order_id,
                    user, S.rupiah(u2["saldo"] if u2 else 0)))
    except Exception:
        pass

# ---------- riwayat akun ----------
@bot.on(events.CallbackQuery(data=b'store-riwayat'))
async def store_riwayat(event):
    await _bersih_qr(event)
    ps = S.pesanan_user(event.sender_id, 10)
    teks = "━━━━━━━━━━━━━━━━━━━━━━━\n**🧾 RIWAYAT AKUN**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
    if not ps:
        teks += "belum ada pembelian\n"
    for p in ps:
        teks += "• `%s` — %s (%s)\n" % (p["akun"], p["nama_produk"], p["created"])
    teks += "━━━━━━━━━━━━━━━━━━━━━━━"
    await safe_send(event, teks, buttons=[[Button.inline("‹ Menu Utama ›", "store")]])


# ---------- riwayat invoice / deposit ----------
@bot.on(events.CallbackQuery(data=b'store-invoice'))
async def store_invoice(event):
    await _bersih_qr(event)
    dep = S.deposit_riwayat(event.sender_id, 10)
    teks = "━━━━━━━━━━━━━━━━━━━━━━━\n**📑 RIWAYAT INVOICE**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
    rows = []
    if not dep:
        teks += "belum ada invoice deposit\n"
        rows.append([Button.inline("💰 Deposit", "depo")])
    for d in dep:
        icon = {"PAID": "✅", "PENDING": "⏳", "EXPIRED": "⌛", "FAILED": "❌"}.get(d["status"], "•")
        teks += "%s %s — %s\n   `%s`\n" % (
            icon, S.rupiah(d["amount"]), d["status"], d["order_id"])
        if d["status"] == "PENDING":
            rows.append([Button.inline("💳 Lihat QR — %s" % S.rupiah(d["amount"]),
                                       "depo-qr-%s" % d["order_id"])])
    teks += "━━━━━━━━━━━━━━━━━━━━━━━\n"
    teks += "QR hanya muncul saat tombol Lihat QR ditekan."
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'store-akun'))
async def store_akun(event):
    await _bersih_qr(event)
    ps = S.pesanan_user(event.sender_id, 10)
    if not ps:
        await safe_send(event, "📄 **Belum ada akun.**\nSilakan beli akun dulu.",
                         buttons=[[Button.inline("🛍️ Beli Akun", "store-beli")],
                                  [Button.inline("‹ Menu Utama ›", "store")]])
        return
    rows = []
    for p in ps:
        rows.append([Button.inline("[%s] %s — %s" % (S.status_singkat(p), p["akun"],
                                                     p["nama_produk"]),
                                   "store-det-%s" % p["id"])])
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    await safe_send(event, "━━━━━━━━━━━━━━━━━━━━━━━\n**📄 AKUN SAYA**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
                     "Pilih akun untuk lihat detail 👇",
                     buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-det-'))
async def store_det(event):
    pid = event.data.decode().replace("store-det-", "")
    p = S.pesanan_by_id(pid)
    if not p or str(p["user_id"]) != str(event.sender_id):
        await event.answer("Tidak ditemukan.", alert=True)
        return
    await safe_send(event, _pesan_akun(p), buttons=_tombol_akun(p))


# ---------- perpanjang masa aktif ----------
@bot.on(events.CallbackQuery(pattern=r'^store-renew-\d+$'))
async def store_renew(event):
    pid = event.data.decode().replace("store-renew-", "")
    p = S.pesanan_by_id(pid)
    if not p or str(p["user_id"]) != str(event.sender_id):
        await event.answer("Tidak ditemukan.", alert=True)
        return
    teks, rows = _tombol_perpanjang(p)
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-renewok-'))
async def store_renewok(event):
    d = event.data.decode().replace("store-renewok-", "")
    pid, _, kode = d.partition("-")
    p = S.pesanan_by_id(pid)
    pr = _produk_renew(p, kode) if p else None
    if not p or not pr or str(p["user_id"]) != str(event.sender_id):
        await event.answer("Tidak ditemukan.", alert=True)
        return
    u = S.get_user(event.sender_id)
    saldo = u["saldo"] if u else 0
    cukup = saldo >= pr["harga"]
    st = S.status_masa(p)
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🧾 KONFIRMASI PERPANJANG**
━━━━━━━━━━━━━━━━━━━━━━━
🌐 **Server   :** `{_label_order(p)}`
🧾 **Akun     :** `{p['akun']}`
📦 **Paket    :** `{pr['nama']}`
🗓️ **Tambah   :** `{pr['hari']} hari`
⏱️ **Status   :** `{st}`
💵 **Harga    :** `{S.rupiah(pr['harga'])}`
💰 **Saldo    :** `{S.rupiah(saldo)}`
━━━━━━━━━━━━━━━━━━━━━━━
{'✅ Saldo cukup, lanjutkan?' if cukup else '❌ Saldo kurang. Silakan deposit dulu.'}
"""
    rows = []
    if cukup:
        rows.append([Button.inline("✅ Perpanjang Sekarang", "store-renewgo-%s-%s" % (pid, kode))])
    else:
        rows.append([Button.inline("💰 Deposit Sekarang", "depo")])
    rows.append([Button.inline("‹ Kembali ›", "store-renew-%s" % pid)])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^store-renewgo-'))
async def store_renewgo(event):
    d = event.data.decode().replace("store-renewgo-", "")
    pid, _, kode = d.partition("-")
    p = S.pesanan_by_id(pid)
    pr = _produk_renew(p, kode) if p else None
    if not p or not pr or str(p["user_id"]) != str(event.sender_id):
        await event.answer("Tidak ditemukan.", alert=True)
        return
    s = _server_order(p)
    if not s or not N.server_online(s):
        await event.answer("Server akun ini sedang offline.", alert=True)
        return
    if not S.saldo_kurang(event.sender_id, pr["harga"]):
        await event.answer("Saldo kurang.", alert=True)
        return

    await safe_send(event, "⏳ **Memperpanjang akun di %s...**\nMohon tunggu sebentar."
                    % _label_server(s))
    sisa = S.sisa_hari(p) or 0
    lokal = not str(s["base_url"] or "").strip()

    if lokal:
        ok, out, exp_baru = await asyncio.to_thread(
            S.renew_akun, p["tipe"], p["akun"], p["password"], pr["hari"], sisa,
            pr["quota"], pr["iplimit"])
        detail_baru = ""
    else:
        ok, out, exp_baru, detail_baru = False, "", "", ""
        try:
            data = await asyncio.to_thread(
                N.renew_account, s, p["tipe"], p["akun"], pr["hari"],
                pr["quota"], pr["iplimit"],
                "REN-%s-%s" % (pid, S._rand(4)))
            ok = bool(data.get("ok"))
            if ok:
                try:
                    ts = int(data.get("expires_at") or 0)
                except Exception:
                    ts = 0
                if ts > 0:
                    exp_baru = DT.datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
                else:
                    exp_baru = (DT.date.today() + DT.timedelta(
                        days=int(pr["hari"]) + max(0, int(sisa)))).strftime("%Y-%m-%d")
                detail_baru = str(data.get("profile") or "")
                out = "OK"
            else:
                out = str(data.get("error") or "gagal")
        except Exception as exc:
            ok, out = False, str(exc)

    if not ok:
        S.saldo_tambah(event.sender_id, pr["harga"])
        await safe_send(event,
                        "❌ **Gagal memperpanjang.**\nSaldo dikembalikan.\n\n```\n%s\n```"
                        % (out or "")[-500:],
                        buttons=[[Button.inline("‹ Akun Saya ›", "store-akun")]])
        return

    S.pesanan_update_expired(int(pid), exp_baru, tambah_hari=pr["hari"])
    if detail_baru:
        try:
            x = S.db()
            x.execute("UPDATE pesanan SET detail=? WHERE id=?", (detail_baru, int(pid)))
            x.commit()
            x.close()
        except Exception:
            pass
    p2 = S.pesanan_by_id(pid)
    u2 = S.get_user(event.sender_id)
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**✅ PERPANJANG BERHASIL**
━━━━━━━━━━━━━━━━━━━━━━━
🌐 **Server   :** `{_label_server(s)}`
🧾 **Akun     :** `{p2['akun']}`
🗓️ **Expired  :** `{p2['expired']}`
⏱️ **Masa     :** `{S.status_masa(p2)}`
💵 **Terpotong:** `{S.rupiah(pr['harga'])}`
💰 **Saldo    :** `{S.rupiah(u2['saldo'] if u2 else 0)}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[[Button.inline("📄 Akun Saya", "store-akun")],
                                          [Button.inline("‹ Menu Utama ›", "store")]])
    try:
        adm = S.admin_id()
        if adm:
            await bot.send_message(int(adm),
                "🔄 **PERPANJANGAN**\n👤 User : `%s`\n🌐 Server : `%s`\n"
                "🧾 Akun : `%s`\n📦 Paket: `%s`\n💵 Harga: `%s`\n🗓️ Exp  : `%s`"
                % (event.sender_id, _label_server(s), p2["akun"], pr["nama"],
                   S.rupiah(pr["harga"]), p2["expired"]))
    except Exception:
        pass

# ---------- tombol start untuk pelanggan ----------
@bot.on(events.NewMessage(pattern=r"^/(store|shop|toko)$"))
async def store_cmd(event):
    await kirim_menu_store(event)
