# -*- coding: utf-8 -*-
# ============================================================
#  modules/deposit.py - deposit saldo via Duitku (QRIS)
#  - 1 langkah: pilih nominal -> QRIS muncul sebagai GAMBAR
#  - PEMBAYARAN TERDETEKSI OTOMATIS (tidak perlu tekan apa-apa)
#  - Pesan QR / tagihan DIHAPUS setelah dibayar (biar tidak numpuk)
# ============================================================
import asyncio

from kyt import *
from kyt import store_lib as S

NOMINAL = [5000, 10000, 20000, 50000, 100000]  # cadangan (default di store_lib)

# jeda pengecekan otomatis per tagihan (detik) - makin lama makin jarang
# supaya tidak kena limit Duitku
_INTERVAL = [5, 8, 10, 15, 20, 30]

_TUGAS = {}     # order_id -> task pemantau
_SEDANG = set()  # order_id yang sedang dicek (anti dobel request)


def _nominal_buttons():
    rows, buf = [], []
    for n in S.depo_nominal():
        buf.append(Button.inline(S.rupiah(n), "depo-nom-%d" % n))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([Button.inline("✏️ Nominal Lain", "depo-custom")])
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    return rows


def _teks_depo(u):
    return f"""
━━━━━━━━━━━━━━━━━━━━━━━
**💰 DEPOSIT SALDO**
━━━━━━━━━━━━━━━━━━━━━━━
👤 **Akun  :** `{u['nama'] or u['user_id']}`
💰 **Saldo :** `{S.rupiah(u['saldo'])}`
💳 **Bayar :** `{S.dk_method_name()}`
━━━━━━━━━━━━━━━━━━━━━━━
Pilih nominal deposit (min. {S.rupiah(S.depo_min())}) 👇
"""


@bot.on(events.CallbackQuery(data=b'depo'))
async def depo(event):
    u = S.get_or_create_user(event.sender_id)
    await safe_send(event, _teks_depo(u), buttons=_nominal_buttons())


@bot.on(events.CallbackQuery(pattern=r'^depo-nom-'))
async def depo_nom(event):
    try:
        amount = int(event.data.decode().replace("depo-nom-", ""))
    except Exception:
        await event.answer("Nominal tidak valid.", alert=True)
        return
    await _buat_tagihan(event, amount)


@bot.on(events.CallbackQuery(data=b'depo-custom'))
async def depo_custom(event):
    chat = event.chat_id
    mn = S.depo_min()
    await safe_send(event, "✏️ **Masukkan nominal deposit** (angka saja, "
                           "min %s):" % S.rupiah(mn))
    try:
        async with bot.conversation(chat) as conv:
            fut = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            msg = await fut
    except Exception:
        await event.reply("Gagal membaca input.",
                          buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return
    txt = (msg.raw_text or "").replace(".", "").replace(",", "").replace("Rp", "").strip()
    if not txt.isdigit() or int(txt) < mn:
        await event.reply("❌ Nominal tidak valid (min %s)." % S.rupiah(mn),
                          buttons=[[Button.inline("💰 Deposit", "depo")]])
        return
    await _buat_tagihan(event, int(txt))


# tombol lama (kalau user masih menekan tombol dari pesan lama) -> langsung buat tagihan
@bot.on(events.CallbackQuery(pattern=r'^depo-met-'))
async def depo_met_lama(event):
    rest = event.data.decode().replace("depo-met-", "")
    amount, _, _code = rest.partition("-")
    try:
        await _buat_tagihan(event, int(amount))
    except Exception:
        await event.answer("Silakan ulangi dari menu Deposit.", alert=True)


def _teks_tagihan(order_id, amount, qr):
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🧾 TAGIHAN DEPOSIT**
━━━━━━━━━━━━━━━━━━━━━━━
🆔 **Order  :** `{order_id}`
💵 **Jumlah :** `{S.rupiah(amount)}`
💳 **Metode :** `{S.dk_method_name()}`
⏳ **Batas  :** `{S.dk_expiry()} menit`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    if qr:
        teks += ("📱 **Scan QR di atas** pakai aplikasi bank / e-wallet apa saja\n"
                 "(GoPay, OVO, DANA, ShopeePay, m-banking).\n")
    teks += """
━━━━━━━━━━━━━━━━━━━━━━━
Saldo masuk **otomatis** begitu pembayaran terdeteksi.
Pesan tagihan ini akan **terhapus sendiri** setelah berhasil.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    return teks


def _rows_tagihan(order_id, pay_url):
    rows = []
    if pay_url:
        rows.append([Button.url("💳 Bayar / Lihat QR", pay_url)])
    rows.append([Button.inline("🔄 Cek Status", "depo-cek-%s" % order_id)])
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    return rows


# ---------------- hapus pesan tagihan (anti numpuk) ----------------
async def _hapus_pesan(chat_id, ids):
    if not chat_id:
        return
    uniq = []
    for i in ids:
        try:
            i = int(i)
        except Exception:
            continue
        if i and i not in uniq:
            uniq.append(i)
    if not uniq:
        return
    try:
        await bot.delete_messages(int(chat_id), uniq, revoke=True)
    except Exception as e:
        logging.error("hapus pesan tagihan gagal: %s", e)


async def _bersih_tagihan(order_id):
    """Hapus pesan QR + pesan 'membuat tagihan' setelah selesai/kedaluwarsa."""
    try:
        d = S.deposit_by_order(order_id)
        if not d:
            return
        ids = []
        for k in ("msg_id", "proses_id"):
            try:
                ids.append(d[k])
            except Exception:
                pass
        await _hapus_pesan(d["chat_id"], ids)
        S.deposit_set_pesan(order_id, msg_id="", proses_id="")
    except Exception as e:
        logging.error("bersih tagihan: %s", e)


# ---------------- pemantau otomatis per tagihan ----------------
def _mulai_pantau(order_id, total_detik=1200):
    if order_id in _TUGAS:
        return
    try:
        t = bot.loop.create_task(_pantau_order(order_id, total_detik))
        _TUGAS[order_id] = t
    except Exception as e:
        logging.error("gagal start pemantau %s: %s", order_id, e)


async def _pantau_order(order_id, total_detik=1200):
    """Cek tagihan ini berulang-ulang sampai dibayar / kedaluwarsa."""
    mulai = time.time()
    i = 0
    try:
        while time.time() - mulai < total_detik:
            jeda = _INTERVAL[i] if i < len(_INTERVAL) else 30
            i += 1
            await asyncio.sleep(jeda)
            d = S.deposit_by_order(order_id)
            if not d or d["status"] != "PENDING":
                return
            if await _cek_satu(order_id, notify=True):
                return
    except asyncio.CancelledError:
        return
    except Exception as e:
        logging.error("pantau %s: %s", order_id, e)
    finally:
        _TUGAS.pop(order_id, None)


async def _buat_tagihan(event, amount):
    """Buat tagihan QRIS langsung (tanpa pilih metode)."""
    if not S.dk_ready():
        await safe_send(event,
                         "⚠️ **Pembayaran belum diaktifkan admin.**\n"
                         "Merchant Code / API Key Duitku belum diisi.\nHubungi admin.",
                         buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return

    mproses = await safe_send(event, "⏳ **Membuat tagihan QRIS...**")

    u = S.get_or_create_user(event.sender_id)
    try:
        sender = await event.get_sender()
        nama = getattr(sender, "first_name", "") or "Customer"
    except Exception:
        nama = "Customer"

    order_id = "DEP%s%s" % (DT.datetime.now().strftime("%y%m%d%H%M%S"), S._rand(3))
    kode = S.dk_method()
    S.deposit_baru(order_id, event.sender_id, amount, kode, S.dk_method_name())
    S.deposit_set_pesan(order_id, chat_id=event.chat_id,
                        proses_id=getattr(mproses, "id", None))

    try:
        res = await asyncio.to_thread(
            S.duitku_create, order_id, amount, kode,
            "Deposit Saldo VPN Store", "", "", nama)
    except Exception as e:
        S.deposit_update(order_id, status="FAILED")
        await safe_send(event, "❌ **Gagal membuat tagihan.**\n\n`%s`" % e,
                        buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return

    if str(res.get("statusCode")) != "00":
        S.deposit_update(order_id, status="FAILED")
        await safe_send(event,
                         "❌ **Gagal membuat tagihan.**\n\n`%s`\n\n"
                         "Cek Merchant Code / API Key / mode (Production-Sandbox)."
                         % S._err(res),
                         buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return

    ref = res.get("reference", "")
    pay_url = res.get("paymentUrl", "") or res.get("payment_url", "")
    qr = res.get("qrString", "") or res.get("qr_string", "")
    S.deposit_update(order_id, reference=ref, pay_url=pay_url, qr=qr)

    teks = _teks_tagihan(order_id, amount, qr)
    rows = _rows_tagihan(order_id, pay_url)

    # ---- kirim QR sebagai GAMBAR (biar bisa langsung di-scan) ----
    msg_id = None
    if qr:
        png = await asyncio.to_thread(S.qr_png, qr)
        if png:
            path = os.path.join("/tmp", "qris_%s.png" % order_id)
            try:
                with open(path, "wb") as fh:
                    fh.write(png)
                m = await bot.send_file(event.chat_id, path,
                                        caption=teks, buttons=rows, force_document=False)
                msg_id = getattr(m, "id", None)
            except Exception as e:
                logging.error("kirim foto QR gagal: %s", e)
            finally:
                try:
                    os.remove(path)
                except Exception:
                    pass

    if msg_id is None:
        if qr:
            teks += "\n📱 **QRIS (string):**\n`%s`\n" % qr
        m = await safe_send(event, teks, rows)
        msg_id = getattr(m, "id", None)

    S.deposit_set_pesan(order_id, msg_id=msg_id)
    # ---- mulai pantau otomatis ----
    _mulai_pantau(order_id)


@bot.on(events.CallbackQuery(pattern=r'^depo-cek-'))
async def depo_cek(event):
    order_id = event.data.decode().replace("depo-cek-", "")
    d = S.deposit_by_order(order_id)
    if not d:
        await event.answer("Order tidak ditemukan.", alert=True)
        return
    if d["status"] == "PAID":
        await event.answer("✅ Sudah dibayar.", alert=True)
        return
    if d["status"] in ("FAILED", "EXPIRED"):
        await event.answer("❌ Tagihan sudah %s." % d["status"], alert=True)
        return
    await event.answer("⏳ Mengecek...")
    await _cek_satu(order_id, notify=True)


async def _cek_satu(order_id, notify=True):
    """Cek 1 order ke Duitku. Return True kalau berubah jadi PAID."""
    if order_id in _SEDANG:
        return False
    d = S.deposit_by_order(order_id)
    if not d or d["status"] != "PENDING":
        return False
    _SEDANG.add(order_id)
    try:
        res = await asyncio.to_thread(S.duitku_status, order_id)
    except Exception:
        return False
    finally:
        _SEDANG.discard(order_id)

    # statusCode: 00 = sukses, 01 = proses, 02 = gagal/expired
    rc = str(res.get("statusCode", ""))
    if rc == "00":
        S.deposit_update(order_id, status="PAID", paid_at=S.now())
        S.saldo_tambah(d["user_id"], d["amount"])
        # hapus pesan QR + tagihan (biar tidak numpuk)
        await _bersih_tagihan(order_id)
        if notify:
            try:
                u = S.get_user(d["user_id"])
                await bot.send_message(int(d["user_id"]),
                    "✅ **PEMBAYARAN BERHASIL**\n"
                    "━━━━━━━━━━━━━━━━━━━━━━━\n"
                    "💵 Masuk  : `%s`\n"
                    "💰 Saldo  : `%s`\n"
                    "━━━━━━━━━━━━━━━━━━━━━━━\n"
                    "Terima kasih 🙏" % (S.rupiah(d["amount"]),
                                         S.rupiah(u["saldo"] if u else 0)),
                    buttons=[[Button.inline("🛍️ Beli Akun", "store-beli")],
                             [Button.inline("‹ Menu Utama ›", "store")]])
            except Exception:
                pass
            try:
                adm = S.admin_id()
                if adm:
                    await bot.send_message(int(adm),
                        "💰 **DEPOSIT MASUK**\n👤 `%s`\n💵 `%s`\n🆔 `%s`"
                        % (d["user_id"], S.rupiah(d["amount"]), order_id))
            except Exception:
                pass
        return True
    if rc == "02":
        S.deposit_update(order_id, status="FAILED")
        await _bersih_tagihan(order_id)
    return False


async def cek_semua_pending():
    """Dipanggil background loop.

    - hanya order PALING BARU yang dicek (yang lama sudah kedaluwarsa)
    - order yang sedang dipantau cepat tidak dicek dobel
    - tagihan kedaluwarsa otomatis ditandai & pesannya dihapus
    """
    if not S.dk_ready():
        return

    # 1) tandai & bersihkan yang sudah kedaluwarsa
    try:
        for d in S.deposit_pending_tua(S.dk_expiry() + 5):
            cur = S.deposit_by_order(d["order_id"])
            if cur and cur["status"] == "PENDING":
                S.deposit_update(d["order_id"], status="EXPIRED")
                await _bersih_tagihan(d["order_id"])
    except Exception as e:
        logging.error("bersih pending tua: %s", e)

    # 2) cek yang baru (yang sedang dipantau cepat dilewati)
    for d in S.deposit_pending(5):
        if d["order_id"] in _TUGAS:
            continue
        await _cek_satu(d["order_id"], notify=True)
