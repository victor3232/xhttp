# -*- coding: utf-8 -*-
# ============================================================
#  modules/deposit.py - deposit saldo via Duitku (QRIS ShopeePay)
#  Fokus 1 metode: QRIS. Langsung buat tagihan, tanpa pilih metode.
# ============================================================
import asyncio
import io

from kyt import *
from kyt import store_lib as S

NOMINAL = [10000, 20000, 50000, 100000, 200000]


def _nominal_buttons():
    rows, buf = [], []
    for n in NOMINAL:
        buf.append(Button.inline(S.rupiah(n), "depo-nom-%d" % n))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([Button.inline("✏️ Nominal Lain", "depo-custom")])
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    return rows


def _teks_depo(u):
    return f"""
━━━━━━━━━━━━━━━━━━━━━━━
**💰 DEPOSIT SALDO**
━━━━━━━━━━━━━━━━━━━━━━━
👤 **Akun  :** `{u['nama'] or u['user_id']}`
💰 **Saldo :** `{S.rupiah(u['saldo'])}`
💳 **Bayar :** `{S.dk_method_name()}`
━━━━━━━━━━━━━━━━━━━━━━━
Pilih nominal deposit (min. Rp 10.000) 👇
"""


@bot.on(events.CallbackQuery(data=b'depo'))
async def depo(event):
    u = S.get_or_create_user(event.sender_id)
    await safe_send(event, _teks_depo(u), buttons=_nominal_buttons())


@bot.on(events.CallbackQuery(pattern=r'^depo-nom-'))
async def depo_nom(event):
    try:
        amount = int(event.data.decode().replace("depo-nom-", ""))
    except Exception:
        await event.answer("Nominal tidak valid.", alert=True)
        return
    await _buat_tagihan(event, amount)


@bot.on(events.CallbackQuery(data=b'depo-custom'))
async def depo_custom(event):
    chat = event.chat_id
    await safe_send(event, "✏️ **Masukkan nominal deposit** (angka saja, min Rp 10.000):")
    try:
        async with bot.conversation(chat) as conv:
            fut = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            msg = await fut
    except Exception:
        await event.reply("Gagal membaca input.",
                          buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return
    txt = (msg.raw_text or "").replace(".", "").replace(",", "").replace("Rp", "").strip()
    if not txt.isdigit() or int(txt) < 10000:
        await event.reply("❌ Nominal tidak valid (min Rp 10.000).",
                          buttons=[[Button.inline("💰 Deposit", "depo")]])
        return
    await _buat_tagihan(event, int(txt))


# tombol lama (kalau user masih menekan tombol dari pesan lama) -> langsung buat tagihan
@bot.on(events.CallbackQuery(pattern=r'^depo-met-'))
async def depo_met_lama(event):
    rest = event.data.decode().replace("depo-met-", "")
    amount, _, _code = rest.partition("-")
    try:
        await _buat_tagihan(event, int(amount))
    except Exception:
        await event.answer("Silakan ulangi dari menu Deposit.", alert=True)


def _teks_tagihan(order_id, amount, qr):
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🧾 TAGIHAN DEPOSIT**
━━━━━━━━━━━━━━━━━━━━━━━
🆔 **Order  :** `{order_id}`
💵 **Jumlah :** `{S.rupiah(amount)}`
💳 **Metode :** `{S.dk_method_name()}`
⏳ **Batas  :** `{S.dk_expiry()} menit`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    if qr:
        teks += ("📱 **Scan QR di atas** pakai aplikasi bank / e-wallet apa saja\n"
                 "(GoPay, OVO, DANA, ShopeePay, m-banking).\n")
    teks += """
━━━━━━━━━━━━━━━━━━━━━━━
Saldo masuk **otomatis** setelah dibayar.
Kalau sudah bayar tapi saldo belum masuk, tekan **🔄 Cek Status**.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    return teks


def _rows_tagihan(order_id, pay_url):
    rows = []
    if pay_url:
        rows.append([Button.url("💳 Bayar / Lihat QR", pay_url)])
    rows.append([Button.inline("🔄 Cek Status", "depo-cek-%s" % order_id)])
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    return rows


async def _buat_tagihan(event, amount):
    """Buat tagihan QRIS langsung (tanpa pilih metode)."""
    if not S.dk_ready():
        await safe_send(event,
                         "⚠️ **Pembayaran belum diaktifkan admin.**\n"
                         "Merchant Code / API Key Duitku belum diisi.\nHubungi admin.",
                         buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return

    await safe_send(event, "⏳ **Membuat tagihan QRIS...**")

    u = S.get_or_create_user(event.sender_id)
    try:
        sender = await event.get_sender()
        nama = getattr(sender, "first_name", "") or "Customer"
    except Exception:
        nama = "Customer"

    order_id = "DEP%s%s" % (DT.datetime.now().strftime("%y%m%d%H%M%S"), S._rand(3))
    kode = S.dk_method()
    S.deposit_baru(order_id, event.sender_id, amount, kode, S.dk_method_name())

    try:
        res = await asyncio.to_thread(
            S.duitku_create, order_id, amount, kode,
            "Deposit Saldo VPN Store", "", "", nama)
    except Exception as e:
        S.deposit_update(order_id, status="FAILED")
        await safe_send(event, "❌ **Gagal membuat tagihan.**\n\n`%s`" % e,
                        buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return

    if str(res.get("statusCode")) != "00":
        S.deposit_update(order_id, status="FAILED")
        await safe_send(event,
                         "❌ **Gagal membuat tagihan.**\n\n`%s`\n\n"
                         "Cek Merchant Code / API Key / mode (Production-Sandbox)."
                         % S._err(res),
                         buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return

    ref = res.get("reference", "")
    pay_url = res.get("paymentUrl", "") or res.get("payment_url", "")
    qr = res.get("qrString", "") or res.get("qr_string", "")
    S.deposit_update(order_id, reference=ref, pay_url=pay_url, qr=qr)

    teks = _teks_tagihan(order_id, amount, qr)
    rows = _rows_tagihan(order_id, pay_url)

    # ---- kirim QR sebagai gambar ----
    if qr:
        png = await asyncio.to_thread(S.qr_png, qr)
        if png:
            try:
                await bot.send_file(event.chat_id, io.BytesIO(png),
                                    caption=teks, buttons=rows)
                return
            except Exception as e:
                logging.error("kirim foto QR gagal: %s", e)

    if qr:
        teks += "\n📱 **QRIS (string):**\n`%s`\n" % qr
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^depo-cek-'))
async def depo_cek(event):
    order_id = event.data.decode().replace("depo-cek-", "")
    d = S.deposit_by_order(order_id)
    if not d:
        await event.answer("Order tidak ditemukan.", alert=True)
        return
    if d["status"] == "PAID":
        await event.answer("✅ Sudah dibayar.", alert=True)
        return
    if d["status"] in ("FAILED", "EXPIRED"):
        await event.answer("❌ Tagihan sudah %s." % d["status"], alert=True)
        return
    await event.answer("⏳ Mengecek...")
    ok = await _cek_satu(order_id, notify=True)
    if ok:
        u = S.get_user(event.sender_id)
        await safe_send(event,
                        "✅ **Pembayaran diterima!**\n\n"
                        "💵 Masuk : `%s`\n💰 Saldo : `%s`"
                        % (S.rupiah(d["amount"]), S.rupiah(u["saldo"])),
                        buttons=[[Button.inline("🛍️ Beli Akun", "store-beli")],
                                 [Button.inline("‹ Menu Utama ›", "store")]])
    else:
        await event.answer("Belum terdeteksi. Coba lagi beberapa saat.", alert=True)


async def _cek_satu(order_id, notify=True):
    """Cek 1 order ke Duitku. Return True kalau berubah jadi PAID."""
    d = S.deposit_by_order(order_id)
    if not d or d["status"] != "PENDING":
        return False
    try:
        res = await asyncio.to_thread(S.duitku_status, order_id)
    except Exception:
        return False
    # statusCode: 00 = sukses, 01 = proses, 02 = gagal/expired
    rc = str(res.get("statusCode", ""))
    if rc == "00":
        S.deposit_update(order_id, status="PAID", paid_at=S.now())
        S.saldo_tambah(d["user_id"], d["amount"])
        if notify:
            try:
                u = S.get_user(d["user_id"])
                await bot.send_message(int(d["user_id"]),
                    "✅ **Deposit berhasil!**\n\n💵 Jumlah : `%s`\n💰 Saldo  : `%s`\n\n"
                    "Terima kasih 🙏" % (S.rupiah(d["amount"]), S.rupiah(u["saldo"])))
            except Exception:
                pass
            try:
                adm = S.admin_id()
                if adm:
                    await bot.send_message(int(adm),
                        "💰 **DEPOSIT MASUK**\n👤 `%s`\n💵 `%s`\n🆔 `%s`"
                        % (d["user_id"], S.rupiah(d["amount"]), order_id))
            except Exception:
                pass
        return True
    if rc == "02":
        S.deposit_update(order_id, status="FAILED")
    return False


async def cek_semua_pending():
    """Dipanggil background loop. Duitku batasi hit-rate -> maks 5 order terbaru."""
    if not S.dk_ready():
        return
    for d in S.deposit_pending()[:5]:
        await _cek_satu(d["order_id"], notify=True)
        # tandai expired
        try:
            dibuat = DT.datetime.strptime(d["created"], "%Y-%m-%d %H:%M:%S")
            menit = S.dk_expiry() + 5
            if (DT.datetime.now() - dibuat).total_seconds() > menit * 60:
                cur = S.deposit_by_order(d["order_id"])
                if cur and cur["status"] == "PENDING":
                    S.deposit_update(d["order_id"], status="EXPIRED")
        except Exception:
            pass
