# -*- coding: utf-8 -*-
# ============================================================
#  modules/deposit.py - deposit saldo via Duitku + auto-cek status
# ============================================================
import asyncio

from kyt import *
from kyt import store_lib as S

NOMINAL = [10000, 20000, 50000, 100000, 200000]

METODE_DEFAULT = [
    {"code": "QR", "name": "QRIS"},
    {"code": "BC", "name": "BCA Virtual Account"},
    {"code": "B1", "name": "BNI Virtual Account"},
    {"code": "BR", "name": "BRI Virtual Account"},
    {"code": "M2", "name": "Mandiri Virtual Account"},
    {"code": "DA", "name": "DANA"},
    {"code": "SP", "name": "ShopeePay"},
]


def metode_list():
    raw = S.get_setting("metode", "")
    if raw:
        try:
            d = json.loads(raw)
            if isinstance(d, list) and d:
                return d
        except Exception:
            pass
    return METODE_DEFAULT


def _nominal_buttons():
    rows, buf = [], []
    for n in NOMINAL:
        buf.append(Button.inline(S.rupiah(n), "depo-nom-%d" % n))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([Button.inline("✏️ Nominal Lain", "depo-custom")])
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    return rows


def _teks_depo(u):
    return f"""
━━━━━━━━━━━━━━━━━━━━━━━
**💰 DEPOSIT SALDO**
━━━━━━━━━━━━━━━━━━━━━━━
👤 **Akun  :** `{u['nama'] or u['user_id']}`
💰 **Saldo :** `{S.rupiah(u['saldo'])}`
━━━━━━━━━━━━━━━━━━━━━━━
Pilih nominal deposit (min. Rp 10.000) 👇
"""


async def _kirim_metode(event, amount):
    if not S.dk_ready():
        await safe_send(event, "⚠️ **Pembayaran belum diaktifkan admin.**\nHubungi admin.",
                         buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return
    mets = metode_list()
    rows, buf = [], []
    for m in mets:
        buf.append(Button.inline(m.get("name", m.get("code")), "depo-met-%d-%s" % (amount, m.get("code"))))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([Button.inline("‹ Kembali ›", "depo")])
    await safe_send(event, "━━━━━━━━━━━━━━━━━━━━━━━\n**💳 PILIH METODE BAYAR**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
                     "Nominal : `%s`\n\nSilakan pilih 👇" % S.rupiah(amount), buttons=rows)


@bot.on(events.CallbackQuery(data=b'depo'))
async def depo(event):
    u = S.get_or_create_user(event.sender_id)
    await safe_send(event, _teks_depo(u), buttons=_nominal_buttons())


@bot.on(events.CallbackQuery(pattern=r'^depo-nom-'))
async def depo_nom(event):
    amount = int(event.data.decode().replace("depo-nom-", ""))
    await _kirim_metode(event, amount)


@bot.on(events.CallbackQuery(data=b'depo-custom'))
async def depo_custom(event):
    chat = event.chat_id
    await safe_send(event, "✏️ **Masukkan nominal deposit** (angka saja, min Rp 10.000):")
    try:
        async with bot.conversation(chat) as conv:
            fut = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            msg = await fut
    except Exception:
        await event.reply("Gagal membaca input.", buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return
    txt = (msg.raw_text or "").replace(".", "").replace(",", "").replace("Rp", "").strip()
    if not txt.isdigit() or int(txt) < 10000:
        await event.reply("❌ Nominal tidak valid (min Rp 10.000).",
                          buttons=[[Button.inline("💰 Deposit", "depo")]])
        return
    await _kirim_metode(event, int(txt))


@bot.on(events.CallbackQuery(pattern=r'^depo-met-'))
async def depo_met(event):
    rest = event.data.decode().replace("depo-met-", "")
    amount, _, code = rest.partition("-")
    amount = int(amount)
    nama = code
    for m in metode_list():
        if m.get("code") == code:
            nama = m.get("name", code)
    await safe_send(event, "⏳ **Membuat tagihan...**")

    u = S.get_or_create_user(event.sender_id)
    sender = await event.get_sender()
    order_id = "DEP%s%s" % (DT.datetime.now().strftime("%y%m%d%H%M%S"), S._rand(3))
    S.deposit_baru(order_id, event.sender_id, amount, code, nama)
    res = S.duitku_create(order_id, amount, code, "Deposit Saldo VPN Store",
                          "", "", getattr(sender, "first_name", "") or "Customer")

    if str(res.get("statusCode")) != "00":
        S.deposit_update(order_id, status="FAILED")
        await safe_send(event, "❌ **Gagal membuat tagihan.**\n\n`%s`" % res.get("statusMessage", "-"),
                         buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
        return

    ref = res.get("reference", "")
    pay_url = res.get("paymentUrl", "")
    va = res.get("vaNumber", "")
    qr = res.get("qrString", "")
    S.deposit_update(order_id, reference=ref, pay_url=pay_url, va=va, qr=qr)

    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🧾 TAGIHAN DEPOSIT**
━━━━━━━━━━━━━━━━━━━━━━━
🆔 **Order  :** `{order_id}`
💵 **Jumlah :** `{S.rupiah(amount)}`
💳 **Metode :** `{nama}`
⏳ **Batas  :** `{S.get_setting('expiry_period', '60')} menit`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    if va:
        teks += "🔢 **No. VA :**\n`%s`\n" % va
    if qr:
        teks += "📱 **QRIS (string):**\n`%s`\n" % qr
    teks += """
━━━━━━━━━━━━━━━━━━━━━━━
Setelah bayar, tekan **🔄 Cek Status**.
Saldo masuk otomatis (dicek tiap ±20 detik).
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = []
    if pay_url:
        rows.append([Button.url("💳 Bayar Sekarang", pay_url)])
    rows.append([Button.inline("🔄 Cek Status", "depo-cek-%s" % order_id)])
    rows.append([Button.inline("‹ Menu Utama ›", "store")])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^depo-cek-'))
async def depo_cek(event):
    order_id = event.data.decode().replace("depo-cek-", "")
    d = S.deposit_by_order(order_id)
    if not d:
        await event.answer("Order tidak ditemukan.", alert=True)
        return
    if d["status"] == "PAID":
        await event.answer("✅ Sudah dibayar.", alert=True)
        return
    await event.answer("⏳ Mengecek...")
    ok = await _cek_satu(order_id, notify=False)
    if ok:
        u = S.get_user(event.sender_id)
        await safe_send(event, "✅ **Pembayaran diterima!**\nSaldo sekarang: `%s`" % S.rupiah(u["saldo"]),
                         buttons=[[Button.inline("‹ Menu Utama ›", "store")]])
    else:
        await event.answer("Belum terdeteksi. Coba lagi beberapa saat.", alert=True)


async def _cek_satu(order_id, notify=True):
    """Cek 1 order ke Duitku. Return True kalau berubah jadi PAID."""
    d = S.deposit_by_order(order_id)
    if not d or d["status"] != "PENDING":
        return False
    try:
        res = await asyncio.to_thread(S.duitku_status, order_id)
    except Exception:
        return False
    rc = str(res.get("resultCode", ""))
    if rc == "00":
        S.deposit_update(order_id, status="PAID", paid_at=S.now())
        S.saldo_tambah(d["user_id"], d["amount"])
        if notify:
            try:
                u = S.get_user(d["user_id"])
                await bot.send_message(int(d["user_id"]),
                    "✅ **Deposit berhasil!**\n\n💵 Jumlah : `%s`\n💰 Saldo  : `%s`\n\n"
                    "Terima kasih 🙏" % (S.rupiah(d["amount"]), S.rupiah(u["saldo"])))
            except Exception:
                pass
            try:
                adm = S.cfg("ADMIN", "")
                if adm:
                    await bot.send_message(int(adm),
                        "💰 **DEPOSIT MASUK**\n👤 `%s`\n💵 `%s`\n🆔 `%s`"
                        % (d["user_id"], S.rupiah(d["amount"]), order_id))
            except Exception:
                pass
        return True
    if rc in ("02",):
        S.deposit_update(order_id, status="FAILED")
    return False


async def cek_semua_pending():
    """Dipanggil background loop."""
    if not S.dk_ready():
        return
    for d in S.deposit_pending():
        await _cek_satu(d["order_id"], notify=True)
        # tandai expired
        try:
            dibuat = DT.datetime.strptime(d["created"], "%Y-%m-%d %H:%M:%S")
            menit = int(S.get_setting("expiry_period", "60")) + 10
            if (DT.datetime.now() - dibuat).total_seconds() > menit * 60:
                cur = S.deposit_by_order(d["order_id"])
                if cur and cur["status"] == "PENDING":
                    S.deposit_update(d["order_id"], status="EXPIRED")
        except Exception:
            pass
