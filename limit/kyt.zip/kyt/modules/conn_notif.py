# -*- coding: utf-8 -*-
# ============================================================
# modules/conn_notif.py - Notifikasi status koneksi ke admin
#   SSH/Dropbear : sesi sshd-session / dropbear aktif (real-time)
#   OpenVPN      : CLIENT_LIST di log openvpn tcp/udp
#   Xray         : aktivitas terbaru access.log (idle >= 90 detik = putus)
#   Include      : IP Address & Nama ISP pelanggan
# ============================================================
import os
import re
import json
import time
import asyncio
import logging
import subprocess
import urllib.request
import datetime as DT

from kyt import bot, get_db
from kyt import store_lib as S

_STATE_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "connection_state.json")
_XRAY_LOG = "/var/log/xray/access.log"
_XRAY_IDLE = 90       # Xray tidak memberi event disconnect; inactivity ini dianggap putus
_MAX_NOTIFY_PER_CYCLE = 30
_ISP_CACHE = {}


def conn_notif_aktif():
    return str(S.get_setting("conn_notif_aktif", "0")).strip() == "1"


def _admins():
    try:
        x = get_db()
        rows = x.execute("SELECT user_id FROM admin").fetchall()
        x.close()
        return sorted({str(r["user_id"]).strip() for r in rows if str(r["user_id"]).strip()})
    except Exception:
        return []


async def _kirim_admin(teks):
    sukses = False
    for uid in _admins():
        try:
            await bot.send_message(int(uid), teks, parse_mode="md")
            sukses = True
        except Exception as e:
            logging.error("notif koneksi ke admin %s gagal: %s", uid, e)
    return sukses


def _load_state():
    try:
        with open(_STATE_FILE) as f:
            data = json.load(f)
        if isinstance(data, dict) and "users" in data:
            return data
    except Exception:
        pass
    return None


def _save_state(state):
    try:
        temp = _STATE_FILE + ".tmp"
        with open(temp, "w") as f:
            json.dump(state, f, indent=2, sort_keys=True)
        os.replace(temp, _STATE_FILE)
    except Exception as e:
        logging.error("gagal simpan state koneksi: %s", e)


def _is_local_ip(ip):
    if not ip or ip in ("127.0.0.1", "::1", "localhost"):
        return True
    if ip.startswith((
        "10.", "192.168.", "100.64.", "100.65.", "100.66.", "100.67.",
        "172.16.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.",
        "172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.",
        "172.28.", "172.29.", "172.30.", "172.31."
    )):
        return True
    return False


def _get_isp(ip):
    if not ip or ip == "-":
        return "-"
    if _is_local_ip(ip):
        return "Local / WS Proxy"
    if ip in _ISP_CACHE:
        return _ISP_CACHE[ip]
    try:
        url = f"http://ip-api.com/json/{ip}?fields=status,isp,org"
        req = urllib.request.Request(url, headers={"User-Agent": "curl/7.88.1"})
        with urllib.request.urlopen(req, timeout=2.5) as resp:
            data = json.loads(resp.read().decode())
            isp = data.get("isp") or data.get("org") or "Tidak diketahui"
            _ISP_CACHE[ip] = isp
            return isp
    except Exception:
        return "Tidak diketahui"


def _get_xray_proto_map():
    proto_map = {}
    tags = [("###", "VMess"), ("#&", "VLESS"), ("#!", "Trojan"), ("#!#", "Shadowsocks")]
    try:
        with open("/etc/xray/config.json", errors="ignore") as f:
            for line in f:
                for tag, pname in tags:
                    if line.startswith(tag + " "):
                        parts = line.split()
                        if len(parts) >= 2:
                            u = parts[1].strip()
                            proto_map.setdefault(u, set()).add(pname)
    except Exception:
        pass
    return {u: " / ".join(sorted(pnames)) for u, pnames in proto_map.items()}


def _ssh_known_users():
    try:
        return set(S._daftar_akun("ssh"))
    except Exception:
        return set()


def _get_ws_ssh_map():
    ws_map = {}
    for path in ("/run/ws-ssh.map", "/tmp/ws-ssh.map"):
        if os.path.isfile(path):
            try:
                with open(path) as f:
                    for line in f:
                        parts = line.strip().split()
                        if len(parts) >= 3:
                            ws_map[parts[1]] = parts[2]
            except Exception:
                pass
    return ws_map


def _endpoint_port(endpoint):
    """Ambil port dari endpoint ss, IPv4 maupun IPv6."""
    m = re.search(r":(\d+)$", str(endpoint or ""))
    return m.group(1) if m else ""


def _ssh_active_users():
    """Ambil akun SSH/Dropbear/OpenVPN aktif beserta IP dan ISP.

    Return: dict user -> {"proto": str, "ip": str, "isp": str}
    """
    known = _ssh_known_users()
    if not known:
        return {}

    # Key adalah ID sesi (bukan hanya username) agar login kedua dari akun sama
    # tetap menghasilkan notifikasi CONNECT / DISCONNECT sendiri.
    active_users = {}
    pid_to_user = {}

    try:
        out = subprocess.run(
            ["ps", "-eo", "pid=,user=,args="], stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, timeout=15
        ).stdout
        for line in out.splitlines():
            parts = line.strip().split(None, 2)
            if len(parts) < 2:
                continue
            pid = parts[0]
            p_user = parts[1]
            p_args = parts[2] if len(parts) > 2 else ""

            # 1. OpenSSH master proses untuk satu sesi adalah yang bertanda
            # [priv]. Proses anak `sshd-session: user` memakai socket sama;
            # jangan masukkan agar satu login tidak memicu dua notifikasi.
            m = re.search(r"(?:sshd-session|sshd):\s+([^@\s\[]+)\s+\[priv\]", p_args)
            if m:
                u = m.group(1).strip()
                if u in known:
                    pid_to_user[pid] = (u, "SSH")

            # 2. Dropbear child session. Jangan jadikan semua proses milik akun
            # sebagai Dropbear: pada OpenSSH child shell juga berjalan sebagai user
            # dan akan menyebabkan satu koneksi dihitung dua kali.
            if p_user in known and "dropbear" in p_args.lower():
                pid_to_user[pid] = (p_user, "Dropbear")
    except Exception:
        pass

    # Ambil IP hanya dari socket transport SSH/Dropbear aktif.
    # Proses shell user juga memiliki koneksi keluar (Google, Telegram, dst); koneksi
    # tersebut bukan IP pelanggan dan tidak boleh dipakai sebagai sumber notifikasi.
    ssh_ports = {"22", "109", "143"}
    ws_map = _get_ws_ssh_map()
    session_ips = {}
    if pid_to_user:
        try:
            ss_out = subprocess.run(
                ["ss", "-Htnp", "state", "established"], stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, text=True, timeout=10
            ).stdout
            for line in ss_out.splitlines():
                cols = line.split()
                # ss -Htnp fields: Recv-Q, Send-Q, Local Address:Port,
                # Peer Address:Port, Process. Index local=2, peer=3.
                if len(cols) >= 5:
                    local = cols[2]
                    peer = cols[3]
                    # Baris valid hanya jika sisi lokal adalah listener SSH/Dropbear.
                    # Untuk SSH-over-WS, peer akan 127.0.0.1:<port> dan port tersebut
                    # kemudian diterjemahkan melalui /run/ws-ssh.map.
                    if _endpoint_port(local) not in ssh_ports:
                        continue
                    m_peer = re.match(r"^\[?([0-9a-fA-F:.]+)\]?:([0-9]+)$", peer)
                    if not m_peer:
                        continue
                    peer_ip, peer_port = m_peer.group(1), m_peer.group(2)
                    for pid, (u, pr) in pid_to_user.items():
                        if f"pid={pid}," in line:
                            rip = peer_ip
                            if peer_ip in ("127.0.0.1", "::1") and peer_port in ws_map:
                                rip = ws_map[peer_port]
                            # Jangan timpa IP asli dengan socket lain milik proses
                            # yang sama. Satu sesi SSH hanya membutuhkan satu socket
                            # transport pada port listener.
                            session_ips.setdefault(pid, (pr, rip))
        except Exception:
            pass

    for pid, (u, pr) in pid_to_user.items():
        # Hanya proses PID yang memang memiliki socket transport SSH. Ini mencegah
        # proses shell atau systemd-user ditafsirkan sebagai sesi SSH tambahan.
        if pid not in session_ips:
            continue
        pr_detected, ip_detected = session_ips[pid]
        if ip_detected == "-" or ip_detected in ("127.0.0.1", "::1"):
            # Fallback jika server menerima koneksi langsung tanpa WS mapping.
            try:
                cmd = f"grep -E '(Accepted password|auth succeeded) for .*\\b{u}\\b' /var/log/auth.log 2>/dev/null | tail -n 1"
                log_out = subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL).strip()
                if log_out:
                    m_ip = re.search(r"from\s+([0-9a-fA-F:.]+)", log_out)
                    if m_ip:
                        ip_detected = m_ip.group(1)
            except Exception:
                pass
        active_users[f"sshpid:{pid}"] = {
            "user": u,
            "proto": pr_detected,
            "ip": ip_detected,
            "isp": _get_isp(ip_detected)
        }

    # 3. OpenVPN connected clients
    for ovpn_log, proto_label in (("/etc/openvpn/server/openvpn-tcp.log", "OpenVPN TCP"),
                                  ("/etc/openvpn/server/openvpn-udp.log", "OpenVPN UDP")):
        if not os.path.isfile(ovpn_log):
            continue
        try:
            with open(ovpn_log, "r", errors="ignore") as f:
                for line in f:
                    if line.startswith("CLIENT_LIST,"):
                        cols = line.split(",")
                        if len(cols) > 2:
                            ou = cols[1].strip()
                            if ou in known and ou != "UNDEF":
                                oip = cols[2].split(":")[0].strip("[]")
                                # Remote-IP + virtual IP membedakan sesi OpenVPN
                                # ganda memakai username yang sama.
                                active_users[f"ovpn:{ou}:{oip}:{cols[3].strip() if len(cols) > 3 else ''}"] = {
                                    "user": ou,
                                    "proto": proto_label,
                                    "ip": oip,
                                    "isp": _get_isp(oip)
                                }
        except Exception:
            pass

    return active_users


def _tail(path, max_bytes=1_500_000):
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - max_bytes))
            raw = f.read()
        return raw.decode("utf-8", "ignore")
    except Exception:
        return ""


def _parse_xray_time(s):
    try:
        return DT.datetime.strptime(s, "%Y/%m/%d %H:%M:%S.%f").astimezone().timestamp()
    except Exception:
        try:
            return DT.datetime.strptime(s[:19], "%Y/%m/%d %H:%M:%S").astimezone().timestamp()
        except Exception:
            return 0.0


def _xray_active_users(now=None):
    """Akun Xray aktif beserta IP dan ISP jika punya trafik baru dalam _XRAY_IDLE detik."""
    now = now or time.time()
    proto_map = _get_xray_proto_map()
    if not proto_map:
        return {}

    active = {}
    text = _tail(_XRAY_LOG)
    for line in text.splitlines():
        m_user = re.search(r"\bemail:\s*([^\s]+)", line)
        if not m_user:
            continue
        user = m_user.group(1).strip()
        if user not in proto_map:
            continue
        m_time = re.match(r"^(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?)", line)
        if not m_time:
            continue
        seen = _parse_xray_time(m_time.group(1))
        if seen and (now - seen) <= _XRAY_IDLE:
            # Ambil client IP
            m_ip = re.search(r"from\s+(?:tcp:|udp:)?([0-9a-fA-F:.]+):[0-9]+", line)
            client_ip = m_ip.group(1) if m_ip else "-"
            # Simpan aktivitas paling baru
            if user not in active or seen >= active[user]["seen"]:
                active[user] = {
                    "seen": seen,
                    "proto": proto_map.get(user, "Xray"),
                    "ip": client_ip,
                }

    # Ambil ISP untuk setiap user aktif
    result = {}
    for u, info in active.items():
        cip = info["ip"]
        result[u] = {
            "proto": info["proto"],
            "ip": cip,
            "isp": _get_isp(cip)
        }
    return result


def _build_current_state(ssh_dict, xray_dict):
    users = {}
    for session_id, data in ssh_dict.items():
        users[session_id] = {
            "user": data.get("user", session_id),
            "proto": data.get("proto", "SSH"),
            "ip": data.get("ip", "-"),
            "isp": data.get("isp", "-")
        }
    for u, data in xray_dict.items():
        users[f"xray:{u}"] = {
            "user": u,
            "proto": data.get("proto", "Xray"),
            "ip": data.get("ip", "-"),
            "isp": data.get("isp", "-")
        }
    return {
        "v": 2,
        "updated": int(time.time()),
        "users": users
    }


def _pesan(status, proto, user, ip, isp):
    icon = "🟢" if status == "CONNECT" else "🔴"
    aksi = "TERHUBUNG" if status == "CONNECT" else "TERPUTUS"
    ip_label = "IP        " if status == "CONNECT" else "IP Terakhir"
    return (
        f"{icon} **NOTIFIKASI KONEKSI**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        f"Status    : **{aksi}**\n"
        f"Protokol  : `{proto}`\n"
        f"Akun      : `{user}`\n"
        f"{ip_label}: `{ip or '-'}`\n"
        f"ISP       : `{isp or '-'}`\n"
        f"Waktu     : `{DT.datetime.now().strftime('%d %b %Y %H:%M:%S')}`\n"
        "━━━━━━━━━━━━━━━━━━━━━"
    )


async def cek_perubahan_koneksi(force=False):
    """Cek perubahan koneksi dan kirim notifikasi ke admin jika status berubah."""
    now = time.time()
    ssh_dict = _ssh_active_users()
    xray_dict = _xray_active_users(now)
    current = _build_current_state(ssh_dict, xray_dict)
    previous = _load_state()

    # Baseline pertama saat bot baru start: simpan tanpa kirim notifikasi lama
    if previous is None:
        _save_state(current)
        logging.info("monitor koneksi baseline: ssh=%d xray=%d", len(ssh_dict), len(xray_dict))
        return {"baseline": True, "ssh": len(ssh_dict), "xray": len(xray_dict), "events": []}

    cur_users = current.get("users", {})
    prev_users = previous.get("users", {})

    events = []
    # User baru yang baru konek
    for k in sorted(set(cur_users.keys()) - set(prev_users.keys())):
        d = cur_users[k]
        events.append(("CONNECT", d["proto"], d["user"], d["ip"], d["isp"]))

    # User yang baru saja putus
    for k in sorted(set(prev_users.keys()) - set(cur_users.keys())):
        d = prev_users[k]
        events.append(("DISCONNECT", d["proto"], d["user"], d["ip"], d["isp"]))

    _save_state(current)

    if conn_notif_aktif() or force:
        for status, proto, user, ip, isp in events[:_MAX_NOTIFY_PER_CYCLE]:
            await _kirim_admin(_pesan(status, proto, user, ip, isp))
        if len(events) > _MAX_NOTIFY_PER_CYCLE:
            await _kirim_admin(
                f"⚠️ **MONITOR KONEKSI**\nAda `{len(events)}` perubahan status; dibatasi `{_MAX_NOTIFY_PER_CYCLE}` pesan per siklus."
            )

    if events:
        logging.info("monitor koneksi events: %s", events)
    return {"baseline": False, "events": events}


async def tes_notif_koneksi(proto="VMess", user="testuser", ip="114.122.14.88", isp="Telkomsel Indonesia"):
    """Kirim tes notifikasi ke semua admin dengan contoh IP & ISP."""
    return await _kirim_admin(_pesan("CONNECT", proto, user, ip, isp))
