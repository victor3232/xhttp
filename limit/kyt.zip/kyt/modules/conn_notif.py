# -*- coding: utf-8 -*-
# ============================================================
# modules/conn_notif.py - Notifikasi status koneksi ke admin
#   SSH/Dropbear : sesi sshd-session aktif (real-time)
#   Xray         : aktivitas terbaru access.log (idle >= 90 detik = putus)
# ============================================================
import os
import re
import json
import time
import asyncio
import logging
import subprocess
import datetime as DT

from kyt import bot, get_db
from kyt import store_lib as S

_STATE_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "connection_state.json")
_XRAY_LOG = "/var/log/xray/access.log"
_XRAY_IDLE = 90       # Xray tidak memberi event disconnect; inactivity ini dianggap putus
_MAX_NOTIFY_PER_CYCLE = 30


def conn_notif_aktif():
    return str(S.get_setting("conn_notif_aktif", "0")).strip() == "1"


def _admins():
    try:
        x = get_db()
        rows = x.execute("SELECT user_id FROM admin").fetchall()
        x.close()
        return sorted({str(r["user_id"]).strip() for r in rows if str(r["user_id"]).strip()})
    except Exception:
        return []


async def _kirim_admin(teks):
    sukses = False
    for uid in _admins():
        try:
            await bot.send_message(int(uid), teks, parse_mode="md")
            sukses = True
        except Exception as e:
            logging.error("notif koneksi ke admin %s gagal: %s", uid, e)
    return sukses


def _load_state():
    try:
        with open(_STATE_FILE) as f:
            data = json.load(f)
        if isinstance(data, dict) and "ssh" in data and "xray" in data:
            return data
    except Exception:
        pass
    return None


def _save_state(state):
    try:
        temp = _STATE_FILE + ".tmp"
        with open(temp, "w") as f:
            json.dump(state, f, indent=2, sort_keys=True)
        os.replace(temp, _STATE_FILE)
    except Exception as e:
        logging.error("gagal simpan state koneksi: %s", e)


def _ssh_active_users():
    """Ambil akun SSH aktif dari master sshd-session [priv]. Root tidak dihitung."""
    users = set()
    try:
        out = subprocess.run(
            ["ps", "-eo", "args="], stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, timeout=15
        ).stdout
        for line in out.splitlines():
            # Debian 13: sshd-session: bansos [priv]
            m = re.search(r"(?:sshd-session|sshd):\s+([^\s]+)\s+\[priv\]", line)
            if m:
                user = m.group(1).strip()
                if user and user not in ("root", "sshd", "nobody"):
                    users.add(user)
    except Exception:
        pass
    return users


def _tail(path, max_bytes=1_500_000):
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - max_bytes))
            raw = f.read()
        return raw.decode("utf-8", "ignore")
    except Exception:
        return ""


def _xray_known_users():
    users = set()
    try:
        for tipe in ("vmess", "vless", "trojan", "ss"):
            users.update(S._daftar_akun(tipe))
    except Exception:
        pass
    return users


def _parse_xray_time(s):
    try:
        # format access.log: 2026/11/02 22:58:29.134647
        return DT.datetime.strptime(s, "%Y/%m/%d %H:%M:%S.%f").astimezone().timestamp()
    except Exception:
        try:
            return DT.datetime.strptime(s[:19], "%Y/%m/%d %H:%M:%S").astimezone().timestamp()
        except Exception:
            return 0.0


def _xray_active_users(now=None):
    """Akun Xray aktif jika punya trafik baru dalam _XRAY_IDLE detik."""
    now = now or time.time()
    known = _xray_known_users()
    if not known:
        return set()

    active = set()
    text = _tail(_XRAY_LOG)
    # Hanya baca baris yang memuat email dan timestamp, lalu validasi user memang akun Xray
    for line in text.splitlines():
        m_user = re.search(r"\bemail:\s*([^\s]+)", line)
        if not m_user:
            continue
        user = m_user.group(1).strip()
        if user not in known:
            continue
        m_time = re.match(r"^(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?)", line)
        if not m_time:
            continue
        seen = _parse_xray_time(m_time.group(1))
        if seen and (now - seen) <= _XRAY_IDLE:
            active.add(user)
    return active


def _state(ssh_users, xray_users):
    return {
        "v": 1,
        "updated": int(time.time()),
        "ssh": {u: 1 for u in sorted(ssh_users)},
        "xray": {u: 1 for u in sorted(xray_users)},
    }


def _users(state, tipe):
    try:
        return set((state.get(tipe) or {}).keys())
    except Exception:
        return set()


def _pesan(status, tipe, user):
    icon = "🟢" if status == "CONNECT" else "🔴"
    label = "SSH / OVPN" if tipe == "ssh" else "XRAY (VMess / VLESS / Trojan / SS)"
    aksi = "TERHUBUNG" if status == "CONNECT" else "TERPUTUS"
    extra = ("Sesi SSH aktif terdeteksi." if tipe == "ssh" else
             "Tidak ada aktivitas Xray selama ±%d detik." % _XRAY_IDLE)
    return (
        "%s **NOTIFIKASI KONEKSI**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        "Status   : **%s**\n"
        "Protokol : `%s`\n"
        "Akun     : `%s`\n"
        "Waktu    : `%s`\n"
        "Info     : %s\n"
        "━━━━━━━━━━━━━━━━━━━━━"
    ) % (icon, aksi, label, user, DT.datetime.now().strftime("%d %b %Y %H:%M:%S"), extra)


async def cek_perubahan_koneksi(force=False):
    """Cek perubahan sesi; kirim notifikasi hanya pada transisi status.

    Saat state pertama dibuat / bot restart, kondisi awal hanya dijadikan baseline
    sehingga admin tidak menerima spam akun yang sudah lama terkoneksi.
    """
    now = time.time()
    ssh_now = _ssh_active_users()
    xray_now = _xray_active_users(now)
    current = _state(ssh_now, xray_now)
    previous = _load_state()

    # Baseline pertama: tidak kirim notifikasi lama
    if previous is None:
        _save_state(current)
        logging.info("monitor koneksi baseline: ssh=%d xray=%d", len(ssh_now), len(xray_now))
        return {"baseline": True, "ssh": ssh_now, "xray": xray_now, "events": []}

    events = []
    for tipe, now_users in (("ssh", ssh_now), ("xray", xray_now)):
        before = _users(previous, tipe)
        for user in sorted(now_users - before):
            events.append(("CONNECT", tipe, user))
        for user in sorted(before - now_users):
            events.append(("DISCONNECT", tipe, user))

    _save_state(current)

    if conn_notif_aktif() or force:
        for status, tipe, user in events[:_MAX_NOTIFY_PER_CYCLE]:
            await _kirim_admin(_pesan(status, tipe, user))
        if len(events) > _MAX_NOTIFY_PER_CYCLE:
            await _kirim_admin("⚠️ **MONITOR KONEKSI**\nAda `%d` perubahan koneksi; notifikasi dibatasi `%d` per putaran."
                               % (len(events), _MAX_NOTIFY_PER_CYCLE))

    if events:
        logging.info("monitor koneksi: %s", events)
    return {"baseline": False, "ssh": ssh_now, "xray": xray_now, "events": events}


async def tes_notif_koneksi():
    """Kirim satu tes notif ke semua admin tanpa mengubah state monitor."""
    return await _kirim_admin(
        "🧪 **TES NOTIFIKASI KONEKSI**\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        "Status   : **BERHASIL**\n"
        "Monitor SSH dan Xray siap digunakan.\n"
        "SSH dicek tiap 15 detik; Xray dinilai putus jika idle ±%d detik.\n"
        "━━━━━━━━━━━━━━━━━━━━━" % _XRAY_IDLE
    )
