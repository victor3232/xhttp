from kyt import *
from kyt import store_lib as S


@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" SSH OVPN MANAGER ","ssh")],
[Button.inline(" VMESS MANAGER ","vmess"),
Button.inline(" VLESS MANAGER ","vless")],
[Button.inline(" TROJAN MANAGER ","trojan"),
Button.inline(" SHADOWSOCKS MANAGER ","shadowsocks")],
[Button.inline(" L2TP / IKEv2 MANAGER ","l2tp")],
[Button.inline(" CHECK VPS INFO ","info"),
Button.inline(" OTHER SETTING ","setting")],
[Button.inline(" STORE & PEMBAYARAN ","storeadmin")],
[Button.inline(" ‹ Back Menu › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		namaos = sh_out(" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").strip().replace('"', '')
		ipsaya = sh_out(" curl -s ipv4.icanhazip.com").strip()
		city = sh_out(" cat /etc/xray/city").strip()

		# Angka diambil dari berkas akun VPS (sumber kebenaran),
		# supaya sinkron dengan yang ditampilkan bot.
		try:
			angk = S.hitung_akun_sistem()
			beda = S.akun_beda()
		except Exception as e:
			logging.error("hitung akun gagal: %s", e)
			angk = {t: 0 for t in S.URUT_AKUN}
			beda = False

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**ADMIN PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━
OS       : `{namaos}`
City     : `{city}`
Domain   : `{DOMAIN}`
IP VPS   : `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━
**Total Akun di VPS : `{angk["total"]}`**
SSH/OVPN     : `{angk["ssh"]}`
VMess        : `{angk["vmess"]}`
VLESS        : `{angk["vless"]}`
Trojan       : `{angk["trojan"]}`
Shadowsocks  : `{angk["ss"]}`
L2TP/IKEv2   : `{angk["l2tp"]}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
		if beda:
			msg += ("_Ada selisih dengan catatan bot. Buka "
			        "STORE & PEMBAYARAN > Statistik untuk rinciannya._\n"
			        "━━━━━━━━━━━━━━━━━━━━━━━\n")
		await safe_send_photo(event, S.gambar_start(), msg, inline)
