from kyt import *
from kyt import store_lib as S


@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" SSH OVPN ","ssh"),
Button.inline(" VMESS ","vmess")],
[Button.inline(" VLESS ","vless"),
Button.inline(" TROJAN ","trojan")],
[Button.inline(" SHADOWSOCKS ","shadowsocks"),
Button.inline(" L2TP / IKEv2 ","l2tp")],
[Button.inline(" ALL XRAY ","allxray"),
Button.inline(" TRIAL SETTINGS ","trial-settings")],
[Button.inline(" CHECK VPS INFO ","info"),
Button.inline(" OTHER SETTING ","setting")],
[Button.inline(" MULTI-SERVER ","multiserver")],
[Button.inline(" STORE & PEMBAYARAN ","storeadmin")],
[Button.inline(" ‹ Back Menu › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		namaos = sh_out(" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").strip().replace('"', '')
		ipsaya = sh_out(" curl -s ipv4.icanhazip.com").strip()
		city = sh_out(" cat /etc/xray/city").strip()
		# DOMAIN dari var.txt, kalau kosong ambil dari berkas panel (/etc/xray/domain)
		dom = S.cfg("DOMAIN", "") or "-"

		# Angka diambil dari SATU sumber kebenaran (sinkron dgn server)
		try:
			angk = S.hitung_akun_sistem()
			beda = S.akun_beda()
		except Exception as e:
			logging.error("hitung akun gagal: %s", e)
			angk = {t: 0 for t in S.URUT_AKUN}
			angk["total"] = 0
			beda = False

		# CATATAN: jangan menaruh `code` DI DALAM **bold** — Telegram menolak
		# nested formatting, pesan jadi plain dan semua tanda ** ` muncul mentah.
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**ADMIN PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━
OS       : `{namaos}`
City     : `{city}`
Domain   : `{dom}`
IP VPS   : `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━
Total Akun di VPS : **{angk["total"]}**
SSH/OVPN     : **{angk["ssh"]}**
VMess        : **{angk["vmess"]}**
VLESS        : **{angk["vless"]}**
Trojan       : **{angk["trojan"]}**
Shadowsocks  : **{angk["ss"]}**
L2TP/IKEv2   : **{angk["l2tp"]}**
━━━━━━━━━━━━━━━━━━━━━━━
"""
		if beda:
			msg += ("━━━━━━━━━━━━━━━━━━━━━━━\n"
			        "Catatan: ada selisih dengan data bot.\n"
			        "Buka STORE & PEMBAYARAN > Statistik\n"
			        "untuk rinciannya.\n"
			        "━━━━━━━━━━━━━━━━━━━━━━━\n")
		await safe_send_photo(event, S.gambar_start(), msg, inline)
