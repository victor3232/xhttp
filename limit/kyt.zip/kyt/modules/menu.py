from kyt import *
from kyt import store_lib as S

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" SSH OVPN MANAGER ","ssh")],
[Button.inline(" VMESS MANAGER ","vmess"),
Button.inline(" VLESS MANAGER ","vless")],
[Button.inline(" TROJAN MANAGER ","trojan"),
Button.inline(" SHADOWSOCKS MANAGER ","shadowsocks")],
[Button.inline(" CHECK VPS INFO ","info"),
Button.inline(" OTHER SETTING ","setting")],
[Button.inline(" STORE & PEMBAYARAN ","storeadmin")],
[Button.inline(" ‹ Back Menu › ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = "awk -F: '$3 >= 1000 && $1 != \"nobody\"' /etc/passwd | grep -c -E 'false|nologin'"
		ssh = sh_out(sh).strip() or "0"
		vms = sh_out(' cat /etc/vmess/.vmess.db | grep "###" | wc -l').strip() or "0"
		vls = sh_out(' cat /etc/vless/.vless.db | grep "###" | wc -l').strip() or "0"
		trj = sh_out(' cat /etc/trojan/.trojan.db | grep "###" | wc -l').strip() or "0"
		namaos = sh_out(" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'").strip().replace('"', '')
		ipsaya = sh_out(" curl -s ipv4.icanhazip.com").strip()
		city = sh_out(" cat /etc/xray/city").strip()

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**ADMIN PANEL MENU**
━━━━━━━━━━━━━━━━━━━━━━━
OS       : `{namaos}`
City     : `{city}`
Domain   : `{DOMAIN}`
IP VPS   : `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━
**Total Akun Dibuat**
SSH OVPN     : `{ssh}`
XRAY VMESS   : `{vms}`
XRAY VLESS   : `{vls}`
XRAY TROJAN  : `{trj}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
		await safe_send_photo(event, S.gambar_start(), msg, inline)
