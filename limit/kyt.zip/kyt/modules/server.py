# -*- coding: utf-8 -*-
# ============================================================
#  modules/server.py - menu MULTI-SERVER untuk ADMIN
#
#  Satu bot bisa menjual akun di beberapa VPS.
#  Server 1 = rumah (VPS tempat bot dipasang).
#  Server lain ditambahkan dengan URL agent + API Key + Secret.
# ============================================================
from kyt import *
from kyt import node_lib as N
from kyt import store_lib as S

GARIS = "━" * 23


def _adm_ok(event):
    return valid(str(event.sender_id)) == "true"

def _txt(v):
    """Callback regex Telethon mengembalikan bytes untuk grup teks."""
    if isinstance(v, (bytes, bytearray)):
        return v.decode("ascii", "ignore")
    return str(v or "")


def _label(s):
    if int(s["is_home"] or 0) == 1:
        return "Utama"
    return "Node %d" % int(s["id"])


def _status(s):
    if not int(s["active"] or 0):
        return "NONAKTIF"
    if N.server_online(s):
        return "ONLINE"
    if str(s["last_error"] or "").strip():
        return "ERROR"
    return "BELUM DICEK"


def _mode(s):
    return "Agent" if str(s["base_url"] or "").strip() else "Lokal"


def _ringkas_akun(s):
    d = N.akun_server(s)
    if not d:
        return "-"
    urut = ("ssh", "vmess", "vless", "trojan")
    return " · ".join("%s %s" % (t.upper(), d.get(t, 0)) for t in urut
                      if t in d) or "-"


def _teks_daftar():
    rows = []
    teks = f"""
{GARIS}
**🌐 MULTI-SERVER**
{GARIS}
Satu bot, banyak VPS.
Pelanggan bisa pilih server saat membeli.
{GARIS}
"""
    for i, s in enumerate(N.servers(), 1):
        teks += (
            "**%d. %s**\n"
            "   %s · %s\n"
            "   `%s`\n"
            "   Akun: %s\n"
        ) % (i, s["name"], _status(s), _mode(s),
             (s["base_url"] or "mode lokal"), _ringkas_akun(s))
        if str(s["last_error"] or "").strip():
            teks += "   ⚠️ `%s`\n" % str(s["last_error"])[:90]
    teks += f"""{GARIS}
Tekan **nama server** untuk atur koneksi, produk,
harga, limit IP, dan quota. Tidak ada setting
harga di menu Store lama.
{GARIS}"""
    return teks


def _tombol_daftar():
    rows = []
    for s in N.servers():
        rows.append([Button.inline("🌐 %s" % s["name"][:34],
                                   "ms-v-%d" % int(s["id"]))])
    rows.append([Button.inline("➕ Tambah Server", "ms-add")])
    rows.append([Button.inline("🩺 Test Semua", "ms-testall"),
                 Button.inline("‹ Menu ›", "menu")])
    return rows


@bot.on(events.CallbackQuery(data=b'multiserver'))
async def ms_home(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await safe_send(event, _teks_daftar(), _tombol_daftar())


# ---------------- tambah server ----------------
def _val_nama(t):
    t = (t or "").strip()
    if len(t) < 2:
        return False, "Nama minimal 2 huruf."
    if len(t) > 40:
        return False, "Nama maksimal 40 huruf."
    return True, ""


def _val_url(t):
    t = (t or "").strip().rstrip("/")
    if not t.startswith("https://"):
        return False, "URL harus diawali https://"
    if " " in t:
        return False, "URL tidak boleh ada spasi."
    return True, ""


def _val_wajib(t):
    if not (t or "").strip():
        return False, "Tidak boleh kosong."
    return True, ""


def _val_secret(t):
    t = (t or "").strip()
    if len(t) < 16:
        return False, "Secret terlalu pendek (minimal 16 karakter)."
    return True, ""


@bot.on(events.CallbackQuery(data=b'ms-add'))
async def ms_add(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    nama = await tanya(event, "**➕ TAMBAH SERVER**\n\n"
                              "Nama server, contoh: `VPS B - Jakarta`\n\n"
                              "Ketik `-` untuk batal.", validasi=_val_nama)
    if not nama:
        return
    url = await tanya(event, "**URL agent VPS baru**\n\n"
                            "Contoh: `https://node.domain.com:8787`\n"
                            "Harus https dan domain DNS-only (bukan orange cloud).\n\n"
                            "Ketik `-` untuk batal.", validasi=_val_url)
    if not url:
        return
    api_key = await tanya(event, "**API Key node**\n\n"
                                "Ambil dari hasil install agent / `kyt-node show`.\n\n"
                                "Ketik `-` untuk batal.", validasi=_val_wajib)
    if not api_key:
        return
    secret = await tanya(event, "**Secret node**\n\n"
                               "Ambil dari hasil install agent.\n"
                               "Kalau sudah lupa: di VPS node jalankan `kyt-node rotate`.\n\n"
                               "Ketik `-` untuk batal.", validasi=_val_secret)
    if not secret:
        return
    code = await tanya(event, "**Kode node** (dari installer, contoh `id-2`)\n\n"
                              "Ketik `-` kalau tidak tahu / biarkan otomatis.",
                       boleh_batal=False)
    code = "" if (code or "").strip() in ("", "-", "otomatis") else code.strip()

    await safe_send(event, "⏳ **Menguji koneksi ke node...**")
    try:
        data = await asyncio.to_thread(N.test_credentials, url, api_key, secret, code or "test")
    except Exception as exc:
        await safe_send(
            event,
            "❌ **Gagal terhubung ke node.**\n\n```\n%s\n```\n"
            "Periksa:\n"
            "• URL https dan port 8787 terbuka\n"
            "• API Key & Secret benar\n"
            "• domain node DNS-only, cert valid\n"
            "• IP VPS bot diizinkan di node" % str(exc)[-600:],
            buttons=[[Button.inline("🔁 Coba Tambah Lagi", "ms-add")],
                     [Button.inline("‹ Multi-Server ›", "multiserver")]])
        return

    sid = N.add_server(nama.strip(), url, api_key, secret, code=code,
                       premium=1, free=0)
    await asyncio.to_thread(N.check_server, sid)
    s = N.server_by_id(sid)
    await safe_send(
        event,
        "✅ **SERVER BERHASIL DITAMBAH**\n\n"
        "Nama  : `%s`\n"
        "Kode  : `%s`\n"
        "URL   : `%s`\n"
        "Versi : `%s`\n\n"
        "Produk 4 tipe × 3/7/30 sudah dibuat.\n"
        "Atur harga/limit lewat **Setting Produk**." % (
            s["name"], s["code"], s["base_url"], data.get("version") or "-"),
        buttons=[[Button.inline("⚙️ Setting Produk", "ms-prod-%d" % sid)],
                 [Button.inline("‹ Multi-Server ›", "multiserver")]])


# ---------------- detail server ----------------
@bot.on(events.CallbackQuery(pattern=r'^ms-v-(\d+)$'))
async def ms_view(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    sid = int(event.pattern_match.group(1))
    s = N.server_by_id(sid)
    if not s:
        await event.answer("Server tidak ada.", alert=True)
        return
    teks = f"""
{GARIS}
**🌐 {s['name']}**
{GARIS}
Posisi  : `{_label(s)}`
Status  : {_status(s)}
Mode    : `{_mode(s)}`
URL     : `{s['base_url'] or 'lokal (VPS bot)'}`
Kode    : `{s['code']}`
Premium : {'✅ ON' if int(s['premium_enabled'] or 0) else '⛔ OFF'}
Free    : {'✅ ON' if int(s['free_enabled'] or 0) else '⛔ OFF'}
Akun    : {_ringkas_akun(s)}
Versi   : `{s['last_version'] or '-'}`
{GARIS}"""
    if str(s["last_error"] or "").strip():
        teks += "\n⚠️ Error: `%s`\n" % str(s["last_error"])[:150]
    rows = [
        [Button.inline("🩺 Test Koneksi", "ms-test-%d" % sid),
         Button.inline("⚙️ Setting Produk", "ms-prod-%d" % sid)],
        [Button.inline("✏️ Ganti Nama", "ms-ren-%d" % sid),
         Button.inline("🔑 Ganti Koneksi", "ms-conn-%d" % sid)],
        [Button.inline("%s Premium" % ("⛔ Matikan" if int(s["premium_enabled"] or 0) else "✅ Aktifkan"),
                       "ms-prem-%d" % sid),
         Button.inline("%s Free" % ("⛔ Matikan" if int(s["free_enabled"] or 0) else "✅ Aktifkan"),
                       "ms-free-%d" % sid)],
        [Button.inline("%s Server" % ("⛔ Nonaktifkan" if int(s["active"] or 0) else "✅ Aktifkan"),
                       "ms-act-%d" % sid)],
    ]
    if int(s["is_home"] or 0) != 1:
        rows.append([Button.inline("🗑️ Hapus Server", "ms-del-%d" % sid)])
    rows.append([Button.inline("‹ Multi-Server ›", "multiserver")])
    await safe_send(event, teks, rows)


@bot.on(events.CallbackQuery(pattern=r'^ms-test-(\d+)$'))
async def ms_test(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    sid = int(event.pattern_match.group(1))
    await event.answer("Menguji koneksi...")
    r = await asyncio.to_thread(N.check_server, sid)
    if r.get("ok"):
        await event.answer("Node online.", alert=True)
    else:
        await event.answer("Node gagal: %s" % str(r.get("error") or "-")[:150], alert=True)
    await ms_view(event)


@bot.on(events.CallbackQuery(data=b'ms-testall'))
async def ms_testall(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Menguji semua server...")
    await asyncio.to_thread(N.check_all)
    await safe_send(event, _teks_daftar(), _tombol_daftar())


@bot.on(events.CallbackQuery(pattern=r'^ms-ren-(\d+)$'))
async def ms_rename(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    sid = int(event.pattern_match.group(1))
    s = N.server_by_id(sid)
    if not s:
        return
    nama = await tanya(event, "**Nama baru untuk %s**\n\nKetik `-` untuk batal." % s["name"],
                       validasi=_val_nama)
    if not nama:
        return
    N.update_server(sid, name=nama.strip())
    await ms_view(event)


@bot.on(events.CallbackQuery(pattern=r'^ms-conn-(\d+)$'))
async def ms_conn(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    sid = int(event.pattern_match.group(1))
    s = N.server_by_id(sid)
    if not s:
        return
    url = await tanya(
        event,
        "**🔑 GANTI KONEKSI — %s**\n\n"
        "URL sekarang : `%s`\n\n"
        "**URL agent baru** (https://domain:8787)\n"
        "Ketik `-` untuk batal." % (s["name"], s["base_url"] or "lokal"),
        validasi=_val_url)
    if not url:
        return
    api_key = await tanya(event, "**API Key**\n\nKetik `-` batal.", validasi=_val_wajib)
    if not api_key:
        return
    secret = await tanya(event, "**Secret**\n\nKetik `-` batal.", validasi=_val_secret)
    if not secret:
        return
    await safe_send(event, "⏳ Menguji koneksi...")
    try:
        data = await asyncio.to_thread(N.test_credentials, url, api_key, secret, s["code"])
    except Exception as exc:
        await safe_send(event, "❌ Gagal: `%s`" % str(exc)[-400:],
                        [[Button.inline("‹ Kembali ›", "ms-v-%d" % sid)]])
        return
    N.update_server(sid, base_url=url, api_key=api_key, secret=secret)
    await asyncio.to_thread(N.check_server, sid)
    await safe_send(event, "✅ Koneksi diperbarui. Versi: `%s`" % (data.get("version") or "-"),
                    [[Button.inline("‹ Server ›", "ms-v-%d" % sid)]])


@bot.on(events.CallbackQuery(pattern=r'^ms-prem-(\d+)$'))
async def ms_premium(event):
    if not _adm_ok(event):
        return
    sid = int(event.pattern_match.group(1))
    s = N.server_by_id(sid)
    if not s:
        return
    N.update_server(sid, premium_enabled=0 if int(s["premium_enabled"] or 0) else 1)
    await ms_view(event)


@bot.on(events.CallbackQuery(pattern=r'^ms-free-(\d+)$'))
async def ms_free(event):
    if not _adm_ok(event):
        return
    sid = int(event.pattern_match.group(1))
    s = N.server_by_id(sid)
    if not s:
        return
    N.update_server(sid, free_enabled=0 if int(s["free_enabled"] or 0) else 1)
    await ms_view(event)


@bot.on(events.CallbackQuery(pattern=r'^ms-act-(\d+)$'))
async def ms_active(event):
    if not _adm_ok(event):
        return
    sid = int(event.pattern_match.group(1))
    s = N.server_by_id(sid)
    if not s:
        return
    N.update_server(sid, active=0 if int(s["active"] or 0) else 1)
    await ms_view(event)


@bot.on(events.CallbackQuery(pattern=r'^ms-del-(\d+)$'))
async def ms_delete_ask(event):
    if not _adm_ok(event):
        return
    sid = int(event.pattern_match.group(1))
    s = N.server_by_id(sid)
    if not s:
        return
    await safe_send(
        event,
        "⚠️ **HAPUS SERVER?**\n\n"
        "Server : `%s`\n\n"
        "Server dihapus dari bot. **Akun VPN di VPS tidak dihapus.**\n"
        "Order lama tetap tersimpan.\n\nLanjut?" % s["name"],
        buttons=[[Button.inline("🗑️ Ya, hapus", "ms-delyes-%d" % sid)],
                 [Button.inline("‹ Batal ›", "ms-v-%d" % sid)]])


@bot.on(events.CallbackQuery(pattern=r'^ms-delyes-(\d+)$'))
async def ms_delete_yes(event):
    if not _adm_ok(event):
        return
    sid = int(event.pattern_match.group(1))
    ok, msg = N.delete_server(sid)
    await event.answer(msg, alert=True)
    await safe_send(event, _teks_daftar(), _tombol_daftar())


# ---------------- setting produk per node ----------------
def _teks_produk(s):
    teks = f"""
{GARIS}
**⚙️ SETTING NODE {s['id']} — {s['name']}**
{GARIS}
Atur harga, limit IP, dan quota (GB) untuk
setiap masa aktif. Quota `0` = unlimited.
{GARIS}
"""
    tipe_now = None
    for p in N.server_products(int(s["id"])):
        if p["tipe"] != tipe_now:
            tipe_now = p["tipe"]
            teks += "\n**%s**\n" % N.TIPE_LABEL.get(tipe_now, tipe_now)
        teks += "  %2d hari : `%s` · IP `%s` · `%s` GB %s\n" % (
            int(p["hari"]), S.rupiah(int(p["harga"])), p["iplimit"],
            p["quota"], "" if int(p["aktif"] or 0) else " (OFF)")
    teks += f"\n{GARIS}\n⚡ Massal = atur 3/7/30 sekaligus.\n✏️ Per masa = atur satu per satu.\n{GARIS}"
    return teks


def _tombol_produk(s):
    rows = []
    # Massal per protokol (3/7/30 sekaligus)
    ada_tipe = {p["tipe"] for p in N.server_products(int(s["id"]))}
    buf = []
    for t in N.TIPE_JUAL:
        if t not in ada_tipe:
            continue
        buf.append(Button.inline("⚡ Massal %s" % t.upper(),
                                 "ms-bulk-%d-%s" % (int(s["id"]), t)))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    # Atur per masa aktif (kalau mau beda per durasi)
    buf = []
    for p in N.server_products(int(s["id"])):
        buf.append(Button.inline("✏️ %s %dh — %s" % (p["tipe"].upper(), int(p["hari"]), S.rupiah(int(p["harga"]))),
                                 "ms-set-%d-%s-%d" % (int(s["id"]), p["tipe"], int(p["hari"]))))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    home = N.home_server()
    if home and int(home["id"]) != int(s["id"]):
        rows.append([Button.inline("📋 Samakan dengan Node %d" % int(home["id"]),
                                   "ms-copy-%d" % int(s["id"]))])
    rows.append([Button.inline("‹ Server ›", "ms-v-%d" % int(s["id"]))])
    return rows


@bot.on(events.CallbackQuery(pattern=r'^ms-prod-(\d+)$'))
async def ms_products(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    sid = int(event.pattern_match.group(1))
    s = N.server_by_id(sid)
    if not s:
        return
    try:
        await event.reply(_teks_produk(s), buttons=_tombol_produk(s))
    except Exception:
        await safe_send(event, _teks_produk(s), _tombol_produk(s))


@bot.on(events.CallbackQuery(pattern=r'^ms-set-(\d+)-([a-z]+)-(\d+)$'))
async def ms_product_set(event):
    if not _adm_ok(event):
        return
    sid = int(event.pattern_match.group(1))
    tipe = _txt(event.pattern_match.group(2))
    hari = int(event.pattern_match.group(3))
    s = N.server_by_id(sid)
    logging.info("ms-set data=%r sid=%s tipe=%s hari=%s", event.data, sid, tipe, hari)
    p = N.server_product(sid, tipe, hari)
    if s and not p:
        N.set_server_product(sid, tipe, hari)
        p = N.server_product(sid, tipe, hari)
    if not s or not p:
        logging.warning("ms-set produk tidak ada sid=%s tipe=%s hari=%s", sid, tipe, hari)
        await event.answer("Produk tidak ada.", alert=True)
        return
    label = "%s %d HARI" % (N.TIPE_LABEL.get(tipe, tipe), hari)
    harga = await tanya(
        event,
        "**%s — HARGA**\n\n"
        "Harga sekarang: `%s`\n\n"
        "Ketik harga baru (angka rupiah), contoh `1000`.\n"
        "Ketik `-` untuk batal." % (label, S.rupiah(int(p["harga"]))),
        validasi=lambda x: _val_angka(x, None))
    if harga is None:
        return
    ip = await tanya(
        event,
        "**%s — LIMIT IP**\n\n"
        "Sekarang: `%s`\n\n"
        "Ketik angka. `0` = unlimited.\n"
        "Ketik `-` untuk batal." % (label, p["iplimit"]),
        validasi=lambda x: _val_angka(x, 100))
    if ip is None:
        return
    quota = await tanya(
        event,
        "**%s — QUOTA**\n\n"
        "Sekarang: `%s` GB\n\n"
        "Ketik angka GB. `0` = unlimited.\n"
        "Ketik `-` untuk batal." % (label, p["quota"]),
        validasi=lambda x: _val_angka(x, 10000))
    if quota is None:
        return
    N.set_server_product(sid, tipe, hari, harga=int(harga),
                         iplimit=int(ip), quota=int(quota))
    await event.answer("Tersimpan.")
    await ms_products(event)

def _val_angka(t, maks=None):
    v = (t or "").strip().replace(".", "").replace(",", "")
    if not v.isdigit():
        return False, "Harus angka."
    n = int(v)
    if maks is not None and n > maks:
        return False, "Maksimal %d." % maks
    return True, ""

def _val_harga_massal(t):
    b = (t or "").replace(".", "").replace(",", " ").split()
    if len(b) not in (1, 3):
        return False, "Isi 1 angka (semua sama) atau 3 angka (3/7/30)."
    if any(not x.isdigit() for x in b):
        return False, "Semua harus angka."
    return True, ""

@bot.on(events.CallbackQuery(pattern=r'^ms-bulk-(\d+)-([a-z]+)$'))
async def ms_bulk(event):
    if not _adm_ok(event):
        return
    sid = int(event.pattern_match.group(1))
    tipe = _txt(event.pattern_match.group(2))
    s = N.server_by_id(sid)
    if not s or tipe not in N.TIPE_JUAL:
        await event.answer("Server/protokol tidak valid.", alert=True)
        return
    prods = [p for p in N.server_products(sid) if p["tipe"] == tipe]
    if not prods:
        await event.answer("Produk protokol ini belum ada.", alert=True)
        return
    label = N.TIPE_LABEL.get(tipe, tipe)
    sekarang = ""
    for p in prods:
        sekarang += "  %d hari: %s · IP %s · %s GB\n" % (
            int(p["hari"]), S.rupiah(int(p["harga"])), p["iplimit"], p["quota"])

    harga = await tanya(
        event,
        "⚡ **MASSAL %s**\n\n"
        "Sekarang:\n%s\n"
        "Masukkan harga **3 / 7 / 30 hari**.\n"
        "Contoh: `1000 2500 10000`\n"
        "Kalau harga semua sama, cukup satu angka: `1000`\n\n"
        "Ketik `-` untuk batal." % (label, sekarang),
        validasi=_val_harga_massal)
    if harga is None:
        return
    bagian = (harga or "").replace(".", "").replace(",", " ").split()
    if len(bagian) == 1:
        harga_map = {h: int(bagian[0]) for h in N.HARI_JUAL}
    else:
        harga_map = dict(zip(N.HARI_JUAL, [int(x) for x in bagian]))

    ip = await tanya(
        event,
        "⚡ **MASSAL %s — LIMIT IP**\n\n"
        "Berlaku untuk 3, 7, dan 30 hari.\n"
        "Ketik angka. `0` = unlimited.\n\n"
        "Ketik `-` untuk batal." % label,
        validasi=lambda x: _val_angka(x, 100))
    if ip is None:
        return

    quota = await tanya(
        event,
        "⚡ **MASSAL %s — QUOTA**\n\n"
        "Berlaku untuk 3, 7, dan 30 hari.\n"
        "Ketik angka GB. `0` = unlimited.\n\n"
        "Ketik `-` untuk batal." % label,
        validasi=lambda x: _val_angka(x, 10000))
    if quota is None:
        return

    for h in N.HARI_JUAL:
        N.set_server_product(sid, tipe, h, harga=harga_map[h],
                             iplimit=int(ip), quota=int(quota))
    await event.answer("Massal %s tersimpan." % label)
    await ms_products(event)


@bot.on(events.CallbackQuery(pattern=r'^ms-copy-(\d+)$'))
async def ms_copy(event):
    if not _adm_ok(event):
        return
    sid = int(event.pattern_match.group(1))
    home = N.home_server()
    if not home or int(home["id"]) == sid:
        await event.answer("Server utama tidak tersedia.", alert=True)
        return
    ok, msg = N.copy_products(int(home["id"]), sid)
    await event.answer(msg, alert=not ok)
    await ms_products(event)
