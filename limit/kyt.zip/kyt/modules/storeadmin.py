# -*- coding: utf-8 -*-
# ============================================================
#  modules/storeadmin.py - pengaturan STORE untuk ADMIN
# ============================================================
from kyt import *
from kyt import store_lib as S


def _adm_ok(event):
    return valid(str(event.sender_id)) == "true"


@bot.on(events.CallbackQuery(data=b'storeadmin'))
async def sa_home(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    mc = S.dk_merchant()
    st = "PRODUCTION" if S.get_setting("duitku_sandbox", "0") != "1" else "SANDBOX"
    stat = "✅ siap" if S.dk_ready() else "❌ belum diisi"
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🏪 PENGATURAN STORE**
━━━━━━━━━━━━━━━━━━━━━━━
🔑 **Duitku :** {stat}
🏷️ **Merchant :** `{mc or '-'}`
🌐 **Mode :** `{st}`
💳 **Metode :** `{len(__import__('kyt').modules.deposit.metode_list())} tersedia`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("🔑 Setting Duitku", "sa-duitku")],
        [Button.inline("📦 Produk & Harga", "sa-produk"),
         Button.inline("💳 Metode Bayar", "sa-metode")],
        [Button.inline("📊 Statistik", "sa-stat"),
         Button.inline("🔄 Cek Deposit", "sa-cekd")],
        [Button.inline("‹ Main Menu ›", "menu")],
    ]
    await safe_send(event, teks, buttons=rows)


# ---------- Duitku ----------
@bot.on(events.CallbackQuery(data=b'sa-duitku'))
async def sa_duitku(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    chat = event.chat_id
    await safe_send(event, "🔑 **Masukkan Merchant Code Duitku** (atau kirim `-` untuk batal):")
    try:
        async with bot.conversation(chat) as conv:
            f1 = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m1 = await f1
    except Exception:
        return
    mc = (m1.raw_text or "").strip()
    if mc == "-":
        await event.reply("Dibatalkan.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    await event.reply("🔑 **Masukkan API Key Duitku:**")
    try:
        async with bot.conversation(chat) as conv:
            f2 = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m2 = await f2
    except Exception:
        return
    ak = (m2.raw_text or "").strip()
    S.set_setting("duitku_merchant", mc)
    S.set_setting("duitku_apikey", ak)
    await event.reply(
        "✅ Tersimpan.\n\nSekarang pilih mode:",
        buttons=[[Button.inline("🚀 PRODUCTION", "sa-mode-0"),
                  Button.inline("🧪 SANDBOX", "sa-mode-1")],
                 [Button.inline("‹ Store ›", "storeadmin")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-mode-'))
async def sa_mode(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    v = event.data.decode().replace("sa-mode-", "")
    S.set_setting("duitku_sandbox", v)
    await event.answer("Mode: %s" % ("SANDBOX" if v == "1" else "PRODUCTION"), alert=True)
    await sa_home(event)


# ---------- metode bayar ----------
@bot.on(events.CallbackQuery(data=b'sa-metode'))
async def sa_metode(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    mets = __import__('kyt').modules.deposit.metode_list()
    teks = "━━━━━━━━━━━━━━━━━━━━━━━\n**💳 METODE BAYAR AKTIF**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
    for m in mets:
        teks += "• `%s` — %s\n" % (m.get("code"), m.get("name"))
    teks += "━━━━━━━━━━━━━━━━━━━━━━━"
    await safe_send(event, teks, buttons=[
        [Button.inline("🔄 Sync dari Duitku", "sa-metode-sync")],
        [Button.inline("♻️ Reset Default", "sa-metode-reset")],
        [Button.inline("‹ Store ›", "storeadmin")]])


@bot.on(events.CallbackQuery(data=b'sa-metode-reset'))
async def sa_metode_reset(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    S.set_setting("metode", "")
    await event.answer("Direset ke default.", alert=True)
    await sa_metode(event)


@bot.on(events.CallbackQuery(data=b'sa-metode-sync'))
async def sa_metode_sync(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await safe_send(event, "⏳ **Mengambil metode dari Duitku...**")
    try:
        res = await __import__('asyncio').to_thread(S.duitku_methods, 10000)
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e, buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    lst = res.get("paymentMethod") or []
    if not lst:
        await safe_send(event, "❌ Tidak ada metode. Cek merchant/apikey.\n`%s`"
                         % res.get("responseMessage", "-"),
                         buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    data = [{"code": x.get("paymentMethod"), "name": x.get("paymentName")} for x in lst]
    S.set_setting("metode", json.dumps(data))
    await safe_send(event, "✅ **%d metode tersimpan.**" % len(data),
                     buttons=[[Button.inline("💳 Lihat", "sa-metode")],
                              [Button.inline("‹ Store ›", "storeadmin")]])


# ---------- produk ----------
@bot.on(events.CallbackQuery(data=b'sa-produk'))
async def sa_produk(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    rows = []
    for p in S.produk_semua():
        tanda = "✅" if p["aktif"] else "⛔"
        rows.append([Button.inline("%s %s — %s" % (tanda, p["nama"], S.rupiah(p["harga"])),
                                   "sa-prod-%d" % p["id"])])
    rows.append([Button.inline("‹ Store ›", "storeadmin")])
    await safe_send(event, "━━━━━━━━━━━━━━━━━━━━━━━\n**📦 PRODUK & HARGA**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
                     "Pilih produk untuk ubah 👇", buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^sa-prod-\d+$'))
async def sa_prod(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-prod-", ""))
    x = S.db()
    p = x.execute("SELECT * FROM produk WHERE id=?", (pid,)).fetchone()
    x.close()
    if not p:
        await event.answer("Tidak ada.", alert=True)
        return
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**📦 {p['nama']}**
━━━━━━━━━━━━━━━━━━━━━━━
🏷️ Kode   : `{p['kode']}`
🔖 Tipe   : `{p['tipe']}`
💵 Harga  : `{S.rupiah(p['harga'])}`
🗓️ Hari   : `{p['hari']}`
📊 Kuota  : `{p['quota']} GB`
🌐 LimitIP: `{p['iplimit']}`
✅ Aktif  : `{'YA' if p['aktif'] else 'TIDAK'}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[
        [Button.inline("💵 Ubah Harga", "sa-pe-harga-%d" % pid),
         Button.inline("🗓️ Ubah Hari", "sa-pe-hari-%d" % pid)],
        [Button.inline("📊 Kuota", "sa-pe-quota-%d" % pid),
         Button.inline("🌐 Limit IP", "sa-pe-ip-%d" % pid)],
        [Button.inline("✅/⛔ Aktif", "sa-pe-toggle-%d" % pid),
         Button.inline("🗑️ Hapus", "sa-pe-hapus-%d" % pid)],
        [Button.inline("‹ Produk ›", "sa-produk")]])


async def _minta_angka(event, judul):
    chat = event.chat_id
    await safe_send(event, judul)
    try:
        async with bot.conversation(chat) as conv:
            fut = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m = await fut
    except Exception:
        return None
    t = (m.raw_text or "").strip()
    return t


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-(harga|hari|quota|ip)-\d+$'))
async def sa_pe_field(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    d = event.data.decode()
    field = d.split("-")[2]
    pid = int(d.split("-")[3])
    label = {"harga": "harga (angka, rupiah)", "hari": "masa aktif (hari)",
             "quota": "kuota GB (0 = unlimited)", "ip": "limit IP (0 = unlimited)"}[field]
    val = await _minta_angka(event, "✏️ **Masukkan %s:**" % label)
    if val is None:
        return
    col = {"harga": "harga", "hari": "hari", "quota": "quota", "ip": "iplimit"}[field]
    try:
        iv = int(val)
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])
        return
    x = S.db()
    x.execute("UPDATE produk SET %s=? WHERE id=?" % col, (iv, pid))
    x.commit()
    x.close()
    await event.reply("✅ Tersimpan.", buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-toggle-\d+$'))
async def sa_pe_toggle(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-pe-toggle-", ""))
    x = S.db()
    x.execute("UPDATE produk SET aktif = 1 - aktif WHERE id=?", (pid,))
    x.commit()
    x.close()
    await event.answer("Diubah.", alert=True)
    await sa_produk(event)


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-hapus-\d+$'))
async def sa_pe_hapus(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-pe-hapus-", ""))
    x = S.db()
    x.execute("DELETE FROM produk WHERE id=?", (pid,))
    x.commit()
    x.close()
    await event.answer("Produk dihapus.", alert=True)
    await sa_produk(event)


# ---------- statistik ----------
@bot.on(events.CallbackQuery(data=b'sa-stat'))
async def sa_stat(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    x = S.db()
    tot_order = x.execute("SELECT COUNT(*) c FROM pesanan").fetchone()["c"]
    tot_omset = x.execute("SELECT COALESCE(SUM(harga),0) s FROM pesanan").fetchone()["s"]
    tot_user = x.execute("SELECT COUNT(*) c FROM store_user").fetchone()["c"]
    tot_saldo = x.execute("SELECT COALESCE(SUM(saldo),0) s FROM store_user").fetchone()["s"]
    dep_paid = x.execute("SELECT COALESCE(SUM(amount),0) s FROM deposit WHERE status='PAID'").fetchone()["s"]
    dep_pend = x.execute("SELECT COUNT(*) c FROM deposit WHERE status='PENDING'").fetchone()["c"]
    x.close()
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**📊 STATISTIK STORE**
━━━━━━━━━━━━━━━━━━━━━━━
👥 **User terdaftar :** `{tot_user}`
📦 **Akun terjual   :** `{tot_order}`
💵 **Total penjualan:** `{S.rupiah(tot_omset)}`
💰 **Saldo user     :** `{S.rupiah(tot_saldo)}`
🧾 **Deposit masuk  :** `{S.rupiah(dep_paid)}`
⏳ **Deposit pending:** `{dep_pend}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[[Button.inline("‹ Store ›", "storeadmin")]])


@bot.on(events.CallbackQuery(data=b'sa-cekd'))
async def sa_cekd(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Mengecek deposit pending...")
    await __import__('kyt').modules.deposit.cek_semua_pending()
    await event.answer("Selesai dicek.", alert=True)
    await sa_stat(event)


@bot.on(events.NewMessage(pattern=r"^/(cekd|ceksaldo)$"))
async def cmd_cekd(event):
    if not _adm_ok(event):
        return
    await __import__('kyt').modules.deposit.cek_semua_pending()
    await event.reply("✅ Deposit pending sudah dicek ulang.")


# ---------- kelola saldo user ----------
@bot.on(events.CallbackQuery(data=b'sa-kelola'))
async def sa_kelola(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    chat = event.chat_id
    await safe_send(event, "👤 **Masukkan ID Telegram user:**")
    try:
        async with bot.conversation(chat) as conv:
            f1 = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m1 = await f1
    except Exception:
        return
    uid = (m1.raw_text or "").strip()
    u = S.get_user(uid)
    if not u:
        await event.reply("❌ User tidak ada.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    await event.reply("👤 `%s`\n💰 Saldo: `%s`\n\nMasukkan nominal (+ tambah / - kurang):"
                      % (uid, S.rupiah(u["saldo"])),
                      buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
    try:
        async with bot.conversation(chat) as conv:
            f2 = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m2 = await f2
    except Exception:
        return
    t = (m2.raw_text or "").strip()
    try:
        n = int(t)
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    if n >= 0:
        S.saldo_tambah(uid, n)
    else:
        S.saldo_kurang(uid, -n)
    u2 = S.get_user(uid)
    await event.reply("✅ Saldo `%s` sekarang: `%s`" % (uid, S.rupiah(u2["saldo"])),
                      buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
