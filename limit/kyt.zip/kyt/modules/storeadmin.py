# -*- coding: utf-8 -*-
# ============================================================
#  modules/storeadmin.py - pengaturan STORE untuk ADMIN
# ============================================================
from kyt import *
from kyt import store_lib as S


def _adm_ok(event):
    return valid(str(event.sender_id)) == "true"


@bot.on(events.CallbackQuery(data=b'storeadmin'))
async def sa_home(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    mc = S.dk_merchant()
    st = "PRODUCTION" if not S.dk_dev() else "SANDBOX"
    stat = "✅ siap" if S.dk_ready() else "❌ belum diisi"
    try:
        from kyt.modules.notif import notif_aktif, notif_hari
        nstat = "✅ H-%s" % ", H-".join(str(x) for x in notif_hari()) if notif_aktif() else "⛔ mati"
    except Exception:
        nstat = "-"
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🏪 PENGATURAN STORE**
━━━━━━━━━━━━━━━━━━━━━━━
🔑 **Duitku :** {stat}
🏷️ **Merchant :** `{mc or '-'}`
🌐 **Mode :** `{st}`
💳 **Bayar :** `{S.dk_method_name()}`
⏰ **Notif Expired :** {nstat}
🎨 **Gambar /start :** `{'ada' if S.gambar_start() else 'belum diisi'}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("🔑 Setting Duitku", "sa-duitku")],
        [Button.inline("📦 Produk & Harga", "sa-produk"),
         Button.inline("💰 Harga Massal", "sa-harga")],
        [Button.inline("💳 Metode Bayar", "sa-metode"),
         Button.inline("⏰ Notifikasi Expired", "sa-notif")],
        [Button.inline("🎨 Gambar /start", "sa-gambar"),
         Button.inline("💾 Backup & Restore", "backer")],
        [Button.inline("📊 Statistik", "sa-stat"),
         Button.inline("🔄 Cek Deposit", "sa-cekd")],
        [Button.inline("‹ Main Menu ›", "menu")],
    ]
    await safe_send(event, teks, buttons=rows)


# ---------- HARGA MASSAL (semua tipe sekaligus) ----------
def _flat_preset():
    """Harga flat untuk 3/7/30 hari (bisa diubah admin)."""
    out = {}
    for h, d in ((3, 1000), (7, 2500), (30, 10000)):
        try:
            out[h] = int(S.get_setting("flat_%d" % h, str(d)) or d)
        except Exception:
            out[h] = d
    return out


def _teks_harga():
    teks = """
━━━━━━━━━━━━━━━━━━━━━━━
**💰 HARGA MASSAL (SEMUA TIPE)**
━━━━━━━━━━━━━━━━━━━━━━━
Harga sekarang 👇
"""
    for r in S.ringkas_harga():
        h, a, b, n = int(r["hari"]), int(r["a"]), int(r["b"]), int(r["n"])
        if a == b:
            hrg = S.rupiah(a)
        else:
            hrg = "%s - %s (beda)" % (S.rupiah(a), S.rupiah(b))
        teks += "  %2d hari : %s  (%d paket)\n" % (h, hrg, n)
    p = _flat_preset()
    teks += """
━━━━━━━━━━━━━━━━━━━━━━━
**Ubah semua tipe sekaligus** (harga flat), atau
ubah **per tipe** kalau mau diskon salah satu saja
(mis. cuma VMess) lewat menu 📦 Produk & Harga.

Preset flat sekarang: `%s / %s / %s`
""" % (S.rupiah(p[3]), S.rupiah(p[7]), S.rupiah(p[30]))
    teks += "━━━━━━━━━━━━━━━━━━━━━━━"
    return teks


@bot.on(events.CallbackQuery(data=b'sa-harga'))
async def sa_harga(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    p = _flat_preset()
    rows = [
        [Button.inline("⚡ Terapkan Flat: %s / %s / %s" % (
            S.rupiah(p[3]), S.rupiah(p[7]), S.rupiah(p[30])), "sa-hflat")],
        [Button.inline("🗓️ Ubah Harga 3 Hari", "sa-hs-3"),
         Button.inline("🗓️ Ubah Harga 7 Hari", "sa-hs-7")],
        [Button.inline("🗓️ Ubah Harga 30 Hari", "sa-hs-30"),
         Button.inline("✏️ Ubah Preset", "sa-hpreset")],
        [Button.inline("🪙 Nominal Deposit", "sa-depo")],
        [Button.inline("📦 Produk & Harga (per tipe)", "sa-produk")],
        [Button.inline("‹ Store ›", "storeadmin")],
    ]
    await safe_send(event, _teks_harga(), buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-depo'))
async def sa_depo(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🪙 NOMINAL DEPOSIT**
━━━━━━━━━━━━━━━━━━━━━━━
Minimal deposit : `{S.rupiah(S.depo_min())}`
Tombol nominal  : `{', '.join(S.rupiah(x) for x in S.depo_nominal())}`

Kalau harga produk murah (mis. Rp 1.000), minimal deposit
sebaiknya ikut kecil biar pembeli tidak perlu deposit besar.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("💵 Ubah Minimal Deposit", "sa-depo-min")],
        [Button.inline("🔢 Ubah Tombol Nominal", "sa-depo-list")],
        [Button.inline("‹ Harga ›", "sa-harga")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-depo-min'))
async def sa_depo_min(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event, "💵 **Masukkan minimal deposit** (angka saja, "
                                    "contoh: `1000`)\nSekarang: `%s`"
                                    % S.rupiah(S.depo_min()))
    if val is None:
        return
    try:
        v = int((val or "").replace(".", "").replace(",", "").replace("Rp", "").strip())
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])
        return
    if v < 100:
        await event.reply("❌ Minimal Rp 100.", buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])
        return
    S.set_setting("depo_min", v)
    await event.reply("✅ Minimal deposit: `%s`" % S.rupiah(v),
                      buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])


@bot.on(events.CallbackQuery(data=b'sa-depo-list'))
async def sa_depo_list(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event,
                             "🔢 **Masukkan tombol nominal deposit** (pisahkan koma)\n"
                             "contoh: `1000,2500,5000,10000,25000`\n"
                             "Sekarang: `%s`" % ",".join(str(x) for x in S.depo_nominal()))
    if val is None:
        return
    bersih = [x.strip().replace(".", "") for x in (val or "").replace(" ", ",").split(",")]
    angka = [int(x) for x in bersih if x.isdigit() and int(x) > 0]
    if not angka:
        await event.reply("❌ Tidak ada angka valid.",
                          buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])
        return
    S.set_setting("depo_nominal", ",".join(str(x) for x in sorted(set(angka))))
    await event.reply("✅ Tombol nominal: `%s`"
                      % ", ".join(S.rupiah(x) for x in S.depo_nominal()),
                      buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-hs-\d+$'))
async def sa_harga_set(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    hari = int(event.data.decode().replace("sa-hs-", ""))
    val = await _minta_angka(event,
                             "💰 **Masukkan harga baru untuk SEMUA tipe (%d hari)**\n"
                             "angka saja, contoh: `1000`" % hari)
    if val is None:
        return
    try:
        harga = int((val or "").replace(".", "").replace(",", "").replace("Rp", "").strip())
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Harga ›", "sa-harga")]])
        return
    if harga < 0:
        await event.reply("❌ Harga tidak boleh minus.",
                          buttons=[[Button.inline("‹ Harga ›", "sa-harga")]])
        return
    jml = len(S.produk_by_hari(hari))
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**KONFIRMASI HARGA MASSAL**
━━━━━━━━━━━━━━━━━━━━━━━
🗓️ **Masa aktif :** `{hari} hari`
💵 **Harga baru :** `{S.rupiah(harga)}`
📦 **Berlaku untuk:** `{jml} paket` (semua tipe)

Harga sekarang akan DIGANTI untuk semua tipe
yang masa aktifnya {hari} hari.
━━━━━━━━━━━━━━━━━━━━━━━
Lanjutkan?
"""
    await safe_send(event, teks, buttons=[
        [Button.inline("✅ Terapkan ke %d paket" % jml, "sa-hsok-%d-%d" % (hari, harga))],
        [Button.inline("‹ Batal ›", "sa-harga")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-hsok-\d+-\d+$'))
async def sa_harga_setok(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    d = event.data.decode().replace("sa-hsok-", "")
    hari, _, harga = d.partition("-")
    n = S.set_harga_hari(int(hari), int(harga))
    await event.answer("Harga %d hari diubah (%d paket)." % (int(hari), n), alert=True)
    await sa_harga(event)


@bot.on(events.CallbackQuery(data=b'sa-hflat'))
async def sa_hflat(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    p = _flat_preset()
    rincian = "\n".join(
        "  %2d hari : %s  ->  %s" % (h, S.rupiah(x["a"]),
                                     S.rupiah(p[h]))
        for h in (3, 7, 30)
        for x in [next((y for y in S.ringkas_harga() if int(y["hari"]) == h),
                       {"a": 0})])
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**TERAPKAN HARGA FLAT**
━━━━━━━━━━━━━━━━━━━━━━━
Semua tipe akan memakai harga yang sama:

  3 hari  : {S.rupiah(p[3])}
  7 hari  : {S.rupiah(p[7])}
  30 hari : {S.rupiah(p[30])}

Perubahan:
{rincian}
━━━━━━━━━━━━━━━━━━━━━━━
Lanjutkan?
"""
    await safe_send(event, teks, buttons=[
        [Button.inline("✅ Terapkan ke semua", "sa-hflatok")],
        [Button.inline("✏️ Ubah Preset", "sa-hpreset")],
        [Button.inline("‹ Batal ›", "sa-harga")]])


@bot.on(events.CallbackQuery(data=b'sa-hflatok'))
async def sa_hflatok(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    p = _flat_preset()
    total = 0
    for h in (3, 7, 30):
        total += S.set_harga_hari(h, p[h])
    await event.answer("Harga flat diterapkan (%d paket)." % total, alert=True)
    await sa_harga(event)


@bot.on(events.CallbackQuery(data=b'sa-hpreset'))
async def sa_hpreset(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    p = _flat_preset()
    val = await _minta_angka(event,
                             "✏️ **Masukkan 3 harga flat** (untuk 3 / 7 / 30 hari)\n"
                             "pisahkan dengan spasi, contoh: `1000 2500 10000`\n"
                             "Preset sekarang: `%d %d %d`" % (p[3], p[7], p[30]))
    if val is None:
        return
    bagian = [x for x in (val or "").replace(",", " ").replace(".", " ").split() if x]
    angka = []
    for x in bagian:
        try:
            angka.append(int(x.replace("Rp", "")))
        except Exception:
            pass
    if len(angka) != 3:
        await event.reply("❌ Harus 3 angka. Contoh: `1000 2500 10000`",
                          buttons=[[Button.inline("‹ Harga ›", "sa-harga")]])
        return
    for h, v in zip((3, 7, 30), angka):
        S.set_setting("flat_%d" % h, v)
    await event.reply("✅ Preset disimpan: `%s / %s / %s`" % (
        S.rupiah(angka[0]), S.rupiah(angka[1]), S.rupiah(angka[2])),
        buttons=[[Button.inline("⚡ Terapkan Sekarang", "sa-hflat")],
                 [Button.inline("‹ Harga ›", "sa-harga")]])


# ---------- gambar /start ----------
def _path_gambar_lokal():
    folder = os.path.dirname(os.path.abspath(S.DB_PATH))
    return os.path.join(folder, "start.jpg")


@bot.on(events.CallbackQuery(data=b'sa-gambar'))
async def sa_gambar(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    url = S.get_setting("start_image", "")
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**GAMBAR /START**
━━━━━━━━━━━━━━━━━━━━━━━
Gambar ini muncul di pesan **/start** (admin & pelanggan)
supaya tampilan bot tidak polosan.

Setting sekarang : `{url or '(belum diisi)'}`

Cara isi:
1. Upload gambar ke **catbox.moe** / **qu.ax** / imgur
2. Copy **direct link** gambarnya (harus berakhiran .jpg/.png)
3. Tekan **Ganti URL** lalu kirim link-nya

Atau kirim langsung **foto** ke bot lewat tombol **Kirim Foto**.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("🔗 Ganti URL", "sa-gambar-url"),
         Button.inline("📷 Kirim Foto", "sa-gambar-foto")],
        [Button.inline("👁️ Tes Tampilkan", "sa-gambar-tes"),
         Button.inline("🗑️ Hapus", "sa-gambar-hapus")],
        [Button.inline("‹ Store ›", "storeadmin")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-gambar-url'))
async def sa_gambar_url(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event, "🔗 **Kirim direct link gambar** "
                                    "(contoh: `https://files.catbox.moe/xxxx.jpg`)\n"
                                    "Kirim `-` untuk batal.")
    if val is None:
        return
    val = (val or "").strip()
    if val == "-":
        await event.reply("Dibatalkan.", buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    if not (val.startswith("http://") or val.startswith("https://")):
        await event.reply("❌ Link harus diawali `http://` atau `https://`",
                          buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    await balas(event, "⏳ **Mengunduh & merapikan gambar...**")
    ok, pesan, _nilai = await asyncio.to_thread(S.simpan_gambar_start, val)
    if not ok:
        await balas(event, "❌ %s" % pesan,
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    await balas(event, "✅ %s\n\nCoba tekan **👁️ Tes Tampilkan**." % pesan,
                buttons=[[Button.inline("👁️ Tes Tampilkan", "sa-gambar-tes")],
                         [Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-foto'))
async def sa_gambar_foto(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return

    m = None
    try:
        # PENTING: pertanyaan harus dikirim DARI DALAM conversation.
        # Kalau dikirim di luar (safe_send), conv.get_response() error:
        # "No message was sent previously".
        async with bot.conversation(event.chat_id, exclusive=False,
                                    timeout=180) as conv:
            await conv.send_message(
                "📷 **Kirim fotonya sekarang** ke chat ini.\n"
                "(kirim `-` untuk batal)\n\n"
                "_Foto akan otomatis dirapikan ke 16:9 supaya pas di /start._")
            m = await conv.get_response(timeout=180)
    except asyncio.TimeoutError:
        await balas(event, "⏱️ Waktu habis. Silakan ulangi.",
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    except Exception as e:
        logging.error("sa_gambar_foto: %s", e)
        await balas(event, "❌ Gagal menerima foto: %s" % e,
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return

    if m is None:
        await balas(event, "❌ Tidak ada foto diterima.",
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    if (m.raw_text or "").strip() == "-":
        await balas(event, "Dibatalkan.",
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    if not getattr(m, "photo", None):
        await balas(event, "❌ Itu bukan **foto**. Kirim sebagai foto "
                           "(bukan file/dokumen).",
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return

    tmp = os.path.join("/tmp", "kyt-start-%s.jpg" % DT.datetime.now().strftime("%H%M%S"))
    try:
        await m.download_media(tmp)
    except Exception as e:
        await balas(event, "❌ Gagal mengunduh foto: %s" % e,
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return

    ok, pesan, nilai = await asyncio.to_thread(S.simpan_gambar_start, tmp)
    try:
        os.remove(tmp)
    except Exception:
        pass

    if not ok:
        await balas(event, "❌ %s" % pesan,
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    await balas(event, "✅ %s\n\nCoba tekan **👁️ Tes Tampilkan**." % pesan,
                buttons=[[Button.inline("👁️ Tes Tampilkan", "sa-gambar-tes")],
                         [Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-tes'))
async def sa_gambar_tes(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    g = S.gambar_start()
    if not g:
        await event.answer("Belum ada gambar.", alert=True)
        return
    await safe_send_photo(event, g, "✅ **Tes gambar /start** — kalau gambar ini muncul, "
                                    "berarti sudah benar.",
                          [[Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-hapus'))
async def sa_gambar_hapus(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    S.set_setting("start_image", "")
    try:
        os.remove(_path_gambar_lokal())
    except Exception:
        pass
    await event.answer("Gambar dihapus.", alert=True)
    await sa_gambar(event)


# ---------- notifikasi expired ----------
@bot.on(events.CallbackQuery(data=b'sa-notif'))
async def sa_notif(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    from kyt.modules.notif import notif_aktif, notif_hari
    on = notif_aktif()
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**⏰ NOTIFIKASI EXPIRED**
━━━━━━━━━━━━━━━━━━━━━━━
Bot otomatis mengirim pesan ke pelanggan kalau akunnya
mau habis, dan memberi tombol **🔄 Perpanjang**.

📣 **Status  :** `{'AKTIF' if on else 'MATI'}`
🗓️ **Ingatkan :** `{', '.join('H-'+str(x) for x in notif_hari())}`
━━━━━━━━━━━━━━━━━━━━━━━
Contoh: H-3 = 3 hari sebelum expired.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [[Button.inline("⛔ Matikan" if on else "✅ Aktifkan", "sa-notif-toggle")],
            [Button.inline("🗓️ Ubah Hari Ingat", "sa-notif-hari")],
            [Button.inline("📨 Tes Kirim Sekarang", "sa-notif-tes")],
            [Button.inline("‹ Store ›", "storeadmin")]]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-notif-toggle'))
async def sa_notif_toggle(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    from kyt.modules.notif import notif_aktif
    S.set_setting("notif_aktif", "0" if notif_aktif() else "1")
    await event.answer("Diubah.", alert=True)
    await sa_notif(event)


@bot.on(events.CallbackQuery(data=b'sa-notif-hari'))
async def sa_notif_hari(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event, "🗓️ **Masukkan hari pengingat** "
                                    "(pisahkan koma, contoh: `3,1`):")
    if val is None:
        return
    bersih = ",".join(x.strip() for x in val.replace(" ", ",").split(",")
                      if x.strip().isdigit())
    if not bersih:
        await event.reply("❌ Format salah. Contoh: `3,1`",
                          buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])
        return
    S.set_setting("notif_hari", bersih)
    await event.reply("✅ Tersimpan: `H-%s`" % ", H-".join(bersih.split(",")),
                      buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])


@bot.on(events.CallbackQuery(data=b'sa-notif-tes'))
async def sa_notif_tes(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Menjalankan pengecekan...")
    try:
        await __import__('kyt').modules.notif.cek_expired()
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])
        return
    await safe_send(event,
                    "✅ Selesai. Pengingat yang belum terkirim sudah dikirim.\n"
                    "_(akun yang sudah pernah diingatkan tidak dikirim ulang)_",
                    buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])


# ---------- Duitku ----------
@bot.on(events.CallbackQuery(data=b'sa-duitku'))
async def sa_duitku(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    mc = await tanya(event, "🔑 **Masukkan Merchant Code Duitku**\n"
                            "(contoh: `D1234` — kirim `-` untuk batal)")
    if not mc:
        return
    mc = mc.strip()
    ak = await tanya(event, "🔑 **Masukkan API Key Duitku:**")
    if not ak:
        return
    ak = ak.strip()
    S.set_setting("duitku_merchant", mc)
    S.set_setting("duitku_apikey", ak)
    await balas(event,
                "✅ **Tersimpan.**\n\nSekarang pilih mode:",
                buttons=[[Button.inline("🚀 PRODUCTION", "sa-mode-0"),
                          Button.inline("🧪 SANDBOX", "sa-mode-1")],
                         [Button.inline("‹ Store ›", "storeadmin")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-mode-'))
async def sa_mode(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    v = event.data.decode().replace("sa-mode-", "")
    S.set_setting("duitku_sandbox", v)
    await event.answer("Mode: %s" % ("SANDBOX" if v == "1" else "PRODUCTION"), alert=True)
    await sa_home(event)


# ---------- metode bayar (QRIS saja) ----------
@bot.on(events.CallbackQuery(data=b'sa-metode'))
async def sa_metode(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    aktif = S.dk_method()
    teks = ("━━━━━━━━━━━━━━━━━━━━━━━\n**💳 METODE BAYAR (QRIS)**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
            "Pelanggan membayar dengan **scan QR** — bisa dari aplikasi\n"
            "bank / e-wallet apa saja (GoPay, OVO, DANA, ShopeePay, m-banking).\n\n"
            "Pilih penyedia QRIS yang aktif di akun Duitku kamu 👇\n")
    rows = []
    for m in S.QRIS_OPTIONS:
        tanda = "✅" if m["code"] == aktif else "▫️"
        rows.append([Button.inline("%s %s" % (tanda, m["name"]),
                                   "sa-qris-%s" % m["code"])])
    rows.append([Button.inline("🔄 Cek QRIS Aktif di Duitku", "sa-metode-sync")])
    rows.append([Button.inline("‹ Store ›", "storeadmin")])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^sa-qris-'))
async def sa_qris(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    code = event.data.decode().replace("sa-qris-", "").upper()
    S.set_setting("duitku_method", code)
    await event.answer("Metode: %s" % S.dk_method_name(), alert=True)
    await sa_metode(event)


@bot.on(events.CallbackQuery(data=b'sa-metode-reset'))
async def sa_metode_reset(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    S.set_setting("duitku_method", "SP")
    await event.answer("Kembali ke QRIS ShopeePay.", alert=True)
    await sa_metode(event)


@bot.on(events.CallbackQuery(data=b'sa-metode-sync'))
async def sa_metode_sync(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    if not S.dk_ready():
        await event.answer("Isi Merchant Code & API Key dulu.", alert=True)
        return
    await safe_send(event, "⏳ **Mengambil daftar metode dari Duitku...**")
    try:
        res = await __import__('asyncio').to_thread(S.duitku_methods, 10000)
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    if str(res.get("responseCode", "")) != "00":
        await safe_send(event,
                         "❌ Duitku menolak. Cek Merchant Code / API Key / mode.\n\n`%s`"
                         % S._err(res),
                         buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    lst = res.get("paymentFee") or res.get("paymentMethod") or []
    qris = [x for x in lst if str(x.get("paymentMethod", "")).upper() in
            ("SP", "NQ", "SQ")]
    teks = "━━━━━━━━━━━━━━━━━━━━━━━\n**✅ QRIS AKTIF DI AKUN KAMU**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
    if qris:
        for x in qris:
            nm = x.get("paymentName", x.get("paymentMethod"))
            kd = str(x.get("paymentMethod", "")).upper()
            tanda = " (sedang dipakai)" if kd == S.dk_method() else ""
            teks += "• `%s` — %s%s\n" % (kd, nm, tanda)
        teks += "\nKalau yang aktif cuma 1, pilih itu di menu sebelumnya."
    else:
        teks += ("Tidak ada QRIS aktif.\n\nMinta aktivasi QRIS ke Duitku "
                 "(live chat dashboard), lalu cek lagi.\n")
        if lst:
            teks += "\nYang tersedia: `%s`\n" % ", ".join(
                str(x.get("paymentMethod")) for x in lst[:12])
    teks += "━━━━━━━━━━━━━━━━━━━━━━━"
    await safe_send(event, teks, buttons=[[Button.inline("💳 Pilih Metode", "sa-metode")],
                                          [Button.inline("‹ Store ›", "storeadmin")]])


# ---------- produk ----------
@bot.on(events.CallbackQuery(data=b'sa-produk'))
async def sa_produk(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    teks = """
━━━━━━━━━━━━━━━━━━━━━━━
**📦 PRODUK & HARGA**
━━━━━━━━━━━━━━━━━━━━━━━
Pilih jenis akun untuk ubah harga (3 / 7 / 30 hari
sekaligus), atau lihat semua paket.

Mau ubah SEMUA tipe jadi harga flat?
→ menu 💰 **Harga Massal**
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows, buf = [], []
    for t in S.produk_tipe_tersedia():
        buf.append(Button.inline(S.TIPE_LABEL.get(t, t).replace(" / ", "/"),
                                 "sa-tipe-%s" % t))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([Button.inline("📋 Semua Paket (%d)" % len(S.produk_semua()),
                               "sa-produk-all")])
    rows.append([Button.inline("💰 Harga Massal", "sa-harga")])
    rows.append([Button.inline("‹ Store ›", "storeadmin")])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^sa-tipe-[a-z]+$'))
async def sa_tipe(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    tipe = event.data.decode().replace("sa-tipe-", "")
    prods = S.produk_by_tipe(tipe, hanya_aktif=False)
    if not prods:
        await event.answer("Tidak ada paket.", alert=True)
        return
    teks = "━━━━━━━━━━━━━━━━━━━━━━━\n**📦 %s**\n━━━━━━━━━━━━━━━━━━━━━━━\n" % \
        S.TIPE_LABEL.get(tipe, tipe)
    rows = []
    for p in prods:
        tanda = "✅" if p["aktif"] else "⛔"
        teks += "%s **%d hari** : `%s`\n" % (tanda, p["hari"], S.rupiah(p["harga"]))
        rows.append([Button.inline("💵 %d Hari — %s" % (p["hari"], S.rupiah(p["harga"])),
                                   "sa-prod-%d" % p["id"])])
    teks += "━━━━━━━━━━━━━━━━━━━━━━━\nTekan paket untuk ubah harga / aktif."
    rows.append([Button.inline("‹ Produk ›", "sa-produk")])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-produk-all'))
async def sa_produk_all(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    rows = []
    for p in S.produk_semua():
        tanda = "✅" if p["aktif"] else "⛔"
        label = "%s %s %dh — %s" % (tanda,
                                    S.TIPE_LABEL.get(p["tipe"], p["tipe"]).replace(" / ", "/"),
                                    p["hari"], S.rupiah(p["harga"]))
        rows.append([Button.inline(label, "sa-prod-%d" % p["id"])])
    rows.append([Button.inline("‹ Produk ›", "sa-produk")])
    await safe_send(event, "━━━━━━━━━━━━━━━━━━━━━━━\n**📋 SEMUA PAKET**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
                     "Pilih paket untuk ubah 👇", buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^sa-prod-\d+$'))
async def sa_prod(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-prod-", ""))
    x = S.db()
    p = x.execute("SELECT * FROM produk WHERE id=?", (pid,)).fetchone()
    x.close()
    if not p:
        await event.answer("Tidak ada.", alert=True)
        return
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**📦 {p['nama']}**
━━━━━━━━━━━━━━━━━━━━━━━
🏷️ Kode   : `{p['kode']}`
🔖 Tipe   : `{p['tipe']}`
💵 Harga  : `{S.rupiah(p['harga'])}`
🗓️ Hari   : `{p['hari']}`
📊 Kuota  : `{p['quota']} GB`
🌐 LimitIP: `{p['iplimit']}`
✅ Aktif  : `{'YA' if p['aktif'] else 'TIDAK'}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[
        [Button.inline("💵 Ubah Harga", "sa-pe-harga-%d" % pid),
         Button.inline("🗓️ Ubah Hari", "sa-pe-hari-%d" % pid)],
        [Button.inline("📊 Kuota", "sa-pe-quota-%d" % pid),
         Button.inline("🌐 Limit IP", "sa-pe-ip-%d" % pid)],
        [Button.inline("✅/⛔ Aktif", "sa-pe-toggle-%d" % pid),
         Button.inline("🗑️ Hapus", "sa-pe-hapus-%d" % pid)],
        [Button.inline("‹ %s ›" % S.TIPE_LABEL.get(p["tipe"], p["tipe"]).replace(" / ", "/"),
                       "sa-tipe-%s" % p["tipe"]),
         Button.inline("‹ Produk ›", "sa-produk")]])


async def _minta_angka(event, judul):
	"""Tanya 1 nilai ke admin. Pakai helper tanya() supaya tidak stuck."""
	return await tanya(event, judul)


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-(harga|hari|quota|ip)-\d+$'))
async def sa_pe_field(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    d = event.data.decode()
    field = d.split("-")[2]
    pid = int(d.split("-")[3])
    label = {"harga": "harga (angka, rupiah)", "hari": "masa aktif (hari)",
             "quota": "kuota GB (0 = unlimited)", "ip": "limit IP (0 = unlimited)"}[field]
    val = await _minta_angka(event, "✏️ **Masukkan %s:**" % label)
    if val is None:
        return
    col = {"harga": "harga", "hari": "hari", "quota": "quota", "ip": "iplimit"}[field]
    try:
        iv = int(val)
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])
        return
    x = S.db()
    x.execute("UPDATE produk SET %s=? WHERE id=?" % col, (iv, pid))
    x.commit()
    x.close()
    if field == "harga":
        await event.reply("✅ Harga disimpan: `%s`\n\n_(kalau mau semua tipe sekaligus, "
                          "pakai menu 💰 Harga Massal)_" % S.rupiah(iv),
                          buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])
    else:
        await event.reply("✅ Tersimpan.", buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-toggle-\d+$'))
async def sa_pe_toggle(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-pe-toggle-", ""))
    x = S.db()
    x.execute("UPDATE produk SET aktif = 1 - aktif WHERE id=?", (pid,))
    x.commit()
    x.close()
    await event.answer("Diubah.", alert=True)
    await sa_tipe_balik(event, pid)


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-hapus-\d+$'))
async def sa_pe_hapus(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-pe-hapus-", ""))
    x = S.db()
    x.execute("DELETE FROM produk WHERE id=?", (pid,))
    x.commit()
    x.close()
    await event.answer("Produk dihapus.", alert=True)
    await sa_produk(event)


async def sa_tipe_balik(event, pid):
    """Kembali ke daftar paket per tipe (kalau produknya masih ada)."""
    try:
        x = S.db()
        p = x.execute("SELECT tipe FROM produk WHERE id=?", (pid,)).fetchone()
        x.close()
        if p:
            event.data = ("sa-tipe-%s" % p["tipe"]).encode()
    except Exception:
        pass
    await sa_tipe(event)


# ---------- statistik ----------
@bot.on(events.CallbackQuery(data=b'sa-stat'))
async def sa_stat(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    x = S.db()
    tot_order = x.execute("SELECT COUNT(*) c FROM pesanan").fetchone()["c"]
    tot_omset = x.execute("SELECT COALESCE(SUM(harga),0) s FROM pesanan").fetchone()["s"]
    tot_user = x.execute("SELECT COUNT(*) c FROM store_user").fetchone()["c"]
    tot_saldo = x.execute("SELECT COALESCE(SUM(saldo),0) s FROM store_user").fetchone()["s"]
    dep_paid = x.execute("SELECT COALESCE(SUM(amount),0) s FROM deposit WHERE status='PAID'").fetchone()["s"]
    dep_pend = x.execute("SELECT COUNT(*) c FROM deposit WHERE status='PENDING'").fetchone()["c"]
    x.close()

    rinci = S.rincian_akun()
    tot_vps = sum(v for _t, _n, v, _b in rinci)
    tot_bot = sum(b for _t, _n, _v, b in rinci)
    beda = [(n, v, b) for _t, n, v, b in rinci if v != b]

    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**📊 STATISTIK STORE**
━━━━━━━━━━━━━━━━━━━━━━━
👥 **User terdaftar :** `{tot_user}`
📦 **Pesanan di bot :** `{tot_order}`
💵 **Total penjualan:** `{S.rupiah(tot_omset)}`
💰 **Saldo user     :** `{S.rupiah(tot_saldo)}`
🧾 **Deposit masuk  :** `{S.rupiah(dep_paid)}`
⏳ **Deposit pending:** `{dep_pend}`
━━━━━━━━━━━━━━━━━━━━━━━
**AKUN DI VPS : `{tot_vps}`**   (catatan bot: `{tot_bot}`)
"""
    for _t, nama, v, b in rinci:
        tanda = "" if v == b else "  ⚠️"
        teks += "%-12s : `%d`%s\n" % (nama, v, tanda)
    teks += "━━━━━━━━━━━━━━━━━━━━━━━\n"

    if beda:
        teks += "**⚠️ Ada selisih:**\n"
        for nama, v, b in beda:
            teks += "• %s — VPS `%d`, bot `%d`\n" % (nama, v, b)
        teks += ("\n_Selisih biasanya karena akun dihapus manual di panel "
                 "(bukan lewat bot). Angka di menu utama memakai data VPS._\n")
        teks += "━━━━━━━━━━━━━━━━━━━━━━━\n"
    else:
        teks += "✅ **Angka VPS & bot SINKRON**\n━━━━━━━━━━━━━━━━━━━━━━━\n"

    await safe_send(event, teks, buttons=[
        [Button.inline("🔄 Hitung Ulang", "sa-stat"),
         Button.inline("‹ Store ›", "storeadmin")]])


@bot.on(events.CallbackQuery(data=b'sa-cekd'))
async def sa_cekd(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Mengecek deposit pending...")
    await __import__('kyt').modules.deposit.cek_semua_pending()
    await event.answer("Selesai dicek.", alert=True)
    await sa_stat(event)


@bot.on(events.NewMessage(pattern=r"^/(cekd|ceksaldo)$"))
async def cmd_cekd(event):
    if not _adm_ok(event):
        return
    await __import__('kyt').modules.deposit.cek_semua_pending()
    await event.reply("✅ Deposit pending sudah dicek ulang.")


# ---------- kelola saldo user ----------
@bot.on(events.CallbackQuery(data=b'sa-kelola'))
async def sa_kelola(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    chat = event.chat_id
    uid = await tanya(event, "👤 **Masukkan ID Telegram user:**")
    if not uid:
        return
    uid = uid.strip()
    u = S.get_user(uid)
    if not u:
        await balas(event, "❌ User tidak ada.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    t = await tanya(event, "👤 `%s`\n💰 Saldo: `%s`\n\nMasukkan nominal "
                           "(+ tambah / - kurang):" % (uid, S.rupiah(u["saldo"])))
    if t is None:
        return
    try:
        n = int(t.strip().replace(".", "").replace(",", ""))
    except Exception:
        await balas(event, "❌ Harus angka.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    if n >= 0:
        S.saldo_tambah(uid, n)
    else:
        S.saldo_kurang(uid, -n)
    u2 = S.get_user(uid)
    await balas(event, "✅ Saldo `%s` sekarang: `%s`" % (uid, S.rupiah(u2["saldo"])),
                buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
