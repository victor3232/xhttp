# -*- coding: utf-8 -*-
# ============================================================
#  modules/storeadmin.py - pengaturan STORE untuk ADMIN
# ============================================================
from kyt import *
from kyt import store_lib as S


def _adm_ok(event):
    return valid(str(event.sender_id)) == "true"


@bot.on(events.CallbackQuery(data=b'storeadmin'))
async def sa_home(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    qr_stat = "✅ siap" if S.dk_ready() else "❌ belum diisi"
    try:
        from kyt.modules.notif import notif_aktif, notif_hari
        nstat = "✅ H-%s" % ", H-".join(str(x) for x in notif_hari()) if notif_aktif() else "⛔ mati"
    except Exception:
        nstat = "-"
    try:
        from kyt.modules.conn_notif import conn_notif_aktif
        cstat = "✅ aktif" if conn_notif_aktif() else "⛔ mati"
    except Exception:
        cstat = "-"
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🏪 PENGATURAN STORE**
━━━━━━━━━━━━━━━━━━━━━━━
💳 **GoPay Merchant :** {qr_stat}
📱 **Bayar via :** `QRIS GoPay`
🪙 **Min Deposit :** `{S.rupiah(S.depo_min())}`
🔢 **Nominal Depo :** `{', '.join(S.rupiah(x) for x in S.depo_nominal())}`
⏰ **Notif Expired :** {nstat}
🔔 **Notif Koneksi :** {cstat}
🎨 **Gambar /start :** `{'ada' if S.gambar_start() else 'belum diisi'}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("💳 Setting GoPay Merchant", "sa-gopay"),
         Button.inline("🪙 Setting Deposit", "sa-depo")],
        [Button.inline("📦 Produk & Harga", "sa-produk"),
         Button.inline("💰 Harga Massal", "sa-harga")],
        [Button.inline("⏰ Notifikasi Expired", "sa-notif"),
         Button.inline("🔔 Notif Koneksi", "sa-connnotif")],
        [Button.inline("🎨 Gambar /start", "sa-gambar")],
        [Button.inline("💾 Backup & Restore", "backer"),
         Button.inline("📊 Statistik", "sa-stat")],
        [Button.inline("🔄 Cek Deposit", "sa-cekd")],
        [Button.inline("‹ Main Menu ›", "menu")],
    ]
    await safe_send(event, teks, buttons=rows)


# ---------- HARGA MASSAL (semua tipe sekaligus) ----------
def _flat_preset():
    """Harga flat untuk 3/7/30 hari (bisa diubah admin)."""
    out = {}
    for h, d in ((3, 1000), (7, 2500), (30, 10000)):
        try:
            out[h] = int(S.get_setting("flat_%d" % h, str(d)) or d)
        except Exception:
            out[h] = d
    return out


def _teks_harga():
    teks = """
━━━━━━━━━━━━━━━━━━━━━━━
**💰 HARGA MASSAL (SEMUA TIPE)**
━━━━━━━━━━━━━━━━━━━━━━━
Harga sekarang 👇
"""
    for r in S.ringkas_harga():
        h, a, b, n = int(r["hari"]), int(r["a"]), int(r["b"]), int(r["n"])
        if a == b:
            hrg = S.rupiah(a)
        else:
            hrg = "%s - %s (beda)" % (S.rupiah(a), S.rupiah(b))
        teks += "  %2d hari : %s  (%d paket)\n" % (h, hrg, n)
    p = _flat_preset()
    teks += """
━━━━━━━━━━━━━━━━━━━━━━━
**Ubah semua tipe sekaligus** (harga flat), atau
ubah **per tipe** kalau mau diskon salah satu saja
(mis. cuma VMess) lewat menu 📦 Produk & Harga.

Preset flat sekarang: `%s / %s / %s`
""" % (S.rupiah(p[3]), S.rupiah(p[7]), S.rupiah(p[30]))
    teks += "━━━━━━━━━━━━━━━━━━━━━━━"
    return teks


@bot.on(events.CallbackQuery(data=b'sa-harga'))
async def sa_harga(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    p = _flat_preset()
    rows = [
        [Button.inline("⚡ Terapkan Flat: %s / %s / %s" % (
            S.rupiah(p[3]), S.rupiah(p[7]), S.rupiah(p[30])), "sa-hflat")],
        [Button.inline("🗓️ Ubah Harga 3 Hari", "sa-hs-3"),
         Button.inline("🗓️ Ubah Harga 7 Hari", "sa-hs-7")],
        [Button.inline("🗓️ Ubah Harga 30 Hari", "sa-hs-30"),
         Button.inline("✏️ Ubah Preset", "sa-hpreset")],
        [Button.inline("🪙 Nominal Deposit", "sa-depo")],
        [Button.inline("📦 Produk & Harga (per tipe)", "sa-produk")],
        [Button.inline("‹ Store ›", "storeadmin")],
    ]
    await safe_send(event, _teks_harga(), buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-depo'))
async def sa_depo(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🪙 NOMINAL DEPOSIT**
━━━━━━━━━━━━━━━━━━━━━━━
Minimal deposit : `{S.rupiah(S.depo_min())}`
Tombol nominal  : `{', '.join(S.rupiah(x) for x in S.depo_nominal())}`

Kalau harga produk murah (mis. Rp 1.000), minimal deposit
sebaiknya ikut kecil biar pembeli tidak perlu deposit besar.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("💵 Ubah Minimal Deposit", "sa-depo-min")],
        [Button.inline("🔢 Ubah Tombol Nominal", "sa-depo-list")],
        [Button.inline("‹ Harga ›", "sa-harga")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-depo-min'))
async def sa_depo_min(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event, "💵 **Masukkan minimal deposit** (angka saja, "
                                    "contoh: `1000`)\nSekarang: `%s`"
                                    % S.rupiah(S.depo_min()))
    if val is None:
        return
    try:
        v = int((val or "").replace(".", "").replace(",", "").replace("Rp", "").strip())
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])
        return
    if v < 100:
        await event.reply("❌ Minimal Rp 100.", buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])
        return
    S.set_setting("depo_min", v)
    await event.reply("✅ Minimal deposit: `%s`" % S.rupiah(v),
                      buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])


@bot.on(events.CallbackQuery(data=b'sa-depo-list'))
async def sa_depo_list(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event,
                             "🔢 **Masukkan tombol nominal deposit** (pisahkan koma)\n"
                             "contoh: `1000,2500,5000,10000,25000`\n"
                             "Sekarang: `%s`" % ",".join(str(x) for x in S.depo_nominal()))
    if val is None:
        return
    bersih = [x.strip().replace(".", "") for x in (val or "").replace(" ", ",").split(",")]
    angka = [int(x) for x in bersih if x.isdigit() and int(x) > 0]
    if not angka:
        await event.reply("❌ Tidak ada angka valid.",
                          buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])
        return
    S.set_setting("depo_nominal", ",".join(str(x) for x in sorted(set(angka))))
    await event.reply("✅ Tombol nominal: `%s`"
                      % ", ".join(S.rupiah(x) for x in S.depo_nominal()),
                      buttons=[[Button.inline("‹ Deposit ›", "sa-depo")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-hs-\d+$'))
async def sa_harga_set(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    hari = int(event.data.decode().replace("sa-hs-", ""))
    val = await _minta_angka(event,
                             "💰 **Masukkan harga baru untuk SEMUA tipe (%d hari)**\n"
                             "angka saja, contoh: `1000`" % hari)
    if val is None:
        return
    try:
        harga = int((val or "").replace(".", "").replace(",", "").replace("Rp", "").strip())
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Harga ›", "sa-harga")]])
        return
    if harga < 0:
        await event.reply("❌ Harga tidak boleh minus.",
                          buttons=[[Button.inline("‹ Harga ›", "sa-harga")]])
        return
    jml = len(S.produk_by_hari(hari))
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**KONFIRMASI HARGA MASSAL**
━━━━━━━━━━━━━━━━━━━━━━━
🗓️ **Masa aktif :** `{hari} hari`
💵 **Harga baru :** `{S.rupiah(harga)}`
📦 **Berlaku untuk:** `{jml} paket` (semua tipe)

Harga sekarang akan DIGANTI untuk semua tipe
yang masa aktifnya {hari} hari.
━━━━━━━━━━━━━━━━━━━━━━━
Lanjutkan?
"""
    await safe_send(event, teks, buttons=[
        [Button.inline("✅ Terapkan ke %d paket" % jml, "sa-hsok-%d-%d" % (hari, harga))],
        [Button.inline("‹ Batal ›", "sa-harga")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-hsok-\d+-\d+$'))
async def sa_harga_setok(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    d = event.data.decode().replace("sa-hsok-", "")
    hari, _, harga = d.partition("-")
    n = S.set_harga_hari(int(hari), int(harga))
    await event.answer("Harga %d hari diubah (%d paket)." % (int(hari), n), alert=True)
    await sa_harga(event)


@bot.on(events.CallbackQuery(data=b'sa-hflat'))
async def sa_hflat(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    p = _flat_preset()
    rincian = "\n".join(
        "  %2d hari : %s  ->  %s" % (h, S.rupiah(x["a"]),
                                     S.rupiah(p[h]))
        for h in (3, 7, 30)
        for x in [next((y for y in S.ringkas_harga() if int(y["hari"]) == h),
                       {"a": 0})])
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**TERAPKAN HARGA FLAT**
━━━━━━━━━━━━━━━━━━━━━━━
Semua tipe akan memakai harga yang sama:

  3 hari  : {S.rupiah(p[3])}
  7 hari  : {S.rupiah(p[7])}
  30 hari : {S.rupiah(p[30])}

Perubahan:
{rincian}
━━━━━━━━━━━━━━━━━━━━━━━
Lanjutkan?
"""
    await safe_send(event, teks, buttons=[
        [Button.inline("✅ Terapkan ke semua", "sa-hflatok")],
        [Button.inline("✏️ Ubah Preset", "sa-hpreset")],
        [Button.inline("‹ Batal ›", "sa-harga")]])


@bot.on(events.CallbackQuery(data=b'sa-hflatok'))
async def sa_hflatok(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    p = _flat_preset()
    total = 0
    for h in (3, 7, 30):
        total += S.set_harga_hari(h, p[h])
    await event.answer("Harga flat diterapkan (%d paket)." % total, alert=True)
    await sa_harga(event)


@bot.on(events.CallbackQuery(data=b'sa-hpreset'))
async def sa_hpreset(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    p = _flat_preset()
    val = await _minta_angka(event,
                             "✏️ **Masukkan 3 harga flat** (untuk 3 / 7 / 30 hari)\n"
                             "pisahkan dengan spasi, contoh: `1000 2500 10000`\n"
                             "Preset sekarang: `%d %d %d`" % (p[3], p[7], p[30]))
    if val is None:
        return
    bagian = [x for x in (val or "").replace(",", " ").replace(".", " ").split() if x]
    angka = []
    for x in bagian:
        try:
            angka.append(int(x.replace("Rp", "")))
        except Exception:
            pass
    if len(angka) != 3:
        await event.reply("❌ Harus 3 angka. Contoh: `1000 2500 10000`",
                          buttons=[[Button.inline("‹ Harga ›", "sa-harga")]])
        return
    for h, v in zip((3, 7, 30), angka):
        S.set_setting("flat_%d" % h, v)
    await event.reply("✅ Preset disimpan: `%s / %s / %s`" % (
        S.rupiah(angka[0]), S.rupiah(angka[1]), S.rupiah(angka[2])),
        buttons=[[Button.inline("⚡ Terapkan Sekarang", "sa-hflat")],
                 [Button.inline("‹ Harga ›", "sa-harga")]])


# ---------- gambar /start ----------
def _path_gambar_lokal():
    folder = os.path.dirname(os.path.abspath(S.DB_PATH))
    return os.path.join(folder, "start.jpg")


@bot.on(events.CallbackQuery(data=b'sa-gambar'))
async def sa_gambar(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    url = S.get_setting("start_image", "")
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**GAMBAR /START**
━━━━━━━━━━━━━━━━━━━━━━━
Gambar ini muncul di pesan **/start** (admin & pelanggan)
supaya tampilan bot tidak polosan.

Setting sekarang : `{url or '(belum diisi)'}`

Cara isi:
1. Upload gambar ke **catbox.moe** / **qu.ax** / imgur
2. Copy **direct link** gambarnya (harus berakhiran .jpg/.png)
3. Tekan **Ganti URL** lalu kirim link-nya

Atau kirim langsung **foto** ke bot lewat tombol **Kirim Foto**.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("🔗 Ganti URL", "sa-gambar-url"),
         Button.inline("📷 Kirim Foto", "sa-gambar-foto")],
        [Button.inline("👁️ Tes Tampilkan", "sa-gambar-tes"),
         Button.inline("🗑️ Hapus", "sa-gambar-hapus")],
        [Button.inline("‹ Store ›", "storeadmin")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-gambar-url'))
async def sa_gambar_url(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event, "🔗 **Kirim direct link gambar** "
                                    "(contoh: `https://files.catbox.moe/xxxx.jpg`)\n"
                                    "Kirim `-` untuk batal.")
    if val is None:
        return
    val = (val or "").strip()
    if val == "-":
        await event.reply("Dibatalkan.", buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    if not (val.startswith("http://") or val.startswith("https://")):
        await event.reply("❌ Link harus diawali `http://` atau `https://`",
                          buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    await balas(event, "⏳ **Mengunduh & merapikan gambar...**")
    ok, pesan, _nilai = await asyncio.to_thread(S.simpan_gambar_start, val)
    if not ok:
        await balas(event, "❌ %s" % pesan,
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    await balas(event, "✅ %s\n\nCoba tekan **👁️ Tes Tampilkan**." % pesan,
                buttons=[[Button.inline("👁️ Tes Tampilkan", "sa-gambar-tes")],
                         [Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-foto'))
async def sa_gambar_foto(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return

    # pakai antrean tunggu yang sama dengan tanya() (tanpa conversation)
    try:
        m = await tunggu_pesan(
            event,
            "📷 **Kirim fotonya sekarang** ke chat ini.\n"
            "(kirim `-` untuk batal)\n\n"
            "Foto akan otomatis dirapikan ke 16:9 supaya pas di /start.",
            timeout=180)
    except Exception as e:
        logging.error("sa_gambar_foto: %s", repr(e))
        await balas(event, "❌ Gagal menerima foto: %s" % e,
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    if m is None:
        return

    if m is None:
        await balas(event, "❌ Tidak ada foto diterima.",
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    if (m.raw_text or "").strip() == "-":
        await balas(event, "Dibatalkan.",
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    if not getattr(m, "photo", None):
        await balas(event, "❌ Itu bukan **foto**. Kirim sebagai foto "
                           "(bukan file/dokumen).",
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return

    tmp = os.path.join("/tmp", "kyt-start-%s.jpg" % DT.datetime.now().strftime("%H%M%S"))
    try:
        await m.download_media(tmp)
    except Exception as e:
        await balas(event, "❌ Gagal mengunduh foto: %s" % e,
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return

    ok, pesan, nilai = await asyncio.to_thread(S.simpan_gambar_start, tmp)
    try:
        os.remove(tmp)
    except Exception:
        pass

    if not ok:
        await balas(event, "❌ %s" % pesan,
                    buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    await balas(event, "✅ %s\n\nCoba tekan **👁️ Tes Tampilkan**." % pesan,
                buttons=[[Button.inline("👁️ Tes Tampilkan", "sa-gambar-tes")],
                         [Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-tes'))
async def sa_gambar_tes(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    g = S.gambar_start()
    if not g:
        await event.answer("Belum ada gambar.", alert=True)
        return
    await safe_send_photo(event, g, "✅ **Tes gambar /start** — kalau gambar ini muncul, "
                                    "berarti sudah benar.",
                          [[Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-hapus'))
async def sa_gambar_hapus(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    S.set_setting("start_image", "")
    try:
        os.remove(_path_gambar_lokal())
    except Exception:
        pass
    await event.answer("Gambar dihapus.", alert=True)
    await sa_gambar(event)


# ---------- notifikasi expired ----------
@bot.on(events.CallbackQuery(data=b'sa-notif'))
async def sa_notif(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    from kyt.modules.notif import notif_aktif, notif_hari
    on = notif_aktif()
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**⏰ NOTIFIKASI EXPIRED**
━━━━━━━━━━━━━━━━━━━━━━━
Bot otomatis mengirim pesan ke pelanggan kalau akunnya
mau habis, dan memberi tombol **🔄 Perpanjang**.

📣 **Status  :** `{'AKTIF' if on else 'MATI'}`
🗓️ **Ingatkan :** `{', '.join('H-'+str(x) for x in notif_hari())}`
━━━━━━━━━━━━━━━━━━━━━━━
Contoh: H-3 = 3 hari sebelum expired.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [[Button.inline("⛔ Matikan" if on else "✅ Aktifkan", "sa-notif-toggle")],
            [Button.inline("🗓️ Ubah Hari Ingat", "sa-notif-hari")],
            [Button.inline("📨 Tes Kirim Sekarang", "sa-notif-tes")],
            [Button.inline("‹ Store ›", "storeadmin")]]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-notif-toggle'))
async def sa_notif_toggle(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    from kyt.modules.notif import notif_aktif
    S.set_setting("notif_aktif", "0" if notif_aktif() else "1")
    await event.answer("Diubah.", alert=True)
    await sa_notif(event)


@bot.on(events.CallbackQuery(data=b'sa-notif-hari'))
async def sa_notif_hari(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event, "🗓️ **Masukkan hari pengingat** "
                                    "(pisahkan koma, contoh: `3,1`):")
    if val is None:
        return
    bersih = ",".join(x.strip() for x in val.replace(" ", ",").split(",")
                      if x.strip().isdigit())
    if not bersih:
        await event.reply("❌ Format salah. Contoh: `3,1`",
                          buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])
        return
    S.set_setting("notif_hari", bersih)
    await event.reply("✅ Tersimpan: `H-%s`" % ", H-".join(bersih.split(",")),
                      buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])


@bot.on(events.CallbackQuery(data=b'sa-notif-tes'))
async def sa_notif_tes(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Menjalankan pengecekan...")
    try:
        await __import__('kyt').modules.notif.cek_expired()
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])
        return
    await safe_send(event,
                    "✅ Selesai. Pengingat yang belum terkirim sudah dikirim.\n"
                    "(akun yang sudah pernah diingatkan tidak dikirim ulang)",
                    buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])

# ---------- notifikasi koneksi (SSH / Xray) ----------
@bot.on(events.CallbackQuery(data=b'sa-connnotif'))
async def sa_connnotif(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    from kyt.modules.conn_notif import conn_notif_aktif
    on = conn_notif_aktif()
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🔔 NOTIFIKASI KONEKSI**
━━━━━━━━━━━━━━━━━━━━━━━
📣 **Status :** `{'AKTIF' if on else 'MATI'}`

Admin menerima notifikasi saat akun:
🟢 **Connect** / terhubung
🔴 **Disconnect** / terputus

✅ SSH/Dropbear: sesi aktif dicek real-time.
✅ Xray: status putus bila tidak ada trafik sekitar 30 detik.
⏱️ Monitor berjalan otomatis tiap 5 detik.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("⛔ Matikan" if on else "✅ Aktifkan", "sa-connnotif-toggle")],
        [Button.inline("🧪 Tes Notifikasi", "sa-connnotif-tes")],
        [Button.inline("‹ Store ›", "storeadmin")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-connnotif-toggle'))
async def sa_connnotif_toggle(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    from kyt.modules.conn_notif import conn_notif_aktif
    baru = "0" if conn_notif_aktif() else "1"
    S.set_setting("conn_notif_aktif", baru)
    await event.answer("Notifikasi koneksi %s." % ("diaktifkan" if baru == "1" else "dimatikan"))
    await sa_connnotif(event)


@bot.on(events.CallbackQuery(data=b'sa-connnotif-tes'))
async def sa_connnotif_tes(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Mengirim tes...")
    try:
        from kyt.modules.conn_notif import tes_notif_koneksi
        ok = await tes_notif_koneksi()
    except Exception as e:
        logging.error("tes notif koneksi: %s", e)
        ok = False
    await safe_send(event,
                    "✅ Tes dikirim ke seluruh admin." if ok else "❌ Tes gagal dikirim. Cek log bot.",
                    buttons=[[Button.inline("‹ Notif Koneksi ›", "sa-connnotif")]])


# ---------- GoPay Merchant (pengganti Duitku) ----------
@bot.on(events.CallbackQuery(data=b'sa-gopay'))
async def sa_gopay(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    qr = S.gm_static_qr()
    phone = S.gm_phone()
    base = S.gm_base()
    status = "✅ siap" if qr else "❌ belum diisi"
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**💳 SETTING GOPAY MERCHANT**
━━━━━━━━━━━━━━━━━━━━━━━
🟢 **Status     :** {status}
🌐 **Base URL   :** `{base}`
📱 **HP Merchant:** `{phone or '-'}`
📲 **QR Statis  :** `{'ada (%d karakter)' % len(qr) if qr else 'belum diisi'}`
━━━━━━━━━━━━━━━━━━━━━━━
Untuk menggunakan QRIS GoPay:
1. Simpan QR statis merchant (dari aplikasi GoBiz)
2. Login via OTP GoPay untuk cek pembayaran
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("📲 Isi QR Statis", "sa-gopay-qr")],
        [Button.inline("📱 Isi No HP Merchant", "sa-gopay-phone")],
        [Button.inline("🔑 Login OTP GoPay", "sa-gopay-otp")],
        [Button.inline("🧪 Test QRIS Rp 1.000", "sa-gopay-test")],
        [Button.inline("‹ Store ›", "storeadmin")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-gopay-qr'))
async def sa_gopay_qr(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await tanya(event,
                      "📲 **Masukkan QR Statis GoPay Merchant**\n"
                      "(string panjang dari aplikasi GoBiz / scan QR merchant)\n"
                      "Kirim `-` untuk batal.")
    if not val or val.strip() == "-":
        return
    val = val.strip()
    if not val.startswith("000201"):
        await balas(event, "❌ Format QR tidak valid (harus diawali `000201`).",
                    buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])
        return
    S.set_setting("gomerch_static_qr", val)
    # reset loaded flag
    import kyt.store_lib as _sl
    _sl._GM_TOKEN_LOADED = False
    _sl._GM_TOKEN_CACHE = {}
    await balas(event, "✅ QR Statis disimpan (%d karakter)." % len(val),
                buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])


@bot.on(events.CallbackQuery(data=b'sa-gopay-phone'))
async def sa_gopay_phone(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await tanya(event,
                      "📱 **Masukkan nomor HP merchant GoPay**\n"
                      "(format: 628xxx, tanpa +)\n"
                      "Kirim `-` untuk batal.")
    if not val or val.strip() == "-":
        return
    val = val.strip().replace("+", "").replace(" ", "")
    S.set_setting("gomerch_phone", val)
    await balas(event, "✅ Nomor HP disimpan: `%s`" % val,
                buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])


@bot.on(events.CallbackQuery(data=b'sa-gopay-otp'))
async def sa_gopay_otp(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    phone = S.gm_phone()
    if not phone:
        await event.answer("Isi No HP Merchant dulu!", alert=True)
        return
    await safe_send(event, "⏳ **Mengirim OTP ke %s...**" % phone)
    try:
        import asyncio as _asyncio, requests as _req
        r = await _asyncio.to_thread(
            lambda: _req.get(S.gm_base() + "/auth/send-otp",
                             params={"phone": phone}, timeout=20))
        d = r.json()
    except Exception as e:
        await safe_send(event, "❌ Gagal kirim OTP: `%s`" % e,
                        buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])
        return
    if not d.get("success"):
        await safe_send(event,
                        "❌ GoPay menolak: `%s`" % (d.get("error", {}).get("message") or d),
                        buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])
        return
    otp_token = (d.get("data") or {}).get("otp_token") or (d.get("data") or {}).get("otpToken") or ""
    # simpan otp_token sementara agar verify bisa pakai
    S.set_setting("_gopay_otp_token_tmp", otp_token)
    val = await tanya(event,
                      "✅ **OTP dikirim ke HP merchant.**\n\n"
                      "Masukkan **kode OTP** yang diterima:\n"
                      "(atau kirim - untuk batal)")
    if not val or val.strip() == "-":
        return
    otp = val.strip()
    await safe_send(event, "⏳ **Verifikasi OTP...**")
    try:
        r2 = await _asyncio.to_thread(
            lambda: _req.get(S.gm_base() + "/auth/verify",
                             params={"otp": otp, "otp_token": otp_token},
                             timeout=20))
        d2 = r2.json()
    except Exception as e:
        await safe_send(event, "❌ Gagal verifikasi: `%s`" % e,
                        buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])
        return
    if not d2.get("success"):
        await safe_send(event,
                        "❌ OTP salah/kedaluwarsa: `%s`" % (d2.get("error", {}).get("message") or d2),
                        buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])
        return
    dd = d2.get("data") or {}
    new_token = dd.get("token") or dd.get("access_token") or dd.get("accessToken")
    new_rf = dd.get("refresh_token") or dd.get("refreshToken")
    if not new_token:
        await safe_send(event, "❌ Token tidak ditemukan di respons.",
                        buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])
        return
    S.gm_save_token = getattr(S, "_gm_save_token", None)
    import kyt.store_lib as _sl
    _sl._gm_save_token(new_token, new_rf)
    _sl.set_setting("gomerch_token", new_token)
    if new_rf:
        _sl.set_setting("gomerch_refresh_token", new_rf)
    await balas(event,
                "✅ **Login GoPay berhasil!**\nToken tersimpan. Cek pembayaran sudah aktif.",
                buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])


@bot.on(events.CallbackQuery(data=b'sa-gopay-test'))
async def sa_gopay_test(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    if not S.dk_ready():
        await event.answer("QR Statis belum diisi!", alert=True)
        return
    import asyncio as _asyncio
    await safe_send(event, "⏳ **Membuat QRIS test Rp 1.000...**")
    try:
        qr = await _asyncio.to_thread(S.gm_build_qris, 1000)
        png = await _asyncio.to_thread(S.qr_png, qr)
    except Exception as e:
        await safe_send(event, "❌ Gagal: `%s`" % e,
                        buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])
        return
    if png:
        path = "/tmp/qris_test.png"
        with open(path, "wb") as fh:
            fh.write(png)
        try:
            await bot.send_file(event.chat_id, path,
                                caption="✅ **QRIS Test Rp 1.000** — scan dan bayar Rp 1.000 untuk memastikan QRIS aktif.\n\n`%s`" % qr[:80] + "...",
                                buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])
        finally:
            try:
                import os as _os
                _os.remove(path)
            except Exception:
                pass
    else:
        await safe_send(event,
                        "✅ QR String dibuat:\n`%s`" % qr[:200],
                        buttons=[[Button.inline("‹ GoPay ›", "sa-gopay")]])


# ---------- produk ----------
@bot.on(events.CallbackQuery(data=b'sa-produk'))
async def sa_produk(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    teks = """
━━━━━━━━━━━━━━━━━━━━━━━
**📦 PRODUK & HARGA**
━━━━━━━━━━━━━━━━━━━━━━━
Pilih jenis akun untuk ubah harga (3 / 7 / 30 hari
sekaligus), atau lihat semua paket.

Mau ubah SEMUA tipe jadi harga flat?
→ menu 💰 **Harga Massal**
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows, buf = [], []
    for t in S.produk_tipe_tersedia():
        buf.append(Button.inline(S.TIPE_LABEL.get(t, t).replace(" / ", "/"),
                                 "sa-tipe-%s" % t))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)
    rows.append([Button.inline("📋 Semua Paket (%d)" % len(S.produk_semua()),
                               "sa-produk-all")])
    rows.append([Button.inline("💰 Harga Massal", "sa-harga")])
    rows.append([Button.inline("‹ Store ›", "storeadmin")])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^sa-tipe-[a-z]+$'))
async def sa_tipe(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    tipe = event.data.decode().replace("sa-tipe-", "")
    prods = S.produk_by_tipe(tipe, hanya_aktif=False)
    if not prods:
        await event.answer("Tidak ada paket.", alert=True)
        return
    teks = "━━━━━━━━━━━━━━━━━━━━━━━\n**📦 %s**\n━━━━━━━━━━━━━━━━━━━━━━━\n" % \
        S.TIPE_LABEL.get(tipe, tipe)
    rows = []
    for p in prods:
        tanda = "✅" if p["aktif"] else "⛔"
        teks += "%s **%d hari** : `%s`\n" % (tanda, p["hari"], S.rupiah(p["harga"]))
        rows.append([Button.inline("💵 %d Hari — %s" % (p["hari"], S.rupiah(p["harga"])),
                                   "sa-prod-%d" % p["id"])])
    teks += "━━━━━━━━━━━━━━━━━━━━━━━\nTekan paket untuk ubah harga / aktif."
    rows.append([Button.inline("‹ Produk ›", "sa-produk")])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-produk-all'))
async def sa_produk_all(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    rows = []
    for p in S.produk_semua():
        tanda = "✅" if p["aktif"] else "⛔"
        label = "%s %s %dh — %s" % (tanda,
                                    S.TIPE_LABEL.get(p["tipe"], p["tipe"]).replace(" / ", "/"),
                                    p["hari"], S.rupiah(p["harga"]))
        rows.append([Button.inline(label, "sa-prod-%d" % p["id"])])
    rows.append([Button.inline("‹ Produk ›", "sa-produk")])
    await safe_send(event, "━━━━━━━━━━━━━━━━━━━━━━━\n**📋 SEMUA PAKET**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
                     "Pilih paket untuk ubah 👇", buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^sa-prod-\d+$'))
async def sa_prod(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-prod-", ""))
    x = S.db()
    p = x.execute("SELECT * FROM produk WHERE id=?", (pid,)).fetchone()
    x.close()
    if not p:
        await event.answer("Tidak ada.", alert=True)
        return
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**📦 {p['nama']}**
━━━━━━━━━━━━━━━━━━━━━━━
🏷️ Kode   : `{p['kode']}`
🔖 Tipe   : `{p['tipe']}`
💵 Harga  : `{S.rupiah(p['harga'])}`
🗓️ Hari   : `{p['hari']}`
📊 Kuota  : `{p['quota']} GB`
🌐 LimitIP: `{p['iplimit']}`
✅ Aktif  : `{'YA' if p['aktif'] else 'TIDAK'}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[
        [Button.inline("💵 Ubah Harga", "sa-pe-harga-%d" % pid),
         Button.inline("🗓️ Ubah Hari", "sa-pe-hari-%d" % pid)],
        [Button.inline("📊 Kuota", "sa-pe-quota-%d" % pid),
         Button.inline("🌐 Limit IP", "sa-pe-ip-%d" % pid)],
        [Button.inline("✅/⛔ Aktif", "sa-pe-toggle-%d" % pid),
         Button.inline("🗑️ Hapus", "sa-pe-hapus-%d" % pid)],
        [Button.inline("‹ %s ›" % S.TIPE_LABEL.get(p["tipe"], p["tipe"]).replace(" / ", "/"),
                       "sa-tipe-%s" % p["tipe"]),
         Button.inline("‹ Produk ›", "sa-produk")]])


async def _minta_angka(event, judul):
	"""Tanya 1 nilai ke admin. Pakai helper tanya() supaya tidak stuck."""
	return await tanya(event, judul)


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-(harga|hari|quota|ip)-\d+$'))
async def sa_pe_field(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    d = event.data.decode()
    field = d.split("-")[2]
    pid = int(d.split("-")[3])
    label = {"harga": "harga (angka, rupiah)", "hari": "masa aktif (hari)",
             "quota": "kuota GB (0 = unlimited)", "ip": "limit IP (0 = unlimited)"}[field]
    val = await _minta_angka(event, "✏️ **Masukkan %s:**" % label)
    if val is None:
        return
    col = {"harga": "harga", "hari": "hari", "quota": "quota", "ip": "iplimit"}[field]
    try:
        iv = int(val)
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])
        return
    x = S.db()
    x.execute("UPDATE produk SET %s=? WHERE id=?" % col, (iv, pid))
    x.commit()
    x.close()
    if field == "harga":
        await event.reply("✅ Harga disimpan: `%s`\n\n_(kalau mau semua tipe sekaligus, "
                          "pakai menu 💰 Harga Massal)_" % S.rupiah(iv),
                          buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])
    else:
        await event.reply("✅ Tersimpan.", buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-toggle-\d+$'))
async def sa_pe_toggle(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-pe-toggle-", ""))
    x = S.db()
    x.execute("UPDATE produk SET aktif = 1 - aktif WHERE id=?", (pid,))
    x.commit()
    x.close()
    await event.answer("Diubah.", alert=True)
    await sa_tipe_balik(event, pid)


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-hapus-\d+$'))
async def sa_pe_hapus(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-pe-hapus-", ""))
    x = S.db()
    x.execute("DELETE FROM produk WHERE id=?", (pid,))
    x.commit()
    x.close()
    await event.answer("Produk dihapus.", alert=True)
    await sa_produk(event)


async def sa_tipe_balik(event, pid):
    """Kembali ke daftar paket per tipe (kalau produknya masih ada)."""
    try:
        x = S.db()
        p = x.execute("SELECT tipe FROM produk WHERE id=?", (pid,)).fetchone()
        x.close()
        if p:
            event.data = ("sa-tipe-%s" % p["tipe"]).encode()
    except Exception:
        pass
    await sa_tipe(event)


# ---------- statistik ----------
@bot.on(events.CallbackQuery(data=b'sa-stat'))
async def sa_stat(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    x = S.db()
    tot_order = x.execute("SELECT COUNT(*) c FROM pesanan").fetchone()["c"]
    tot_omset = x.execute("SELECT COALESCE(SUM(harga),0) s FROM pesanan").fetchone()["s"]
    tot_user = x.execute("SELECT COUNT(*) c FROM store_user").fetchone()["c"]
    tot_saldo = x.execute("SELECT COALESCE(SUM(saldo),0) s FROM store_user").fetchone()["s"]
    dep_paid = x.execute("SELECT COALESCE(SUM(amount),0) s FROM deposit WHERE status='PAID'").fetchone()["s"]
    dep_pend = x.execute("SELECT COUNT(*) c FROM deposit WHERE status='PENDING'").fetchone()["c"]
    x.close()

    rinci = S.rincian_akun()
    tot_vps = sum(v for _t, _n, v, _b in rinci)
    tot_bot = sum(b for _t, _n, _v, b in rinci)
    beda = [(n, v, b) for _t, n, v, b in rinci if v != b]

    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**📊 STATISTIK STORE**
━━━━━━━━━━━━━━━━━━━━━━━
👥 **User terdaftar :** `{tot_user}`
📦 **Pesanan di bot :** `{tot_order}`
💵 **Total penjualan:** `{S.rupiah(tot_omset)}`
💰 **Saldo user     :** `{S.rupiah(tot_saldo)}`
🧾 **Deposit masuk  :** `{S.rupiah(dep_paid)}`
⏳ **Deposit pending:** `{dep_pend}`
━━━━━━━━━━━━━━━━━━━━━━━
AKUN DI VPS : **%d**   (catatan bot: **%d**)
""" % (tot_vps, tot_bot)
    for _t, nama, v, b in rinci:
        tanda = "" if v == b else "  ⚠️"
        teks += "%-12s : `%d`%s\n" % (nama, v, tanda)
    teks += "━━━━━━━━━━━━━━━━━━━━━━━\n"

    if beda:
        teks += "**⚠️ Ada selisih:**\n"
        for nama, v, b in beda:
            teks += "• %s — VPS `%d`, bot `%d`\n" % (nama, v, b)
        teks += ("\nCatatan: selisih biasanya karena akun dihapus manual "
                 "di panel (bukan lewat bot). Angka di menu utama "
                 "memakai data VPS.\n")
        teks += "━━━━━━━━━━━━━━━━━━━━━━━\n"
    else:
        teks += "✅ **Angka VPS & bot SINKRON**\n━━━━━━━━━━━━━━━━━━━━━━━\n"

    await safe_send(event, teks, buttons=[
        [Button.inline("🔄 Hitung Ulang", "sa-stat"),
         Button.inline("‹ Store ›", "storeadmin")]])


@bot.on(events.CallbackQuery(data=b'sa-cekd'))
async def sa_cekd(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Mengecek deposit pending...")
    await __import__('kyt').modules.deposit.cek_semua_pending()
    await event.answer("Selesai dicek.", alert=True)
    await sa_stat(event)


@bot.on(events.NewMessage(pattern=r"^/(cekd|ceksaldo)$"))
async def cmd_cekd(event):
    if not _adm_ok(event):
        return
    await __import__('kyt').modules.deposit.cek_semua_pending()
    await event.reply("✅ Deposit pending sudah dicek ulang.")


# ---------- kelola saldo user ----------
@bot.on(events.CallbackQuery(data=b'sa-kelola'))
async def sa_kelola(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    chat = event.chat_id
    uid = await tanya(event, "👤 **Masukkan ID Telegram user:**")
    if not uid:
        return
    uid = uid.strip()
    u = S.get_user(uid)
    if not u:
        await balas(event, "❌ User tidak ada.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    t = await tanya(event, "👤 `%s`\n💰 Saldo: `%s`\n\nMasukkan nominal "
                           "(+ tambah / - kurang):" % (uid, S.rupiah(u["saldo"])))
    if t is None:
        return
    try:
        n = int(t.strip().replace(".", "").replace(",", ""))
    except Exception:
        await balas(event, "❌ Harus angka.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    if n >= 0:
        S.saldo_tambah(uid, n)
    else:
        S.saldo_kurang(uid, -n)
    u2 = S.get_user(uid)
    await balas(event, "✅ Saldo `%s` sekarang: `%s`" % (uid, S.rupiah(u2["saldo"])),
                buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
