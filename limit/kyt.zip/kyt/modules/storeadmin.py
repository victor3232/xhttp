# -*- coding: utf-8 -*-
# ============================================================
#  modules/storeadmin.py - pengaturan STORE untuk ADMIN
# ============================================================
from kyt import *
from kyt import store_lib as S


def _adm_ok(event):
    return valid(str(event.sender_id)) == "true"


@bot.on(events.CallbackQuery(data=b'storeadmin'))
async def sa_home(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    mc = S.dk_merchant()
    st = "PRODUCTION" if not S.dk_dev() else "SANDBOX"
    stat = "✅ siap" if S.dk_ready() else "❌ belum diisi"
    try:
        from kyt.modules.notif import notif_aktif, notif_hari
        nstat = "✅ H-%s" % ", H-".join(str(x) for x in notif_hari()) if notif_aktif() else "⛔ mati"
    except Exception:
        nstat = "-"
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**🏪 PENGATURAN STORE**
━━━━━━━━━━━━━━━━━━━━━━━
🔑 **Duitku :** {stat}
🏷️ **Merchant :** `{mc or '-'}`
🌐 **Mode :** `{st}`
💳 **Bayar :** `{S.dk_method_name()}`
⏰ **Notif Expired :** {nstat}
🎨 **Gambar /start :** `{'ada' if S.gambar_start() else 'belum diisi'}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("🔑 Setting Duitku", "sa-duitku")],
        [Button.inline("📦 Produk & Harga", "sa-produk"),
         Button.inline("💳 Metode Bayar", "sa-metode")],
        [Button.inline("⏰ Notifikasi Expired", "sa-notif")],
        [Button.inline("🎨 Gambar /start", "sa-gambar"),
         Button.inline("💾 Backup & Restore", "backer")],
        [Button.inline("📊 Statistik", "sa-stat"),
         Button.inline("🔄 Cek Deposit", "sa-cekd")],
        [Button.inline("‹ Main Menu ›", "menu")],
    ]
    await safe_send(event, teks, buttons=rows)


# ---------- gambar /start ----------
def _path_gambar_lokal():
    folder = os.path.dirname(os.path.abspath(S.DB_PATH))
    return os.path.join(folder, "start.jpg")


@bot.on(events.CallbackQuery(data=b'sa-gambar'))
async def sa_gambar(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    url = S.get_setting("start_image", "")
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**GAMBAR /START**
━━━━━━━━━━━━━━━━━━━━━━━
Gambar ini muncul di pesan **/start** (admin & pelanggan)
supaya tampilan bot tidak polosan.

Setting sekarang : `{url or '(belum diisi)'}`

Cara isi:
1. Upload gambar ke **catbox.moe** / **qu.ax** / imgur
2. Copy **direct link** gambarnya (harus berakhiran .jpg/.png)
3. Tekan **Ganti URL** lalu kirim link-nya

Atau kirim langsung **foto** ke bot lewat tombol **Kirim Foto**.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [
        [Button.inline("🔗 Ganti URL", "sa-gambar-url"),
         Button.inline("📷 Kirim Foto", "sa-gambar-foto")],
        [Button.inline("👁️ Tes Tampilkan", "sa-gambar-tes"),
         Button.inline("🗑️ Hapus", "sa-gambar-hapus")],
        [Button.inline("‹ Store ›", "storeadmin")],
    ]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-gambar-url'))
async def sa_gambar_url(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event, "🔗 **Kirim direct link gambar** "
                                    "(contoh: `https://files.catbox.moe/xxxx.jpg`)\n"
                                    "Kirim `-` untuk batal.")
    if val is None:
        return
    val = (val or "").strip()
    if val == "-":
        await event.reply("Dibatalkan.", buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    if not (val.startswith("http://") or val.startswith("https://")):
        await event.reply("❌ Link harus diawali `http://` atau `https://`",
                          buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    S.set_setting("start_image", val)
    await event.reply("✅ Link gambar disimpan.", buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-foto'))
async def sa_gambar_foto(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await safe_send(event, "📷 **Kirim fotonya sekarang** ke chat ini.")
    try:
        async with bot.conversation(event.chat_id) as conv:
            fut = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m = await fut
    except Exception:
        return
    if not getattr(m, "photo", None):
        await event.reply("❌ Itu bukan foto.", buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    path = _path_gambar_lokal()
    try:
        await m.download_media(path)
    except Exception as e:
        await event.reply("❌ Gagal menyimpan foto: %s" % e,
                          buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])
        return
    S.set_setting("start_image", path)
    await event.reply("✅ Foto disimpan & dipakai untuk /start.",
                      buttons=[[Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-tes'))
async def sa_gambar_tes(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    g = S.gambar_start()
    if not g:
        await event.answer("Belum ada gambar.", alert=True)
        return
    await safe_send_photo(event, g, "✅ **Tes gambar /start** — kalau gambar ini muncul, "
                                    "berarti sudah benar.",
                          [[Button.inline("‹ Gambar ›", "sa-gambar")]])


@bot.on(events.CallbackQuery(data=b'sa-gambar-hapus'))
async def sa_gambar_hapus(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    S.set_setting("start_image", "")
    try:
        os.remove(_path_gambar_lokal())
    except Exception:
        pass
    await event.answer("Gambar dihapus.", alert=True)
    await sa_gambar(event)


# ---------- notifikasi expired ----------
@bot.on(events.CallbackQuery(data=b'sa-notif'))
async def sa_notif(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    from kyt.modules.notif import notif_aktif, notif_hari
    on = notif_aktif()
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**⏰ NOTIFIKASI EXPIRED**
━━━━━━━━━━━━━━━━━━━━━━━
Bot otomatis mengirim pesan ke pelanggan kalau akunnya
mau habis, dan memberi tombol **🔄 Perpanjang**.

📣 **Status  :** `{'AKTIF' if on else 'MATI'}`
🗓️ **Ingatkan :** `{', '.join('H-'+str(x) for x in notif_hari())}`
━━━━━━━━━━━━━━━━━━━━━━━
Contoh: H-3 = 3 hari sebelum expired.
━━━━━━━━━━━━━━━━━━━━━━━
"""
    rows = [[Button.inline("⛔ Matikan" if on else "✅ Aktifkan", "sa-notif-toggle")],
            [Button.inline("🗓️ Ubah Hari Ingat", "sa-notif-hari")],
            [Button.inline("📨 Tes Kirim Sekarang", "sa-notif-tes")],
            [Button.inline("‹ Store ›", "storeadmin")]]
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(data=b'sa-notif-toggle'))
async def sa_notif_toggle(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    from kyt.modules.notif import notif_aktif
    S.set_setting("notif_aktif", "0" if notif_aktif() else "1")
    await event.answer("Diubah.", alert=True)
    await sa_notif(event)


@bot.on(events.CallbackQuery(data=b'sa-notif-hari'))
async def sa_notif_hari(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    val = await _minta_angka(event, "🗓️ **Masukkan hari pengingat** "
                                    "(pisahkan koma, contoh: `3,1`):")
    if val is None:
        return
    bersih = ",".join(x.strip() for x in val.replace(" ", ",").split(",")
                      if x.strip().isdigit())
    if not bersih:
        await event.reply("❌ Format salah. Contoh: `3,1`",
                          buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])
        return
    S.set_setting("notif_hari", bersih)
    await event.reply("✅ Tersimpan: `H-%s`" % ", H-".join(bersih.split(",")),
                      buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])


@bot.on(events.CallbackQuery(data=b'sa-notif-tes'))
async def sa_notif_tes(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Menjalankan pengecekan...")
    try:
        await __import__('kyt').modules.notif.cek_expired()
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])
        return
    await safe_send(event,
                    "✅ Selesai. Pengingat yang belum terkirim sudah dikirim.\n"
                    "_(akun yang sudah pernah diingatkan tidak dikirim ulang)_",
                    buttons=[[Button.inline("‹ Notif ›", "sa-notif")]])


# ---------- Duitku ----------
@bot.on(events.CallbackQuery(data=b'sa-duitku'))
async def sa_duitku(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    chat = event.chat_id
    await safe_send(event, "🔑 **Masukkan Merchant Code Duitku** (atau kirim `-` untuk batal):")
    try:
        async with bot.conversation(chat) as conv:
            f1 = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m1 = await f1
    except Exception:
        return
    mc = (m1.raw_text or "").strip()
    if mc == "-":
        await event.reply("Dibatalkan.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    await event.reply("🔑 **Masukkan API Key Duitku:**")
    try:
        async with bot.conversation(chat) as conv:
            f2 = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m2 = await f2
    except Exception:
        return
    ak = (m2.raw_text or "").strip()
    S.set_setting("duitku_merchant", mc)
    S.set_setting("duitku_apikey", ak)
    await event.reply(
        "✅ Tersimpan.\n\nSekarang pilih mode:",
        buttons=[[Button.inline("🚀 PRODUCTION", "sa-mode-0"),
                  Button.inline("🧪 SANDBOX", "sa-mode-1")],
                 [Button.inline("‹ Store ›", "storeadmin")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-mode-'))
async def sa_mode(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    v = event.data.decode().replace("sa-mode-", "")
    S.set_setting("duitku_sandbox", v)
    await event.answer("Mode: %s" % ("SANDBOX" if v == "1" else "PRODUCTION"), alert=True)
    await sa_home(event)


# ---------- metode bayar (QRIS saja) ----------
@bot.on(events.CallbackQuery(data=b'sa-metode'))
async def sa_metode(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    aktif = S.dk_method()
    teks = ("━━━━━━━━━━━━━━━━━━━━━━━\n**💳 METODE BAYAR (QRIS)**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
            "Pelanggan membayar dengan **scan QR** — bisa dari aplikasi\n"
            "bank / e-wallet apa saja (GoPay, OVO, DANA, ShopeePay, m-banking).\n\n"
            "Pilih penyedia QRIS yang aktif di akun Duitku kamu 👇\n")
    rows = []
    for m in S.QRIS_OPTIONS:
        tanda = "✅" if m["code"] == aktif else "▫️"
        rows.append([Button.inline("%s %s" % (tanda, m["name"]),
                                   "sa-qris-%s" % m["code"])])
    rows.append([Button.inline("🔄 Cek QRIS Aktif di Duitku", "sa-metode-sync")])
    rows.append([Button.inline("‹ Store ›", "storeadmin")])
    await safe_send(event, teks, buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^sa-qris-'))
async def sa_qris(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    code = event.data.decode().replace("sa-qris-", "").upper()
    S.set_setting("duitku_method", code)
    await event.answer("Metode: %s" % S.dk_method_name(), alert=True)
    await sa_metode(event)


@bot.on(events.CallbackQuery(data=b'sa-metode-reset'))
async def sa_metode_reset(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    S.set_setting("duitku_method", "SP")
    await event.answer("Kembali ke QRIS ShopeePay.", alert=True)
    await sa_metode(event)


@bot.on(events.CallbackQuery(data=b'sa-metode-sync'))
async def sa_metode_sync(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    if not S.dk_ready():
        await event.answer("Isi Merchant Code & API Key dulu.", alert=True)
        return
    await safe_send(event, "⏳ **Mengambil daftar metode dari Duitku...**")
    try:
        res = await __import__('asyncio').to_thread(S.duitku_methods, 10000)
    except Exception as e:
        await safe_send(event, "❌ Gagal: %s" % e,
                        buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    if str(res.get("responseCode", "")) != "00":
        await safe_send(event,
                         "❌ Duitku menolak. Cek Merchant Code / API Key / mode.\n\n`%s`"
                         % S._err(res),
                         buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    lst = res.get("paymentFee") or res.get("paymentMethod") or []
    qris = [x for x in lst if str(x.get("paymentMethod", "")).upper() in
            ("SP", "NQ", "SQ")]
    teks = "━━━━━━━━━━━━━━━━━━━━━━━\n**✅ QRIS AKTIF DI AKUN KAMU**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
    if qris:
        for x in qris:
            nm = x.get("paymentName", x.get("paymentMethod"))
            kd = str(x.get("paymentMethod", "")).upper()
            tanda = " (sedang dipakai)" if kd == S.dk_method() else ""
            teks += "• `%s` — %s%s\n" % (kd, nm, tanda)
        teks += "\nKalau yang aktif cuma 1, pilih itu di menu sebelumnya."
    else:
        teks += ("Tidak ada QRIS aktif.\n\nMinta aktivasi QRIS ke Duitku "
                 "(live chat dashboard), lalu cek lagi.\n")
        if lst:
            teks += "\nYang tersedia: `%s`\n" % ", ".join(
                str(x.get("paymentMethod")) for x in lst[:12])
    teks += "━━━━━━━━━━━━━━━━━━━━━━━"
    await safe_send(event, teks, buttons=[[Button.inline("💳 Pilih Metode", "sa-metode")],
                                          [Button.inline("‹ Store ›", "storeadmin")]])


# ---------- produk ----------
@bot.on(events.CallbackQuery(data=b'sa-produk'))
async def sa_produk(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    rows = []
    tipe_terakhir = None
    for p in S.produk_semua():
        tanda = "✅" if p["aktif"] else "⛔"
        label = "%s %s %dh — %s" % (tanda,
                                    S.TIPE_LABEL.get(p["tipe"], p["tipe"]).replace(" / ", "/"),
                                    p["hari"], S.rupiah(p["harga"]))
        rows.append([Button.inline(label, "sa-prod-%d" % p["id"])])
    rows.append([Button.inline("‹ Store ›", "storeadmin")])
    await safe_send(event, "━━━━━━━━━━━━━━━━━━━━━━━\n**📦 PRODUK & HARGA**\n━━━━━━━━━━━━━━━━━━━━━━━\n"
                     "Semua tipe tersedia **3 / 7 / 30 hari**.\n"
                     "Pilih produk untuk ubah harga/masa aktif 👇",
                     buttons=rows)


@bot.on(events.CallbackQuery(pattern=r'^sa-prod-\d+$'))
async def sa_prod(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-prod-", ""))
    x = S.db()
    p = x.execute("SELECT * FROM produk WHERE id=?", (pid,)).fetchone()
    x.close()
    if not p:
        await event.answer("Tidak ada.", alert=True)
        return
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**📦 {p['nama']}**
━━━━━━━━━━━━━━━━━━━━━━━
🏷️ Kode   : `{p['kode']}`
🔖 Tipe   : `{p['tipe']}`
💵 Harga  : `{S.rupiah(p['harga'])}`
🗓️ Hari   : `{p['hari']}`
📊 Kuota  : `{p['quota']} GB`
🌐 LimitIP: `{p['iplimit']}`
✅ Aktif  : `{'YA' if p['aktif'] else 'TIDAK'}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[
        [Button.inline("💵 Ubah Harga", "sa-pe-harga-%d" % pid),
         Button.inline("🗓️ Ubah Hari", "sa-pe-hari-%d" % pid)],
        [Button.inline("📊 Kuota", "sa-pe-quota-%d" % pid),
         Button.inline("🌐 Limit IP", "sa-pe-ip-%d" % pid)],
        [Button.inline("✅/⛔ Aktif", "sa-pe-toggle-%d" % pid),
         Button.inline("🗑️ Hapus", "sa-pe-hapus-%d" % pid)],
        [Button.inline("‹ Produk ›", "sa-produk")]])


async def _minta_angka(event, judul):
    chat = event.chat_id
    await safe_send(event, judul)
    try:
        async with bot.conversation(chat) as conv:
            fut = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m = await fut
    except Exception:
        return None
    t = (m.raw_text or "").strip()
    return t


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-(harga|hari|quota|ip)-\d+$'))
async def sa_pe_field(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    d = event.data.decode()
    field = d.split("-")[2]
    pid = int(d.split("-")[3])
    label = {"harga": "harga (angka, rupiah)", "hari": "masa aktif (hari)",
             "quota": "kuota GB (0 = unlimited)", "ip": "limit IP (0 = unlimited)"}[field]
    val = await _minta_angka(event, "✏️ **Masukkan %s:**" % label)
    if val is None:
        return
    col = {"harga": "harga", "hari": "hari", "quota": "quota", "ip": "iplimit"}[field]
    try:
        iv = int(val)
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])
        return
    x = S.db()
    x.execute("UPDATE produk SET %s=? WHERE id=?" % col, (iv, pid))
    x.commit()
    x.close()
    await event.reply("✅ Tersimpan.", buttons=[[Button.inline("‹ Produk ›", "sa-produk")]])


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-toggle-\d+$'))
async def sa_pe_toggle(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-pe-toggle-", ""))
    x = S.db()
    x.execute("UPDATE produk SET aktif = 1 - aktif WHERE id=?", (pid,))
    x.commit()
    x.close()
    await event.answer("Diubah.", alert=True)
    await sa_produk(event)


@bot.on(events.CallbackQuery(pattern=r'^sa-pe-hapus-\d+$'))
async def sa_pe_hapus(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    pid = int(event.data.decode().replace("sa-pe-hapus-", ""))
    x = S.db()
    x.execute("DELETE FROM produk WHERE id=?", (pid,))
    x.commit()
    x.close()
    await event.answer("Produk dihapus.", alert=True)
    await sa_produk(event)


# ---------- statistik ----------
@bot.on(events.CallbackQuery(data=b'sa-stat'))
async def sa_stat(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    x = S.db()
    tot_order = x.execute("SELECT COUNT(*) c FROM pesanan").fetchone()["c"]
    tot_omset = x.execute("SELECT COALESCE(SUM(harga),0) s FROM pesanan").fetchone()["s"]
    tot_user = x.execute("SELECT COUNT(*) c FROM store_user").fetchone()["c"]
    tot_saldo = x.execute("SELECT COALESCE(SUM(saldo),0) s FROM store_user").fetchone()["s"]
    dep_paid = x.execute("SELECT COALESCE(SUM(amount),0) s FROM deposit WHERE status='PAID'").fetchone()["s"]
    dep_pend = x.execute("SELECT COUNT(*) c FROM deposit WHERE status='PENDING'").fetchone()["c"]
    x.close()
    teks = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**📊 STATISTIK STORE**
━━━━━━━━━━━━━━━━━━━━━━━
👥 **User terdaftar :** `{tot_user}`
📦 **Akun terjual   :** `{tot_order}`
💵 **Total penjualan:** `{S.rupiah(tot_omset)}`
💰 **Saldo user     :** `{S.rupiah(tot_saldo)}`
🧾 **Deposit masuk  :** `{S.rupiah(dep_paid)}`
⏳ **Deposit pending:** `{dep_pend}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
    await safe_send(event, teks, buttons=[[Button.inline("‹ Store ›", "storeadmin")]])


@bot.on(events.CallbackQuery(data=b'sa-cekd'))
async def sa_cekd(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    await event.answer("Mengecek deposit pending...")
    await __import__('kyt').modules.deposit.cek_semua_pending()
    await event.answer("Selesai dicek.", alert=True)
    await sa_stat(event)


@bot.on(events.NewMessage(pattern=r"^/(cekd|ceksaldo)$"))
async def cmd_cekd(event):
    if not _adm_ok(event):
        return
    await __import__('kyt').modules.deposit.cek_semua_pending()
    await event.reply("✅ Deposit pending sudah dicek ulang.")


# ---------- kelola saldo user ----------
@bot.on(events.CallbackQuery(data=b'sa-kelola'))
async def sa_kelola(event):
    if not _adm_ok(event):
        await event.answer("Akses Ditolak", alert=True)
        return
    chat = event.chat_id
    await safe_send(event, "👤 **Masukkan ID Telegram user:**")
    try:
        async with bot.conversation(chat) as conv:
            f1 = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m1 = await f1
    except Exception:
        return
    uid = (m1.raw_text or "").strip()
    u = S.get_user(uid)
    if not u:
        await event.reply("❌ User tidak ada.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    await event.reply("👤 `%s`\n💰 Saldo: `%s`\n\nMasukkan nominal (+ tambah / - kurang):"
                      % (uid, S.rupiah(u["saldo"])),
                      buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
    try:
        async with bot.conversation(chat) as conv:
            f2 = conv.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            m2 = await f2
    except Exception:
        return
    t = (m2.raw_text or "").strip()
    try:
        n = int(t)
    except Exception:
        await event.reply("❌ Harus angka.", buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
        return
    if n >= 0:
        S.saldo_tambah(uid, n)
    else:
        S.saldo_kurang(uid, -n)
    u2 = S.get_user(uid)
    await event.reply("✅ Saldo `%s` sekarang: `%s`" % (uid, S.rupiah(u2["saldo"])),
                      buttons=[[Button.inline("‹ Store ›", "storeadmin")]])
