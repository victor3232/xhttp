from kyt import *
from kyt import store_lib as S


def _trial_text():
	c = S.trial_conf()
	def q(v):
		return "Unlimited" if str(v) in ("0", "", "None") else ("%s GB" % v)
	def ip(v):
		return "Unlimited" if str(v) in ("0", "", "None") else ("%s IP" % v)
	return f"""
━━━━━━━━━━━━━━━━━━━━━━━
**TRIAL SETTINGS**
━━━━━━━━━━━━━━━━━━━━━━━
Status       : **{'ON' if c.get('ENABLED') == '1' else 'OFF'}**
Notifikasi   : **{'ON' if c.get('NOTIFY') == '1' else 'OFF'}**
━━━━━━━━━━━━━━━━━━━━━━━
**TRIAL SSH**
Menit        : `{c.get('SSH_MINUTES')}`
Quota        : `{q(c.get('SSH_QUOTA_GB'))}`
Limit IP     : `{ip(c.get('SSH_IP_LIMIT'))}`
━━━━━━━━━━━━━━━━━━━━━━━
**TRIAL ALL XRAY**
Menit        : `{c.get('XRAY_MINUTES')}`
Quota        : `{q(c.get('XRAY_QUOTA_GB'))}`
Limit IP     : `{ip(c.get('XRAY_IP_LIMIT'))}`
━━━━━━━━━━━━━━━━━━━━━━━
VMess / VLESS / Trojan / Shadowsocks
memakai setting XRAY yang sama.
━━━━━━━━━━━━━━━━━━━━━━━
"""


def _trial_buttons():
	return [
		[Button.inline(" SSH MENIT ", "trial-set:SSH_MINUTES"),
		 Button.inline(" SSH QUOTA ", "trial-set:SSH_QUOTA_GB")],
		[Button.inline(" SSH IP ", "trial-set:SSH_IP_LIMIT"),
		 Button.inline(" XRAY MENIT ", "trial-set:XRAY_MINUTES")],
		[Button.inline(" XRAY QUOTA ", "trial-set:XRAY_QUOTA_GB"),
		 Button.inline(" XRAY IP ", "trial-set:XRAY_IP_LIMIT")],
		[Button.inline(" NOTIF ON/OFF ", "trial-set:NOTIFY"),
		 Button.inline(" TRIAL AKTIF ", "trial-active")],
		[Button.inline(" TRIAL ON/OFF ", "trial-set:ENABLED")],
		[Button.inline("‹ Main Menu ›", "menu")],
	]


@bot.on(events.CallbackQuery(data=b'trial-settings'))
async def trial_settings(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	await safe_send(event, _trial_text(), _trial_buttons())


@bot.on(events.CallbackQuery(pattern=b'trial-set:(.*)'))
async def trial_set_value(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	key = event.data.decode("ascii", "ignore").split(":", 1)[1]
	c = S.trial_conf()
	if key == "NOTIFY":
		value = "0" if c.get("NOTIFY") == "1" else "1"
	elif key == "ENABLED":
		value = "0" if c.get("ENABLED") == "1" else "1"
	else:
		labels = {
			"SSH_MINUTES": "SSH menit (1-1440)",
			"SSH_QUOTA_GB": "SSH quota GB (0=unlimited)",
			"SSH_IP_LIMIT": "SSH limit IP (0=unlimited)",
			"XRAY_MINUTES": "XRAY menit (1-1440)",
			"XRAY_QUOTA_GB": "XRAY quota GB (0=unlimited)",
			"XRAY_IP_LIMIT": "XRAY limit IP (0=unlimited)",
		}
		label = labels.get(key)
		if not label:
			await event.answer("Setting tidak dikenal", alert=True)
			return
		chat = event.chat_id
		uid = event.sender_id
		value = await tanya_admin(event, "**%s**\nKetik angka, atau `-` untuk batal:" % label, chat, uid)
		if value is None or value == "-":
			return
	ok, msg = await asyncio.to_thread(S.trial_set, key, value)
	if not ok:
		await balas(event, "❌ Gagal menyimpan setting.\n```\n%s\n```" % (msg or "")[-400:],
		            buttons=[[Button.inline("‹ Trial Settings ›", "trial-settings")]])
		return
	await safe_send(event, _trial_text(), _trial_buttons())


@bot.on(events.CallbackQuery(data=b'trial-active'))
async def trial_active(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	items = await asyncio.to_thread(S.trial_list)
	if not items:
		await safe_send(event, "Tidak ada trial aktif.",
		                [[Button.inline("‹ Trial Settings ›", "trial-settings")]])
		return
	lines = ["━━━━━━━━━━━━━━━━━━━━━━━", "**TRIAL AKTIF**", "━━━━━━━━━━━━━━━━━━━━━━━"]
	buttons = []
	for idx, item in enumerate(items[:12], 1):
		rem = max(0, int(item.get("remaining_seconds", 0) or 0))
		mins = rem // 60
		lines.append("%d. `%s` %s | %dm | %s GB | %s IP" % (
			idx, item.get("username", "-"), item.get("label", ""), mins,
			item.get("quota_gb", 0), item.get("ip_limit", 0)))
		buttons.append([Button.inline(
			"Hapus %s" % item.get("username", "-"),
			"trial-del:%s:%s" % (item.get("protocol", ""), item.get("username", "")))])
	lines.append("━━━━━━━━━━━━━━━━━━━━━━━")
	buttons.append([Button.inline("‹ Trial Settings ›", "trial-settings")])
	await safe_send(event, "\n".join(lines), buttons)


@bot.on(events.CallbackQuery(pattern=b'trial-del:(.*)'))
async def trial_delete(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	raw = event.data.decode("ascii", "ignore")
	parts = raw.split(":", 2)
	if len(parts) != 3:
		await event.answer("Data tidak valid", alert=True)
		return
	_, proto, user = parts
	ok, msg = await asyncio.to_thread(S.trial_delete, proto, user)
	try:
		await event.answer("Trial dihapus" if ok else "Gagal menghapus", alert=not ok)
	except Exception:
		pass
	await trial_active(event)
