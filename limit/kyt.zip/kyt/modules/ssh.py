from kyt import *
from kyt import store_lib as S


# ============================================================
#  CREATE SSH / OVPN
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return

	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	ok_u, msg_u = cek_username(user)
	if not ok_u:
		await event.respond("❌ %s" % msg_u)
		return

	pw = await tanya_admin(event, "**Password** — isi `-` untuk dibuatkan otomatis:", chat, uid)
	if pw is None:
		return
	pw = pw.strip()
	if pw in ("", "-", "auto"):
		pw = S._rand(8)

	exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
	if not exp:
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "addssh",
	                                  [user, pw, "0", "0", exp],
	                                  45, lambda: S._akun_ada("ssh", user))
	if not ok or not S._akun_ada("ssh", user):
		await balas(event, "❌ **Gagal membuat akun SSH.**\n\n```\n%s\n```"
		            % (out or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	later = DT.date.today() + DT.timedelta(days=int(exp))
	msg = "**SSH / OVPN ACCOUNT**\n```\n" + S.detail_ssh(user, pw) + \
	      "\nExpired       : %s\n```" % later.strftime("%d %b %Y")
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  TRIAL SSH
# ============================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	menit = await tombol_admin(event, "**Pilih Masa Trial**", [
		[Button.inline("10 Menit", "10"), Button.inline("15 Menit", "15")],
		[Button.inline("30 Menit", "30"), Button.inline("60 Menit", "60")]],
		chat)
	if menit not in ("10", "15", "30", "60"):
		return

	user = "trial" + S._rand(5)
	pw = S._rand(6)
	await event.respond("`Memproses... mohon tunggu`")
	cmd = ('useradd -e `date -d "%s days" +%%Y-%%m-%%d` -s /bin/false -M %s '
	       '&& echo "%s\\n%s" | passwd %s' % (menit, user, pw, pw, user))
	try:
		subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT,
		                        timeout=30)
	except Exception as e:
		await balas(event, "❌ **Gagal membuat trial.**\n```\n%s\n```" % e,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	msg = "**SSH TRIAL**\n```\n" + S.detail_ssh(user, pw) + \
	      "\nExpired       : %s Menit\n```" % menit
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  CEK / SHOW USER SSH
# ============================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-member-ssh", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-cek-login-ssh", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  HAPUS SSH
# ============================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	user = await tanya_admin(event, "**Username yang mau dihapus:**", chat, sender.id)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("ssh", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	S._hapus_akun("ssh", user)
	await balas(event, "✅ Akun SSH `%s` sudah dihapus." % user,
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  MENU SSH
# ============================================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	inline = [
		[Button.inline(" TRIAL SSH ", "trial-ssh"),
		 Button.inline(" CREATE SSH ", "create-ssh")],
		[Button.inline(" DELETE SSH ", "delete-ssh"),
		 Button.inline(" CHECK LOGIN SSH ", "login-ssh")],
		[Button.inline(" SHOW ALL USER SSH ", "show-ssh")],
		[Button.inline("‹ Main Menu ›", "menu")]]
	try:
		z = requests.get("http://ip-api.com/json/?fields=country,isp",
		                 timeout=10).json()
	except Exception:
		z = {"isp": "-", "country": "-"}
	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**SSH OVPN MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `SSH OVPN`
Hostname/IP : `{DOMAIN}`
ISP         : `{z.get("isp", "-")}`
Country     : `{z.get("country", "-")}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send(event, msg, inline)
