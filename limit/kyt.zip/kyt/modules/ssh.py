from kyt import *
from kyt import store_lib as S


# ============================================================
#  CREATE SSH / OVPN
# ============================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return

	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	ok_u, msg_u = cek_username(user)
	if not ok_u:
		await event.respond("❌ %s" % msg_u)
		return

	pw = await tanya_admin(event, "**Password** — isi `-` untuk dibuatkan otomatis:", chat, uid)
	if pw is None:
		return
	pw = pw.strip()
	if pw in ("", "-", "auto"):
		pw = S._rand(8)

	iplimit = await tanya_admin(event, "**Limit IP** — isi `0` untuk unlimited:", chat, uid)
	if iplimit is None:
		return
	iplimit = iplimit.strip().replace(".", "").replace(",", "")
	if not iplimit.isdigit():
		await event.respond("❌ Harus angka.")
		return

	quota_ssh = await tanya_admin(event, "**Quota (GB)** — isi `0` untuk unlimited:", chat, uid)
	if quota_ssh is None:
		return
	quota_ssh = quota_ssh.strip().replace(".", "").replace(",", "")
	if not quota_ssh.isdigit():
		await event.respond("❌ Harus angka.")
		return

	exp = await hari_admin(event, chat, "**Pilih Masa Aktif**")
	if not exp:
		return

	await event.respond("`Memproses... mohon tunggu`")
	ok, out = await asyncio.to_thread(S._jalan_script, "addssh",
	                                  [user, pw, iplimit, quota_ssh, exp],
	                                  45, lambda: S._akun_ada("ssh", user))
	if not ok or not S._akun_ada("ssh", user):
		await balas(event, "❌ **Gagal membuat akun SSH.**\n\n```\n%s\n```"
		            % (out or "")[-500:],
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	later = DT.date.today() + DT.timedelta(days=int(exp))
	# UI SERAGAM (standar VMess) — detail_ssh sudah include expired/quota/iplimit
	detail = S.detail_ssh(user, pw, expired=later.strftime("%d %b %Y"),
	                      quota=quota_ssh, iplimit=iplimit)
	msg = "**SSH / OVPN ACCOUNT**\n```\n" + detail + "\n```"
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  TRIAL SSH
# ============================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	menit = await tombol_admin(event, "**Pilih Masa Trial**", [
		[Button.inline("10 Menit", "10"), Button.inline("15 Menit", "15")],
		[Button.inline("30 Menit", "30"), Button.inline("60 Menit", "60")]],
		chat)
	if menit not in ("10", "15", "30", "60"):
		return

	user = "Trial-" + S._rand(4)
	pw = "1"
	await event.respond("`Memproses... mohon tunggu`")
	# useradd: account expires besok (besaran minimum chage = hari),
	# penghapusan otomatis dilakukan background thread sesuai menit yang dipilih
	cmd = ('useradd -e `date -d "1 days" +%%Y-%%m-%%d` -s /bin/false -M %s '
	       '&& echo "%s\\n%s" | passwd %s' % (user, pw, pw, user))
	try:
		subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT,
		                        timeout=30)
	except Exception as e:
		await balas(event, "❌ **Gagal membuat trial.**\n```\n%s\n```" % e,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	# Jadwalkan penghapusan otomatis setelah `menit` menit (seperti script trial panel)
	import threading as _th
	def _hapus_trial(u=user):
		try:
			subprocess.run("userdel -f '%s'" % u, shell=True,
			               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
			               timeout=20)
			subprocess.run(
				"rm -f /etc/ssh/%s /etc/limit/ssh/%s /etc/limit/ssh/%s.lock "
				"/etc/kyt/limit/ssh/ip/%s /var/www/html/ssh-%s.txt"
				% (u, u, u, u, u), shell=True,
				stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
			subprocess.run("sed -i '/\\b%s\\b/d' /etc/ssh/.ssh.db" % u,
			               shell=True, stdout=subprocess.DEVNULL,
			               stderr=subprocess.DEVNULL, timeout=20)
		except Exception:
			pass
	_th.Timer(int(menit) * 60, _hapus_trial).start()

	# UI sama dgn akun reguler (seragam), hanya expired yg beda
	detail = S.detail_ssh(user, pw, expired="%s Menit" % menit,
	                      quota="0", iplimit="0")
	msg = "**SSH TRIAL**\n```\n" + detail + "\n```"
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  CEK / SHOW USER SSH
# ============================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-member-ssh", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	try:
		z = subprocess.check_output("bot-cek-login-ssh", shell=True,
		                            stderr=subprocess.STDOUT).decode("utf-8", "ignore")
	except Exception as e:
		z = "Gagal: %s" % e
	await balas(event, "```\n%s\n```" % (z or "-"),
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  HAPUS SSH
# ============================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	user = await tanya_admin(event, "**Username yang mau dihapus:**", chat, sender.id)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("ssh", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return
	S._hapus_akun("ssh", user)
	await balas(event, "✅ Akun SSH `%s` sudah dihapus." % user,
	            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  RENEW SSH (selaras renewssh panel: hari + reset kuota + ubah limit)
# ============================================================
@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Akses Ditolak", alert=True)
		return
	chat = event.chat_id
	sender = await event.get_sender()
	uid = sender.id

	user = await tanya_admin(event, "**Username yang mau direnew:**", chat, uid)
	if not user:
		return
	user = user.strip().lower()
	if not S._akun_ada("ssh", user):
		await balas(event, "❌ User `%s` tidak ditemukan." % user,
		            buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
		return

	hari = await tanya_admin(event, "**Tambah Masa Aktif (hari):**", chat, uid)
	if not hari:
		return
	hari = hari.strip().replace(".", "").replace(",", "")
	if not hari.isdigit() or int(hari) < 1:
		await event.respond("❌ Harus angka minimal 1.")
		return

	reset_q = await tombol_admin(event, "**Reset Kuota Pemakaian (usage) ke 0?**", [
		[Button.inline("✅ Ya, reset kuota", "y"),
		 Button.inline("❌ Tidak", "n")]], chat)
	if reset_q not in ("y", "n"):
		return

	new_q = await tanya_admin(
		event, "**Ubah Limit Quota (GB)** — isi `0` jika tidak diubah:", chat, uid)
	if new_q is None:
		return
	new_q = new_q.strip().replace(".", "").replace(",", "")
	if not new_q.isdigit():
		await event.respond("❌ Harus angka.")
		return

	await event.respond("`Memproses... mohon tunggu`")

	# --- jalankan renew sesuai renewssh panel ---
	def _do_renew():
		import subprocess as sp
		today = int(sp.check_output("date +%s", shell=True).decode().strip())
		exp_on = today + int(hari) * 86400
		exp_iso = sp.check_output(
			"date -u --date='1970-01-01 %s sec GMT' +%%Y/%%m/%%d" % exp_on,
			shell=True).decode().strip()
		exp_disp = sp.check_output(
			"date -u --date='1970-01-01 %s sec GMT' '+%%d %%b %%Y'" % exp_on,
			shell=True).decode().strip()
		sp.run("usermod -e %s %s" % (exp_iso, user), shell=True,
		       stdout=sp.DEVNULL, stderr=sp.DEVNULL, timeout=20)
		sp.run("passwd -u %s" % user, shell=True,
		       stdout=sp.DEVNULL, stderr=sp.DEVNULL, timeout=20)
		sp.run("usermod -U %s" % user, shell=True,
		       stdout=sp.DEVNULL, stderr=sp.DEVNULL, timeout=20)
		if reset_q == "y":
			sp.run("echo 0 > /etc/limit/ssh/%s" % user, shell=True,
			       stdout=sp.DEVNULL, stderr=sp.DEVNULL, timeout=15)
			sp.run("rm -f /etc/limit/ssh/%s.lock" % user, shell=True,
			       stdout=sp.DEVNULL, stderr=sp.DEVNULL, timeout=15)
		if int(new_q) > 0:
			d = int(new_q) * 1024 * 1024 * 1024
			sp.run("echo %s > /etc/ssh/%s" % (d, user), shell=True,
			       stdout=sp.DEVNULL, stderr=sp.DEVNULL, timeout=15)
		return exp_disp
	exp_disp = await asyncio.to_thread(_do_renew)

	msg = "✅ **SSH Berhasil Direnew**\n```\n" \
	      "Username   : %s\n" \
	      "Days Added : %s Hari\n" \
	      "Expires On : %s\n" \
	      "Reset Kuota: %s\n" \
	      "Limit Quota: %s\n```" % (
	          user, hari, exp_disp,
	          "Ya (usage=0)" if reset_q == "y" else "Tidak",
	          ("Diubah ke %s GB" % new_q) if int(new_q) > 0 else "Tetap")
	await balas(event, msg, buttons=[[Button.inline("‹ Main Menu ›", "menu")]])


# ============================================================
#  MENU SSH
# ============================================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	if valid(str(event.sender_id)) != "true":
		await event.answer("Access Denied", alert=True)
		return
	inline = [
		[Button.inline(" TRIAL SSH ", "trial-ssh"),
		 Button.inline(" CREATE SSH ", "create-ssh")],
		[Button.inline(" RENEW SSH ", "renew-ssh"),
		 Button.inline(" DELETE SSH ", "delete-ssh")],
		[Button.inline(" CHECK LOGIN SSH ", "login-ssh")],
		[Button.inline(" SHOW ALL USER SSH ", "show-ssh")],
		[Button.inline("‹ Main Menu ›", "menu")]]
	try:
		z = requests.get("http://ip-api.com/json/?fields=country,isp",
		                 timeout=10).json()
	except Exception:
		z = {"isp": "-", "country": "-"}
	msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**SSH OVPN MANAGER**
━━━━━━━━━━━━━━━━━━━━━━━
Service     : `SSH OVPN`
Hostname/IP : `{DOMAIN}`
ISP         : `{z.get("isp", "-")}`
Country     : `{z.get("country", "-")}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
	await safe_send(event, msg, inline)
