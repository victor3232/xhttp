# -*- coding: utf-8 -*-
# ============================================================
#  store_lib.py - inti "VPN STORE" untuk bot Telegram
#  (database, saldo, produk, pesanan, Duitku, pembuat akun)
# ============================================================
import os
import re
import json
import time
import random
import string
import sqlite3
import hashlib
import subprocess
import datetime as DT

import requests

import kyt

DB_PATH = "kyt/database.db"

TIPE_LABEL = {
    "ssh": "SSH / OVPN",
    "ovpn": "OpenVPN (via akun SSH)",
    "vmess": "VMess",
    "vless": "VLESS",
    "trojan": "Trojan",
    "ss": "Shadowsocks",
    "l2tp": "L2TP / IKEv2",
}


# ---------------- util ----------------
def cfg(name, default=""):
    """Ambil variabel dari var.txt (aman kalau belum ada)."""
    v = getattr(kyt, name, None)
    if v is None or str(v).strip() == "":
        return default
    return str(v).strip()


def rupiah(n):
    try:
        n = int(n)
    except Exception:
        n = 0
    return "Rp " + format(n, ",d").replace(",", ".")


def now():
    return DT.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------- database ----------------
def db():
    x = sqlite3.connect(DB_PATH, timeout=20)
    x.row_factory = sqlite3.Row
    return x


def init_store():
    x = db()
    c = x.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS store_user(
        user_id TEXT PRIMARY KEY,
        username TEXT,
        nama TEXT,
        saldo INTEGER DEFAULT 0,
        created TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS produk(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kode TEXT UNIQUE,
        nama TEXT,
        tipe TEXT,
        harga INTEGER,
        hari INTEGER,
        quota TEXT DEFAULT '0',
        iplimit TEXT DEFAULT '0',
        aktif INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS deposit(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT UNIQUE,
        user_id TEXT,
        amount INTEGER,
        status TEXT DEFAULT 'PENDING',
        method TEXT,
        method_name TEXT,
        reference TEXT,
        pay_url TEXT,
        va TEXT,
        qr TEXT,
        created TEXT,
        paid_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS pesanan(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT UNIQUE,
        user_id TEXT,
        produk_kode TEXT,
        nama_produk TEXT,
        tipe TEXT,
        harga INTEGER,
        akun TEXT,
        password TEXT,
        detail TEXT,
        status TEXT DEFAULT 'AKTIF',
        created TEXT,
        expired TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS settings(
        k TEXT PRIMARY KEY,
        v TEXT)""")
    x.commit()
    _seed_produk(c)
    x.commit()
    x.close()


def _seed_produk(c):
    c.execute("SELECT COUNT(*) AS n FROM produk")
    if c.fetchone()["n"] > 0:
        return
    data = [
        # kode, nama, tipe, harga, hari, quota, iplimit
        ("ssh-7",    "SSH/OVPN 7 Hari",   "ssh",    10000,  7,  "0", "0"),
        ("ssh-30",   "SSH/OVPN 30 Hari",  "ssh",    20000, 30,  "0", "0"),
        ("vmess-30", "VMess 30 Hari",     "vmess",  20000, 30,  "0", "0"),
        ("vless-30", "VLESS 30 Hari",     "vless",  20000, 30,  "0", "0"),
        ("tr-30",    "Trojan 30 Hari",    "trojan", 20000, 30,  "0", "0"),
        ("ss-30",    "Shadowsocks 30 Hari", "ss",   20000, 30,  "0", "0"),
        ("l2tp-30",  "L2TP/IKEv2 30 Hari", "l2tp",  20000, 30,  "0", "0"),
    ]
    for kode, nama, tipe, harga, hari, quota, ip in data:
        c.execute("INSERT OR IGNORE INTO produk(kode,nama,tipe,harga,hari,quota,iplimit,aktif)"
                  " VALUES(?,?,?,?,?,?,?,1)", (kode, nama, tipe, harga, hari, quota, ip))


# ---------------- settings ----------------
def set_setting(k, v):
    x = db()
    x.execute("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
              (k, str(v)))
    x.commit()
    x.close()


def get_setting(k, default=""):
    try:
        x = db()
        r = x.execute("SELECT v FROM settings WHERE k=?", (k,)).fetchone()
        x.close()
        if r and r["v"] is not None and str(r["v"]) != "":
            return str(r["v"])
    except Exception:
        pass
    return default


# ---------------- user / saldo ----------------
def get_user(user_id):
    x = db()
    r = x.execute("SELECT * FROM store_user WHERE user_id=?", (str(user_id),)).fetchone()
    x.close()
    return r


def get_or_create_user(user_id, username="", nama=""):
    r = get_user(user_id)
    if r:
        return r
    x = db()
    x.execute("INSERT OR IGNORE INTO store_user(user_id,username,nama,saldo,created)"
              " VALUES(?,?,?,0,?)", (str(user_id), username or "", nama or "", now()))
    x.commit()
    x.close()
    return get_user(user_id)


def saldo_tambah(user_id, jumlah):
    x = db()
    x.execute("UPDATE store_user SET saldo = saldo + ? WHERE user_id=?", (int(jumlah), str(user_id)))
    x.commit()
    x.close()


def saldo_kurang(user_id, jumlah):
    """True kalau saldo cukup & berhasil dipotong."""
    x = db()
    c = x.cursor()
    c.execute("UPDATE store_user SET saldo = saldo - ? WHERE user_id=? AND saldo >= ?",
              (int(jumlah), str(user_id), int(jumlah)))
    ok = c.rowcount > 0
    x.commit()
    x.close()
    return ok


# ---------------- produk ----------------
def produk_by_tipe(tipe, hanya_aktif=True):
    x = db()
    q = "SELECT * FROM produk WHERE tipe=?"
    if hanya_aktif:
        q += " AND aktif=1"
    q += " ORDER BY harga ASC"
    r = x.execute(q, (tipe,)).fetchall()
    x.close()
    return r


def produk_semua():
    x = db()
    r = x.execute("SELECT * FROM produk ORDER BY tipe ASC, harga ASC").fetchall()
    x.close()
    return r


def produk_by_kode(kode):
    x = db()
    r = x.execute("SELECT * FROM produk WHERE kode=?", (kode,)).fetchone()
    x.close()
    return r


def produk_tipe_tersedia():
    x = db()
    r = x.execute("SELECT DISTINCT tipe FROM produk WHERE aktif=1").fetchall()
    x.close()
    urut = ["ssh", "ovpn", "vmess", "vless", "trojan", "ss", "l2tp"]
    ada = [v["tipe"] for v in r]
    return [t for t in urut if t in ada]


# ---------------- Duitku ----------------
def dk_base():
    return "https://sandbox.duitku.com" if get_setting("duitku_sandbox", "0") == "1" \
        else "https://api-prod.duitku.com"


def dk_merchant():
    return get_setting("duitku_merchant", cfg("DUITKU_MERCHANT", ""))


def dk_apikey():
    return get_setting("duitku_apikey", cfg("DUITKU_APIKEY", ""))


def dk_ready():
    return bool(dk_merchant() and dk_apikey())


def _post(url, payload):
    try:
        r = requests.post(url, json=payload, timeout=30)
        return r.json()
    except Exception as e:
        return {"statusCode": "99", "statusMessage": "Gagal konek Duitku: %s" % e,
                "resultCode": "99", "resultMessage": "Gagal konek Duitku: %s" % e}


def duitku_create(order_id, amount, method, produk_nama, email, phone, nama):
    mc, ak = dk_merchant(), dk_apikey()
    sig = hashlib.md5(("%s%s%s%s" % (mc, order_id, amount, ak)).encode()).hexdigest()
    dom = cfg("DOMAIN", "")
    payload = {
        "merchantCode": mc,
        "paymentAmount": int(amount),
        "paymentMethod": method,
        "merchantOrderId": order_id,
        "productDetails": produk_nama,
        "additionalParam": "",
        "merchantUserInfo": "",
        "customerVaName": (nama or "Customer")[:20],
        "email": email or ("user%s@%s" % (order_id, dom or "mail.com")),
        "phoneNumber": phone or "08123456789",
        "callbackUrl": get_setting("callback_url", "https://%s/duitku/callback" % (dom or "localhost")),
        "returnUrl": get_setting("return_url", "https://%s/duitku/return" % (dom or "localhost")),
        "signature": sig,
        "expiryPeriod": int(get_setting("expiry_period", "60")),
    }
    return _post(dk_base() + "/api/merchant/createInvoice", payload)


def duitku_status(order_id):
    mc, ak = dk_merchant(), dk_apikey()
    sig = hashlib.md5(("%s%s%s" % (mc, order_id, ak)).encode()).hexdigest()
    return _post(dk_base() + "/api/merchant/transactionStatus",
                 {"merchantCode": mc, "merchantOrderId": order_id, "signature": sig})


def duitku_methods(amount=10000):
    mc, ak = dk_merchant(), dk_apikey()
    sig = hashlib.md5(("%s%s%s" % (mc, amount, ak)).encode()).hexdigest()
    return _post(dk_base() + "/api/merchant/getPaymentMethod",
                 {"merchantCode": mc, "amount": int(amount), "signature": sig})


# ---------------- deposit ----------------
def deposit_baru(order_id, user_id, amount, method, method_name):
    x = db()
    x.execute("INSERT INTO deposit(order_id,user_id,amount,status,method,method_name,created)"
              " VALUES(?,?,?,'PENDING',?,?,?)",
              (order_id, str(user_id), int(amount), method, method_name, now()))
    x.commit()
    x.close()


def deposit_update(order_id, **kw):
    if not kw:
        return
    cols = ", ".join("%s=?" % k for k in kw)
    vals = list(kw.values()) + [order_id]
    x = db()
    x.execute("UPDATE deposit SET %s WHERE order_id=?" % cols, vals)
    x.commit()
    x.close()


def deposit_by_order(order_id):
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE order_id=?", (order_id,)).fetchone()
    x.close()
    return r


def deposit_pending():
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE status='PENDING' ORDER BY id ASC").fetchall()
    x.close()
    return r


def deposit_riwayat(user_id, limit=10):
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE user_id=? ORDER BY id DESC LIMIT ?",
                  (str(user_id), limit)).fetchall()
    x.close()
    return r


# ---------------- pesanan ----------------
def pesanan_baru(order_id, user_id, produk, akun, password, detail, expired):
    x = db()
    x.execute("INSERT INTO pesanan(order_id,user_id,produk_kode,nama_produk,tipe,harga,akun,"
              "password,detail,status,created,expired) VALUES(?,?,?,?,?,?,?,?,?,'AKTIF',?,?)",
              (order_id, str(user_id), produk["kode"], produk["nama"], produk["tipe"],
               int(produk["harga"]), akun, password or "", detail or "", now(), expired))
    x.commit()
    x.close()


def pesanan_user(user_id, limit=10):
    x = db()
    r = x.execute("SELECT * FROM pesanan WHERE user_id=? ORDER BY id DESC LIMIT ?",
                  (str(user_id), limit)).fetchall()
    x.close()
    return r


def pesanan_semua(limit=20):
    x = db()
    r = x.execute("SELECT * FROM pesanan ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    x.close()
    return r


def pesanan_by_id(pid):
    x = db()
    r = x.execute("SELECT * FROM pesanan WHERE id=?", (pid,)).fetchone()
    x.close()
    return r


def pesanan_hapus(pid):
    p = pesanan_by_id(pid)
    if not p:
        return False
    _hapus_akun(p["tipe"], p["akun"])
    x = db()
    x.execute("DELETE FROM pesanan WHERE id=?", (pid,))
    x.commit()
    x.close()
    return True


# ---------------- pembuat akun ----------------
def _rand(n=5):
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))


def buat_username(tipe):
    pre = {"ssh": "ssh", "ovpn": "ovpn", "vmess": "vm", "vless": "vl",
           "trojan": "tr", "ss": "ss", "l2tp": "l2"}.get(tipe, "us")
    for _ in range(30):
        u = pre + _rand(5)
        if not _username_dipakai(u):
            return u
    return pre + _rand(8)


def _username_dipakai(u):
    x = db()
    r = x.execute("SELECT 1 FROM pesanan WHERE akun=?", (u,)).fetchone()
    x.close()
    if r:
        return True
    try:
        with open("/etc/passwd") as f:
            if re.search(r"^%s:" % re.escape(u), f.read(), re.M):
                return True
    except Exception:
        pass
    return False


def buat_akun(tipe, user, hari, quota="0", iplimit="0", password=None):
    """Bikin akun pakai script panel. Return (ok, output)."""
    hari = str(int(hari))
    quota = str(quota or "0")
    iplimit = str(iplimit or "0")
    pw = password or _rand(8)

    if tipe in ("ssh", "ovpn"):
        # addssh: Username, Password, Limit IP, Limit Quota, Expired (Days)
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" "%s" "%s" | addssh' % (user, pw, iplimit, quota, hari)
    elif tipe == "vmess":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" "%s" | addws' % (user, hari, quota, iplimit)
    elif tipe == "vless":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" "%s" | addvless' % (user, hari, quota, iplimit)
    elif tipe == "trojan":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" "%s" | addtr' % (user, hari, quota, iplimit)
    elif tipe == "ss":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" | addss' % (user, hari, quota)
    elif tipe == "l2tp":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" | add-l2tp' % (user, pw, hari)
    else:
        return False, "Tipe tidak dikenal: %s" % tipe

    try:
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT,
                                      timeout=120).decode("utf-8", "ignore")
        return True, out
    except subprocess.CalledProcessError as e:
        return False, (e.output or b"").decode("utf-8", "ignore")
    except Exception as e:
        return False, str(e)


def _hapus_akun(tipe, user):
    if not user:
        return
    if tipe in ("ssh", "ovpn"):
        cmd = 'printf "%%s\\n" "%s" | delssh' % user
    elif tipe == "vmess":
        cmd = 'printf "%%s\\n" "%s" | delws' % user
    elif tipe == "vless":
        cmd = 'printf "%%s\\n" "%s" | delvless' % user
    elif tipe == "trojan":
        cmd = 'printf "%%s\\n" "%s" | deltr' % user
    elif tipe == "ss":
        cmd = 'printf "%%s\\n" "%s" | del-ss' % user
    elif tipe == "l2tp":
        cmd = 'printf "%%s\\n" "%s" | del-l2tp' % user
    else:
        return
    try:
        subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=60)
    except Exception:
        pass


def ambil_link(out):
    """Ambil link akun dari output script panel."""
    links = []
    for proto in ("vmess", "vless", "trojan", "ss"):
        for m in re.finditer(r"(?<![A-Za-z0-9])" + proto + r"://[^\s`'\"]+", out or ""):
            links.append(m.group(0).strip())
    # hilangkan duplikat, jaga urutan
    seen, res = set(), []
    for l in links:
        if l not in seen:
            seen.add(l)
            res.append(l)
    return res


def detail_ssh(user, pw):
    dom = cfg("DOMAIN", "")
    return (
        "Host: %s\n"
        "Username: %s\n"
        "Password: %s\n"
        "Port OpenSSH: 443, 80, 22\n"
        "Port Dropbear: 443, 109\n"
        "Port SSH WS: 80, 8080, 8081-9999\n"
        "Port SSL/TLS: 222-1000\n"
        "Port OVPN TCP: 443, 1194\n"
        "Port OVPN UDP: 2200\n"
        "OVPN WS SSL : https://%s:81/ws-ssl.ovpn\n"
        "OVPN SSL    : https://%s:81/ssl.ovpn\n"
        "OVPN TCP    : https://%s:81/tcp.ovpn\n"
        "OVPN UDP    : https://%s:81/udp.ovpn\n"
        "Save Link   : https://%s:81/ssh-%s.txt"
    ) % (dom, user, pw, dom, dom, dom, dom, dom, user)


def detail_l2tp(user, pw):
    dom = cfg("DOMAIN", "")
    psk = ""
    try:
        with open("/etc/l2tp/psk") as f:
            psk = f.read().strip()
    except Exception:
        pass
    return ("Server: %s\nUsername: %s\nPassword: %s\nPSK/IPSec: %s\n"
            "Port: 500/4500/1701 (UDP)") % (dom, user, pw, psk or "-")
