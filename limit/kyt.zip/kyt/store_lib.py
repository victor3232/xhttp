# -*- coding: utf-8 -*-
# ============================================================
#  store_lib.py - inti "VPN STORE" untuk bot Telegram
#  (database, saldo, produk, pesanan, Duitku, pembuat akun)
# ============================================================
import os
import re
import json
import time
import random
import string
import sqlite3
import hashlib
import hmac
import signal
import subprocess
import datetime as DT
from urllib.parse import quote as _urlquote

import requests

import kyt

DB_PATH = "kyt/database.db"

TIPE_LABEL = {
    "ssh": "SSH / OVPN",
    "ovpn": "OpenVPN (via akun SSH)",
    "vmess": "VMess",
    "vless": "VLESS",
    "trojan": "Trojan",
    "ss": "Shadowsocks",
    "l2tp": "L2TP / IKEv2",
}

# ---- masa aktif: SERAGAM 3 / 7 / 30 hari untuk semua tipe ----
HARI_PILIHAN = [3, 7, 30]
HARGA_DEFAULT = {3: 5000, 7: 10000, 30: 25000}
# tipe produk yang benar-benar dijual di store
TIPE_JUAL = ["ssh", "vmess", "vless", "trojan", "ss", "l2tp"]

# Script panel: apakah "renew" MENAMBAH sisa hari (True) atau
# menghitung ulang dari hari ini (False)?
RENEW_TAMBAH = {"vmess": True, "vless": True, "trojan": True, "ss": True,
                "ssh": False, "ovpn": False, "l2tp": False}

TAG_XRAY = {"vmess": "###", "vless": "#&", "trojan": "#!", "ss": "#!#"}


# ---------------- util ----------------
def _bersih(v):
    """Buang tanda kutip/spasi sisa dari penulisan var.txt."""
    return str(v).strip().strip('"').strip("'").strip()


def cfg(name, default=""):
    """Ambil variabel dari var.txt (aman kalau belum ada)."""
    v = getattr(kyt, name, None)
    if v is None or str(v).strip() == "":
        return default
    return _bersih(v)


def admin_id():
    """ID Telegram admin (angka saja)."""
    return _bersih(cfg("ADMIN", ""))


def rupiah(n):
    try:
        n = int(n)
    except Exception:
        n = 0
    return "Rp " + format(n, ",d").replace(",", ".")


# ---------------- gambar /start ----------------
def gambar_start():
    """Gambar untuk /start: URL (catbox/qu.ax dll) atau file lokal.
    Kosong = kirim teks saja."""
    v = (get_setting("start_image", "") or cfg("START_IMAGE", "") or "").strip()
    if not v:
        return ""
    if v.startswith("http://") or v.startswith("https://"):
        return v
    for kandidat in (v, os.path.join("kyt", v), os.path.join("/usr/bin/kyt", v)):
        try:
            if os.path.isfile(kandidat):
                return kandidat
        except Exception:
            continue
    return ""


def now():
    return DT.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------- database ----------------
def db():
    x = sqlite3.connect(DB_PATH, timeout=20)
    x.row_factory = sqlite3.Row
    return x


def init_store():
    x = db()
    c = x.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS store_user(
        user_id TEXT PRIMARY KEY,
        username TEXT,
        nama TEXT,
        saldo INTEGER DEFAULT 0,
        created TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS produk(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kode TEXT UNIQUE,
        nama TEXT,
        tipe TEXT,
        harga INTEGER,
        hari INTEGER,
        quota TEXT DEFAULT '0',
        iplimit TEXT DEFAULT '0',
        aktif INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS deposit(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT UNIQUE,
        user_id TEXT,
        amount INTEGER,
        status TEXT DEFAULT 'PENDING',
        method TEXT,
        method_name TEXT,
        reference TEXT,
        pay_url TEXT,
        va TEXT,
        qr TEXT,
        created TEXT,
        paid_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS pesanan(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT UNIQUE,
        user_id TEXT,
        produk_kode TEXT,
        nama_produk TEXT,
        tipe TEXT,
        harga INTEGER,
        akun TEXT,
        password TEXT,
        detail TEXT,
        status TEXT DEFAULT 'AKTIF',
        created TEXT,
        expired TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS settings(
        k TEXT PRIMARY KEY,
        v TEXT)""")
    x.commit()
    _migrasi(x)
    _seed_produk(c)
    x.commit()
    x.close()


def _kolom(c, tabel):
    try:
        return [r[1] for r in c.execute("PRAGMA table_info(%s)" % tabel).fetchall()]
    except Exception:
        return []


def _migrasi(x):
    """Tambah kolom baru tanpa menghapus data lama."""
    c = x.cursor()
    kol = _kolom(c, "pesanan")
    for nama, tipe in (("exp_iso", "TEXT"), ("notif", "TEXT DEFAULT ''"),
                       ("hari", "INTEGER DEFAULT 0"), ("renew_at", "TEXT")):
        if nama not in kol:
            try:
                c.execute("ALTER TABLE pesanan ADD COLUMN %s %s" % (nama, tipe))
            except Exception:
                pass
    # isi exp_iso dari kolom 'expired' lama (format "20 Okt 2026")
    try:
        for r in c.execute("SELECT id, expired FROM pesanan"
                           " WHERE (exp_iso IS NULL OR exp_iso='') AND expired IS NOT NULL").fetchall():
            d = _parse_tgl_tampil(r[1])
            if d:
                c.execute("UPDATE pesanan SET exp_iso=? WHERE id=?", (d, r[0]))
    except Exception:
        pass
    x.commit()


def _parse_tgl_tampil(s):
    """'20 Okt 2026' -> '2026-10-20' (coba beberapa format)."""
    s = (s or "").strip()
    if not s:
        return None
    for f in ("%d %b %Y", "%d %B %Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return DT.datetime.strptime(s, f).strftime("%Y-%m-%d")
        except Exception:
            continue
    return None


def _seed_produk(c):
    """Semua tipe x masa aktif 3/7/30 hari (seragam)."""
    ada = set()
    try:
        ada = {r[0] for r in c.execute("SELECT kode FROM produk").fetchall()}
    except Exception:
        pass
    for tipe in TIPE_JUAL:
        label = TIPE_LABEL.get(tipe, tipe).replace(" / ", "/")
        for h in HARI_PILIHAN:
            kode = "%s-%d" % (tipe, h)
            if kode in ada:
                continue
            c.execute(
                "INSERT OR IGNORE INTO produk(kode,nama,tipe,harga,hari,quota,iplimit,aktif)"
                " VALUES(?,?,?,?,?,?,?,1)",
                (kode, "%s %d Hari" % (label, h), tipe,
                 HARGA_DEFAULT.get(h, 10000), h, "0", "0"))
    # bersihkan produk lama yang tidak dipakai skema baru (mis. 'tr-30')
    kode_baru = {"%s-%d" % (t, h) for t in TIPE_JUAL for h in HARI_PILIHAN}
    for r in c.execute("SELECT kode FROM produk").fetchall():
        k = r[0]
        if k in kode_baru:
            continue
        dipakai = c.execute("SELECT COUNT(*) FROM pesanan WHERE produk_kode=?", (k,)).fetchone()[0]
        if dipakai:
            c.execute("UPDATE produk SET aktif=0 WHERE kode=?", (k,))
        else:
            c.execute("DELETE FROM produk WHERE kode=?", (k,))


# ---------------- settings ----------------
def set_setting(k, v):
    x = db()
    x.execute("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
              (k, str(v)))
    x.commit()
    x.close()


def get_setting(k, default=""):
    try:
        x = db()
        r = x.execute("SELECT v FROM settings WHERE k=?", (k,)).fetchone()
        x.close()
        if r and r["v"] is not None and str(r["v"]) != "":
            return str(r["v"])
    except Exception:
        pass
    return default


# ---------------- user / saldo ----------------
def get_user(user_id):
    x = db()
    r = x.execute("SELECT * FROM store_user WHERE user_id=?", (str(user_id),)).fetchone()
    x.close()
    return r


def get_or_create_user(user_id, username="", nama=""):
    r = get_user(user_id)
    if r:
        return r
    x = db()
    x.execute("INSERT OR IGNORE INTO store_user(user_id,username,nama,saldo,created)"
              " VALUES(?,?,?,0,?)", (str(user_id), username or "", nama or "", now()))
    x.commit()
    x.close()
    return get_user(user_id)


def saldo_tambah(user_id, jumlah):
    x = db()
    x.execute("UPDATE store_user SET saldo = saldo + ? WHERE user_id=?", (int(jumlah), str(user_id)))
    x.commit()
    x.close()


def saldo_kurang(user_id, jumlah):
    """True kalau saldo cukup & berhasil dipotong."""
    x = db()
    c = x.cursor()
    c.execute("UPDATE store_user SET saldo = saldo - ? WHERE user_id=? AND saldo >= ?",
              (int(jumlah), str(user_id), int(jumlah)))
    ok = c.rowcount > 0
    x.commit()
    x.close()
    return ok


# ---------------- produk ----------------
def produk_by_tipe(tipe, hanya_aktif=True):
    x = db()
    q = "SELECT * FROM produk WHERE tipe=?"
    if hanya_aktif:
        q += " AND aktif=1"
    q += " ORDER BY hari ASC, harga ASC"
    r = x.execute(q, (tipe,)).fetchall()
    x.close()
    return r


def produk_by_tipe_hari(tipe, hari):
    x = db()
    r = x.execute("SELECT * FROM produk WHERE tipe=? AND hari=? AND aktif=1"
                  " ORDER BY harga ASC LIMIT 1", (tipe, int(hari))).fetchone()
    x.close()
    return r


def produk_semua():
    x = db()
    urut = " ".join("WHEN '%s' THEN %d" % (t, i) for i, t in enumerate(
        ["ssh", "ovpn", "vmess", "vless", "trojan", "ss", "l2tp"]))
    r = x.execute("SELECT * FROM produk ORDER BY CASE tipe %s ELSE 99 END,"
                  " hari ASC, harga ASC" % urut).fetchall()
    x.close()
    return r


def produk_by_kode(kode):
    x = db()
    r = x.execute("SELECT * FROM produk WHERE kode=?", (kode,)).fetchone()
    x.close()
    return r


def produk_tipe_tersedia():
    x = db()
    r = x.execute("SELECT DISTINCT tipe FROM produk WHERE aktif=1").fetchall()
    x.close()
    urut = ["ssh", "ovpn", "vmess", "vless", "trojan", "ss", "l2tp"]
    ada = [v["tipe"] for v in r]
    return [t for t in urut if t in ada]


# ---------------- Duitku (API v2 - Inquiry) ----------------
# Dokumentasi: https://docs.duitku.com/api/en/
# Signature WAJIB HMAC-SHA256 (MD5 sudah obsolete sejak April 2026)
# Endpoint dev  : https://sandbox.duitku.com/webapi
# Endpoint prod : https://passport.duitku.com/webapi
# Kode QRIS: SP = ShopeePay | NQ = Nobu | SQ = Nusapay

QRIS_OPTIONS = [
    {"code": "SP", "name": "QRIS ShopeePay"},
    {"code": "NQ", "name": "QRIS Nobu"},
    {"code": "SQ", "name": "QRIS Nusapay"},
]


def dk_dev():
    return str(get_setting("duitku_sandbox", "0")).strip() == "1"


def dk_base():
    return "https://sandbox.duitku.com/webapi" if dk_dev() \
        else "https://passport.duitku.com/webapi"


def dk_merchant():
    return (get_setting("duitku_merchant", cfg("DUITKU_MERCHANT", "")) or "").strip()


def dk_apikey():
    return (get_setting("duitku_apikey", cfg("DUITKU_APIKEY", "")) or "").strip()


def dk_ready():
    return bool(dk_merchant() and dk_apikey())


def dk_method():
    return (get_setting("duitku_method", "SP") or "SP").strip().upper()


def dk_method_name():
    k = dk_method()
    for m in QRIS_OPTIONS:
        if m["code"] == k:
            return m["name"]
    return "QRIS %s" % k


def dk_expiry():
    """QRIS: default 10 menit, maksimal 60 menit."""
    try:
        v = int(get_setting("expiry_period", "10") or 10)
    except Exception:
        v = 10
    return max(1, min(60, v))


def _sig(string_to_sign):
    return hmac.new(dk_apikey().encode(), string_to_sign.encode(),
                    hashlib.sha256).hexdigest()


def _post(url, payload):
    """POST JSON ke Duitku. Selalu kembalikan dict + info diagnostik."""
    try:
        r = requests.post(url, json=payload, timeout=30,
                          headers={"Content-Type": "application/json",
                                   "Accept": "application/json"})
    except Exception as e:
        return {"statusCode": "99",
                "statusMessage": "Tidak bisa konek ke Duitku: %s" % e,
                "_http": 0, "_raw": ""}
    raw = (r.text or "").strip()
    data = None
    try:
        data = r.json()
    except Exception:
        data = None
    if isinstance(data, dict):
        data["_http"] = r.status_code
        data["_raw"] = raw[:300]
        return data
    # bukan JSON (mis. "Unauthorized" / "Wrong Signature")
    return {"statusCode": "99",
            "statusMessage": "Duitku HTTP %s: %s" % (r.status_code, (raw or "(kosong)")[:180]),
            "_http": r.status_code, "_raw": raw[:300]}


def _err(res):
    """Ambil pesan error yang bisa dibaca dari respons Duitku."""
    for k in ("statusMessage", "Message", "message", "_raw"):
        v = res.get(k)
        if v:
            return str(v)
    return "respons tidak dikenal"


def duitku_create(order_id, amount, method, produk_nama, email, phone, nama):
    """Buat tagihan (inquiry). Signature = HMAC(merchantCode + orderId + amount)."""
    mc = dk_merchant()
    amount = int(amount)
    dom = cfg("DOMAIN", "")
    payload = {
        "merchantCode": mc,
        "paymentAmount": amount,
        "paymentMethod": method,
        "merchantOrderId": order_id,
        "productDetails": produk_nama,
        "additionalParam": "",
        "merchantUserInfo": "",
        "customerVaName": (nama or "Customer")[:20],
        "email": email or ("user%s@%s" % (order_id, dom or "mail.com")),
        "phoneNumber": phone or "08123456789",
        "callbackUrl": get_setting("callback_url",
                                   "https://%s/duitku/callback" % (dom or "localhost")),
        "returnUrl": get_setting("return_url",
                                 "https://%s/duitku/return" % (dom or "localhost")),
        "signature": _sig("%s%s%s" % (mc, order_id, amount)),
        "expiryPeriod": dk_expiry(),
    }
    return _post(dk_base() + "/api/merchant/v2/inquiry", payload)


def duitku_status(order_id):
    """Cek status. Signature = HMAC(merchantCode + orderId)."""
    mc = dk_merchant()
    return _post(dk_base() + "/api/merchant/transactionStatus",
                 {"merchantCode": mc, "merchantOrderId": order_id,
                  "signature": _sig("%s%s" % (mc, order_id))})


def duitku_methods(amount=10000):
    """Daftar metode aktif. Signature = HMAC(merchantcode + amount + datetime)."""
    mc = dk_merchant()
    dt = DT.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return _post(dk_base() + "/api/merchant/paymentmethod/getpaymentmethod",
                 {"merchantcode": mc, "amount": str(int(amount)),
                  "datetime": dt, "signature": _sig("%s%s%s" % (mc, int(amount), dt))})


def qr_image_url(qrstring, size=600):
    """URL gambar QR (dipakai Telegram untuk kirim foto QRIS)."""
    return ("https://api.qrserver.com/v1/create-qr-code/?size=%dx%d&margin=8&data=%s"
            % (size, size, _urlquote(qrstring or "", safe="")))


def qr_png(qrstring, size=600):
    """Ambil gambar QR (PNG bytes). None kalau gagal."""
    if not qrstring:
        return None
    urls = [
        qr_image_url(qrstring, size),
        "https://quickchart.io/qr?size=%d&text=%s" % (size, _urlquote(qrstring, safe="")),
    ]
    for u in urls:
        try:
            r = requests.get(u, timeout=20)
            if r.status_code == 200 and r.content and len(r.content) > 100:
                return r.content
        except Exception:
            continue
    return None


# ---------------- deposit ----------------
def deposit_baru(order_id, user_id, amount, method, method_name):
    x = db()
    x.execute("INSERT INTO deposit(order_id,user_id,amount,status,method,method_name,created)"
              " VALUES(?,?,?,'PENDING',?,?,?)",
              (order_id, str(user_id), int(amount), method, method_name, now()))
    x.commit()
    x.close()


def deposit_update(order_id, **kw):
    if not kw:
        return
    cols = ", ".join("%s=?" % k for k in kw)
    vals = list(kw.values()) + [order_id]
    x = db()
    x.execute("UPDATE deposit SET %s WHERE order_id=?" % cols, vals)
    x.commit()
    x.close()


def deposit_by_order(order_id):
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE order_id=?", (order_id,)).fetchone()
    x.close()
    return r


def deposit_pending():
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE status='PENDING' ORDER BY id ASC").fetchall()
    x.close()
    return r


def deposit_riwayat(user_id, limit=10):
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE user_id=? ORDER BY id DESC LIMIT ?",
                  (str(user_id), limit)).fetchall()
    x.close()
    return r


# ---------------- pesanan ----------------
def pesanan_baru(order_id, user_id, produk, akun, password, detail, expired, exp_iso=None):
    if not exp_iso:
        exp_iso = _parse_tgl_tampil(expired)
    x = db()
    x.execute("INSERT INTO pesanan(order_id,user_id,produk_kode,nama_produk,tipe,harga,akun,"
              "password,detail,status,created,expired,exp_iso,hari,notif)"
              " VALUES(?,?,?,?,?,?,?,?,?,'AKTIF',?,?,?,?,'')",
              (order_id, str(user_id), produk["kode"], produk["nama"], produk["tipe"],
               int(produk["harga"]), akun, password or "", detail or "", now(), expired,
               exp_iso, int(produk["hari"] or 0)))
    x.commit()
    x.close()


def pesanan_user(user_id, limit=10):
    x = db()
    r = x.execute("SELECT * FROM pesanan WHERE user_id=? ORDER BY id DESC LIMIT ?",
                  (str(user_id), limit)).fetchall()
    x.close()
    return r


def pesanan_semua(limit=20):
    x = db()
    r = x.execute("SELECT * FROM pesanan ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    x.close()
    return r


def pesanan_by_id(pid):
    x = db()
    r = x.execute("SELECT * FROM pesanan WHERE id=?", (pid,)).fetchone()
    x.close()
    return r


def pesanan_hapus(pid):
    p = pesanan_by_id(pid)
    if not p:
        return False
    _hapus_akun(p["tipe"], p["akun"])
    x = db()
    x.execute("DELETE FROM pesanan WHERE id=?", (pid,))
    x.commit()
    x.close()
    return True


# ---------------- masa aktif (expired) ----------------
def exp_date(p):
    """Tanggal expired pesanan -> datetime.date (atau None)."""
    if not p:
        return None
    try:
        iso = p["exp_iso"]
    except Exception:
        iso = None
    if iso:
        try:
            return DT.datetime.strptime(str(iso)[:10], "%Y-%m-%d").date()
        except Exception:
            pass
    try:
        v = _parse_tgl_tampil(p["expired"])
        if v:
            return DT.datetime.strptime(v, "%Y-%m-%d").date()
    except Exception:
        pass
    return None


def sisa_hari(p):
    """Sisa hari menuju expired. Negatif = sudah lewat. None = tak diketahui."""
    d = exp_date(p)
    if not d:
        return None
    return (d - DT.date.today()).days


def exp_tampil(d):
    """date -> '20 Okt 2026'."""
    try:
        return d.strftime("%d %b %Y")
    except Exception:
        return "-"


def status_masa(p):
    """Teks status masa aktif (tanpa emoticon)."""
    s = sisa_hari(p)
    if s is None:
        return "Tidak diketahui"
    if s < 0:
        return "Expired %d hari lalu" % abs(s)
    if s == 0:
        return "Expired hari ini"
    return "Aktif %d hari lagi" % s


def status_singkat(p):
    """Status singkat untuk daftar akun."""
    s = sisa_hari(p)
    if s is None:
        return "?"
    if s < 0:
        return "HABIS"
    if s == 0:
        return "H-0"
    return "AKTIF %dh" % s


def pesanan_update_expired(pid, exp_iso, tambah_hari=None):
    x = db()
    if tambah_hari is None:
        x.execute("UPDATE pesanan SET exp_iso=?, expired=?, notif='', status='AKTIF',"
                  " renew_at=? WHERE id=?",
                  (exp_iso, exp_tampil(DT.datetime.strptime(exp_iso, "%Y-%m-%d").date()),
                   now(), pid))
    else:
        x.execute("UPDATE pesanan SET exp_iso=?, expired=?, notif='', status='AKTIF',"
                  " hari=COALESCE(hari,0)+?, renew_at=? WHERE id=?",
                  (exp_iso, exp_tampil(DT.datetime.strptime(exp_iso, "%Y-%m-%d").date()),
                   int(tambah_hari), now(), pid))
    x.commit()
    x.close()


def pesanan_set_status(pid, status):
    x = db()
    x.execute("UPDATE pesanan SET status=? WHERE id=?", (status, pid))
    x.commit()
    x.close()


def pesanan_aktif():
    """Semua pesanan yang belum ditandai EXPIRED (untuk notifikasi masa aktif)."""
    x = db()
    r = x.execute("SELECT * FROM pesanan WHERE status IS NULL OR status!='EXPIRED'"
                  " ORDER BY id DESC").fetchall()
    x.close()
    return r


def sudah_notif(p, tag):
    try:
        n = (p["notif"] or "")
    except Exception:
        n = ""
    return ("|%s|" % tag) in ("|%s|" % n.replace(",", "|"))


def tandai_notif(pid, tag):
    p = pesanan_by_id(pid)
    if not p:
        return
    try:
        n = (p["notif"] or "").strip()
    except Exception:
        n = ""
    ada = [x for x in n.split(",") if x]
    if tag not in ada:
        ada.append(tag)
    x = db()
    x.execute("UPDATE pesanan SET notif=? WHERE id=?", (",".join(ada), pid))
    x.commit()
    x.close()


# ---------------- perpanjang akun (renew) ----------------
def _jalan_script(cmd, jawaban, timeout=30):
    """Jalankan script panel yang interaktif: kirim jawaban via stdin,
    matikan paksa setelah `timeout` detik (script panel suka nunggu input
    di akhir). Return (selesai, output)."""
    data = ("\n".join(str(a) for a in jawaban) + "\n").encode()
    try:
        p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             start_new_session=True)
    except Exception as e:
        return False, str(e)
    try:
        out, _ = p.communicate(input=data, timeout=timeout)
        return True, (out or b"").decode("utf-8", "ignore")
    except subprocess.TimeoutExpired:
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass
        try:
            out, _ = p.communicate(timeout=5)
        except Exception:
            out = b""
        # script panel biasanya sudah selesai mengubah data sebelum menu akhir
        return True, (out or b"").decode("utf-8", "ignore")


def baca_expired_panel(tipe, akun):
    """Baca tanggal expired akun langsung dari sistem panel (YYYY-MM-DD)."""
    if not akun:
        return None
    try:
        if tipe in ("ssh", "ovpn"):
            out = subprocess.check_output(
                "chage -l %s 2>/dev/null" % akun, shell=True,
                stderr=subprocess.DEVNULL, timeout=20).decode("utf-8", "ignore")
            for l in out.splitlines():
                if "expires" in l.lower():
                    v = l.split(":", 1)[-1].strip()
                    if not v or v.lower().startswith("never"):
                        continue
                    for f in ("%b %d, %Y", "%b %d %Y", "%Y-%m-%d", "%d %b %Y"):
                        try:
                            return DT.datetime.strptime(v, f).strftime("%Y-%m-%d")
                        except Exception:
                            continue
        elif tipe == "l2tp":
            out = subprocess.check_output(
                "grep -E '^### %s ' /etc/l2tp/.l2tp.db 2>/dev/null" % akun,
                shell=True, stderr=subprocess.DEVNULL, timeout=20).decode("utf-8", "ignore")
            b = (out or "").split()
            if len(b) >= 3:
                return b[2][:10]
        else:
            tag = TAG_XRAY.get(tipe)
            if tag:
                out = subprocess.check_output(
                    "grep -E '^%s %s ' /etc/xray/config.json 2>/dev/null" % (tag, akun),
                    shell=True, stderr=subprocess.DEVNULL, timeout=20).decode("utf-8", "ignore")
                b = (out or "").split()
                if len(b) >= 3:
                    return b[2][:10]
    except Exception:
        pass
    return None


def hari_perpanjang(tipe, sisa, hari_beli):
    """Hitung angka hari yang harus DIKIRIM ke script renew panel.

    Script panel ada 2 macam:
      - MENAMBAH sisa hari  (vmess/vless/trojan/ss) -> kirim hari_beli saja,
        tapi kalau akun sudah lewat expired, sisa negatif harus dikoreksi.
      - HITUNG ULANG dari hari ini (ssh/l2tp) -> kirim sisa + hari_beli.
    Hasil akhirnya sama: expired baru = max(hari ini, expired lama) + hari_beli.
    """
    hari_beli = int(hari_beli)
    sisa = int(sisa or 0)
    if RENEW_TAMBAH.get(tipe):
        return hari_beli + max(0, -sisa)
    return hari_beli + max(0, sisa)


def renew_akun(tipe, akun, password, hari_beli, sisa, quota="0", iplimit="0"):
    """Perpanjang akun di sistem panel.

    Return (ok, pesan, exp_baru 'YYYY-MM-DD').
    """
    if not akun:
        return False, "Akun kosong.", None
    pass_days = hari_perpanjang(tipe, sisa, hari_beli)
    exp_harap = (DT.date.today() +
                 DT.timedelta(days=int(hari_beli) + max(0, int(sisa or 0)))
                 ).strftime("%Y-%m-%d")

    # ---- SSH/OVPN: langsung (script renewssh panel punya bug passwd kosong) ----
    if tipe in ("ssh", "ovpn"):
        try:
            r = subprocess.run("usermod -e %s %s" % (exp_harap, akun), shell=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
            if r.returncode != 0:
                return False, (r.stdout or b"").decode("utf-8", "ignore")[-300:], None
            subprocess.run("passwd -u %s" % akun, shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
            return True, "OK", exp_harap
        except Exception as e:
            return False, str(e), None

    if tipe == "vmess":
        cmd, ans = "renewws", [akun, pass_days, quota, iplimit]
    elif tipe == "vless":
        cmd, ans = "renewvless", [akun, pass_days, quota, iplimit]
    elif tipe == "trojan":
        cmd, ans = "renewtr", [akun, pass_days, quota, iplimit]
    elif tipe == "ss":
        cmd, ans = "renewss", [akun, pass_days]
    elif tipe == "l2tp":
        cmd, ans = "renew-l2tp", [akun, pass_days]
    else:
        return False, "Tipe tidak dikenal: %s" % tipe, None

    ok, out = _jalan_script(cmd, ans, timeout=35)
    if not ok:
        return False, out, None

    # verifikasi: baca ulang dari file panel
    hasil = baca_expired_panel(tipe, akun)
    if hasil:
        try:
            if hasil < exp_harap:
                # script tidak menerapkan yang kita minta -> koreksi langsung
                _koreksi_expired(tipe, akun, password, exp_harap)
                hasil = baca_expired_panel(tipe, akun) or exp_harap
        except Exception:
            pass
    if tipe == "l2tp":
        try:
            subprocess.run("systemctl restart xl2tpd", shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
        except Exception:
            pass
    return True, (out or "")[-400:], (hasil or exp_harap)


def _koreksi_expired(tipe, akun, password, exp_iso):
    """Tulis langsung tanggal expired ke file/db panel (cadangan)."""
    try:
        if tipe == "l2tp":
            pw = password or ""
            subprocess.run("sed -i '/^### %s /c\\### %s %s %s' /etc/l2tp/.l2tp.db"
                           % (akun, akun, exp_iso, pw), shell=True, timeout=20)
            return
        tag = TAG_XRAY.get(tipe)
        if not tag:
            return
        subprocess.run("sed -i '/^%s %s /c\\%s %s %s' /etc/xray/config.json"
                       % (tag, akun, tag, akun, exp_iso), shell=True, timeout=20)
        berkas = {"vmess": "/etc/vmess/.vmess.db",
                  "vless": "/root/akun/vless/.vless.conf",
                  "trojan": "/root/akun/trojan/.trojan.conf",
                  "ss": "/root/akun/shadowsocks/.shadowsocks.conf"}.get(tipe)
        if berkas:
            subprocess.run("sed -i '/^%s %s /c\\%s %s %s' %s"
                           % (tag, akun, tag, akun, exp_iso, berkas),
                           shell=True, timeout=20)
        subprocess.run("systemctl restart xray", shell=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
    except Exception:
        pass


# ---------------- pembuat akun ----------------
def _rand(n=5):
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))


def buat_username(tipe):
    pre = {"ssh": "ssh", "ovpn": "ovpn", "vmess": "vm", "vless": "vl",
           "trojan": "tr", "ss": "ss", "l2tp": "l2"}.get(tipe, "us")
    for _ in range(30):
        u = pre + _rand(5)
        if not _username_dipakai(u):
            return u
    return pre + _rand(8)


def _username_dipakai(u):
    x = db()
    r = x.execute("SELECT 1 FROM pesanan WHERE akun=?", (u,)).fetchone()
    x.close()
    if r:
        return True
    try:
        with open("/etc/passwd") as f:
            if re.search(r"^%s:" % re.escape(u), f.read(), re.M):
                return True
    except Exception:
        pass
    return False


def buat_akun(tipe, user, hari, quota="0", iplimit="0", password=None):
    """Bikin akun pakai script panel. Return (ok, output)."""
    hari = str(int(hari))
    quota = str(quota or "0")
    iplimit = str(iplimit or "0")
    pw = password or _rand(8)

    if tipe in ("ssh", "ovpn"):
        # addssh: Username, Password, Limit IP, Limit Quota, Expired (Days)
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" "%s" "%s" | addssh' % (user, pw, iplimit, quota, hari)
    elif tipe == "vmess":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" "%s" | addws' % (user, hari, quota, iplimit)
    elif tipe == "vless":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" "%s" | addvless' % (user, hari, quota, iplimit)
    elif tipe == "trojan":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" "%s" | addtr' % (user, hari, quota, iplimit)
    elif tipe == "ss":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" | addss' % (user, hari, quota)
    elif tipe == "l2tp":
        cmd = 'printf "%%s\\n" "%s" "%s" "%s" | add-l2tp' % (user, pw, hari)
    else:
        return False, "Tipe tidak dikenal: %s" % tipe

    try:
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT,
                                      timeout=120).decode("utf-8", "ignore")
        return True, out
    except subprocess.CalledProcessError as e:
        return False, (e.output or b"").decode("utf-8", "ignore")
    except Exception as e:
        return False, str(e)


def _hapus_akun(tipe, user):
    if not user:
        return
    if tipe in ("ssh", "ovpn"):
        cmd = 'printf "%%s\\n" "%s" | delssh' % user
    elif tipe == "vmess":
        cmd = 'printf "%%s\\n" "%s" | delws' % user
    elif tipe == "vless":
        cmd = 'printf "%%s\\n" "%s" | delvless' % user
    elif tipe == "trojan":
        cmd = 'printf "%%s\\n" "%s" | deltr' % user
    elif tipe == "ss":
        cmd = 'printf "%%s\\n" "%s" | delss' % user
    elif tipe == "l2tp":
        cmd = 'printf "%%s\\n" "%s" | del-l2tp' % user
    else:
        return
    try:
        subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=60)
    except Exception:
        pass


def ambil_link(out):
    """Ambil link akun dari output script panel."""
    links = []
    for proto in ("vmess", "vless", "trojan", "ss"):
        for m in re.finditer(r"(?<![A-Za-z0-9])" + proto + r"://[^\s`'\"]+", out or ""):
            links.append(m.group(0).strip())
    # hilangkan duplikat, jaga urutan
    seen, res = set(), []
    for l in links:
        if l not in seen:
            seen.add(l)
            res.append(l)
    return res


def detail_ssh(user, pw):
    dom = cfg("DOMAIN", "")
    return (
        "Username      : %s\n"
        "Password      : %s\n"
        "Host          : %s\n"
        "Port OpenSSH  : 443, 80, 22\n"
        "Port Dropbear : 443, 109\n"
        "Port SSH WS   : 80, 8080, 8081-9999\n"
        "Port SSL/TLS  : 222-1000\n"
        "OVPN TCP      : 443, 1194\n"
        "OVPN UDP      : 2200\n"
        "OVPN WS SSL   : https://%s:81/ws-ssl.ovpn\n"
        "OVPN SSL      : https://%s:81/ssl.ovpn\n"
        "OVPN TCP File : https://%s:81/tcp.ovpn\n"
        "OVPN UDP File : https://%s:81/udp.ovpn\n"
        "Save Link     : https://%s:81/ssh-%s.txt"
    ) % (user, pw, dom, dom, dom, dom, dom, dom, user)


def detail_l2tp(user, pw):
    dom = cfg("DOMAIN", "")
    psk = ""
    try:
        with open("/etc/l2tp/psk") as f:
            psk = f.read().strip()
    except Exception:
        pass
    return ("Username   : %s\n"
            "Password   : %s\n"
            "Server     : %s\n"
            "PSK/IPSec  : %s\n"
            "Port       : 500, 4500, 1701 (UDP)") % (user, pw, dom, psk or "-")
