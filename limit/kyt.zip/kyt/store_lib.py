# -*- coding: utf-8 -*-
# ============================================================
#  store_lib.py - inti "VPN STORE" untuk bot Telegram
#  (database, saldo, produk, pesanan, Duitku, pembuat akun)
# ============================================================
import os
import re
import json
import time
import base64
import random
import string
import sqlite3

import logging
import signal
import subprocess
import threading
import datetime as DT
from urllib.parse import quote as _urlquote
from urllib.parse import unquote as _urlunquote

import requests

import kyt

DB_PATH = "kyt/database.db"

TIPE_LABEL = {
    "ssh": "SSH / OVPN",
    "ovpn": "OpenVPN (via akun SSH)",
    "vmess": "VMess",
    "vless": "VLESS",
    "trojan": "Trojan",
    "ss": "Shadowsocks",
    "l2tp": "L2TP / IKEv2",
}

# ---- masa aktif: SERAGAM 3 / 7 / 30 hari untuk semua tipe ----
HARI_PILIHAN = [3, 7, 30]
HARGA_DEFAULT = {3: 5000, 7: 10000, 30: 25000}
# tipe produk yang benar-benar dijual di store
TIPE_JUAL = ["ssh", "vmess", "vless", "trojan", "ss", "l2tp"]

# Script panel: apakah "renew" MENAMBAH sisa hari (True) atau
# menghitung ulang dari hari ini (False)?
RENEW_TAMBAH = {"vmess": True, "vless": True, "trojan": True, "ss": True,
                "ssh": False, "ovpn": False, "l2tp": False}

TAG_XRAY = {"vmess": "###", "vless": "#&", "trojan": "#!", "ss": "#!#"}

# ---- lokasi berkas sistem (dibuat konstanta supaya mudah diuji/diubah) ----
XRAY_CFG = "/etc/xray/config.json"
PASSWD_FILE = "/etc/passwd"
L2TP_DB = "/etc/l2tp/.l2tp.db"
L2TP_CHAP = "/etc/ppp/chap-secrets"
L2TP_IPSEC = "/etc/ipsec.secrets"
L2TP_WWW = "/var/www/html"


# ---------------- util ----------------
def _bersih(v):
    """Buang tanda kutip/spasi sisa dari penulisan var.txt."""
    return str(v).strip().strip('"').strip("'").strip()


def _domain_panel():
    """Ambil domain panel dari beberapa sumber (aman bila satu kosong)."""
    for p in ("/etc/xray/domain", "/etc/v2ray/domain", "/root/domain"):
        try:
            with open(p) as f:
                v = f.read().strip().split()
            if v:
                return v[0]
        except Exception:
            continue
    return ""


def cfg(name, default=""):
    """Ambil variabel dari var.txt; DOMAIN punya fallback ke berkas panel."""
    v = getattr(kyt, name, None)
    if v is not None and str(v).strip() != "":
        return _bersih(v)
    if name == "DOMAIN":
        d = _domain_panel()
        if d:
            return d
    return default


def admin_id():
    """ID Telegram admin (angka saja)."""
    return _bersih(cfg("ADMIN", ""))


def rupiah(n):
    try:
        n = int(n)
    except Exception:
        n = 0
    return "Rp " + format(n, ",d").replace(",", ".")


# ---------------- gambar /start ----------------
def gambar_start():
    """Gambar untuk /start: path lokal (hasil olahan) atau URL.
    Kosong = kirim teks saja."""
    v = (get_setting("start_image", "") or cfg("START_IMAGE", "") or "").strip()
    if not v:
        return ""
    if v.startswith("http://") or v.startswith("https://"):
        return v
    for kandidat in (v, os.path.join("kyt", v), os.path.join("/usr/bin/kyt", v)):
        try:
            if os.path.isfile(kandidat):
                return kandidat
        except Exception:
            continue
    return ""


# ---------------- gambar /start: unduh + rapikan rasio ----------------
LEBAR_START = 1280
TINGGI_START = 720


def _path_start_jpg():
    """Lokasi file gambar /start hasil olahan."""
    try:
        folder = os.path.dirname(os.path.abspath(DB_PATH))
    except Exception:
        folder = "/usr/bin/kyt"
    return os.path.join(folder, "start.jpg")


def _ambil_bytes(sumber, timeout=25):
    """Ambil isi gambar dari URL / path lokal. Return bytes atau None."""
    s = (sumber or "").strip()
    if not s:
        return None
    if s.startswith(("http://", "https://")):
        try:
            r = requests.get(s, timeout=timeout, stream=True,
                             headers={"User-Agent": "Mozilla/5.0"})
            if r.status_code == 200 and r.content and len(r.content) > 200:
                return r.content
        except Exception as e:
            logging.error("unduh gambar start gagal: %s", e)
        return None
    for p in (s, os.path.join("kyt", s), os.path.join("/usr/bin/kyt", s)):
        try:
            if os.path.isfile(p):
                with open(p, "rb") as f:
                    return f.read()
        except Exception:
            continue
    return None


def _rapikan_rasio(data, lebar=LEBAR_START, tinggi=TINGGI_START):
    """Rapikan gambar /start supaya "pas" dan tidak aneh.

    Aturan:
      - Isi gambar TIDAK PERNAH dipotong.
      - Rasio target menyesuaikan bentuk gambar:
          * gambar lebar  -> 16:9  (1280x720)
          * gambar kotak  -> 1:1   (1080x1080)
          * gambar tegak  -> 4:5   (1080x1350)
        Jadi sisa ruang (bar) sekecil mungkin.
      - Sisa ruang diisi latar blur dari gambar itu sendiri.
    Return bytes JPEG, atau None kalau Pillow tidak tersedia / gagal.
    """
    try:
        from PIL import Image, ImageFilter
    except Exception:
        return None
    try:
        import io as _io
        im = Image.open(_io.BytesIO(data)).convert("RGB")
        w, h = im.size
        if w < 1 or h < 1:
            return None
        rasio = w / float(h)

        # pilih kanvas sesuai bentuk gambar (biar bar minimal)
        if rasio >= 1.15:
            lebar, tinggi = 1280, 720          # 16:9
        elif rasio >= 0.85:
            lebar, tinggi = 1080, 1080         # 1:1
        else:
            lebar, tinggi = 1080, 1350         # 4:5

        # kalau rasio gambar hampir sama dengan kanvas -> cukup di-resize
        if abs(rasio - (lebar / float(tinggi))) < 0.06:
            skala = min(lebar / float(w), tinggi / float(h))
            fw, fh = max(1, int(w * skala)), max(1, int(h * skala))
            kanvas = Image.new("RGB", (lebar, tinggi), (12, 16, 24))
            kanvas.paste(im.resize((fw, fh), Image.LANCZOS),
                         ((lebar - fw) // 2, (tinggi - fh) // 2))
            out = _io.BytesIO()
            kanvas.save(out, format="JPEG", quality=88, optimize=True)
            return out.getvalue(), lebar, tinggi

        # latar: penuhi kanvas lalu blur + gelapkan
        skala = max(lebar / float(w), tinggi / float(h))
        bw, bh = max(1, int(w * skala)), max(1, int(h * skala))
        latar = im.resize((bw, bh), Image.LANCZOS)
        kiri = max(0, (bw - lebar) // 2)
        atas = max(0, (bh - tinggi) // 2)
        latar = latar.crop((kiri, atas, kiri + lebar, atas + tinggi))
        latar = latar.filter(ImageFilter.GaussianBlur(30))
        latar = Image.eval(latar, lambda v: int(v * 0.45))

        # gambar utama: muat penuh (tidak dipotong)
        skala2 = min(lebar / float(w), tinggi / float(h))
        fw, fh = max(1, int(w * skala2)), max(1, int(h * skala2))
        depan = im.resize((fw, fh), Image.LANCZOS)
        latar.paste(depan, ((lebar - fw) // 2, (tinggi - fh) // 2))

        out = _io.BytesIO()
        latar.save(out, format="JPEG", quality=88, optimize=True)
        return out.getvalue(), lebar, tinggi
    except Exception as e:
        logging.error("rapikan rasio gambar gagal: %s", e)
        return None


def simpan_gambar_start(sumber):
    """Simpan gambar /start: unduh (kalau URL) + rapikan rasio 16:9.

    Return (ok, pesan, nilai_disimpan).
    Kalau gagal olah tapi URL valid, URL tetap disimpan (cadangan).
    """
    s = (sumber or "").strip()
    if not s:
        return False, "Tidak ada gambar.", ""
    data = _ambil_bytes(s)
    if not data:
        if s.startswith(("http://", "https://")):
            set_setting("start_image", s)
            return True, ("Link disimpan, tapi gambarnya belum bisa diunduh "
                          "sekarang. Pastikan itu **direct link** "
                          "(berakhiran .jpg/.png)."), s
        return False, "File gambar tidak ditemukan.", ""

    hasil = _rapikan_rasio(data)
    rapi = hasil[0] if hasil else None
    path = _path_start_jpg()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            f.write(rapi if rapi else data)
    except Exception as e:
        return False, "Gagal menyimpan gambar: %s" % e, ""

    set_setting("start_image", path)
    if hasil:
        _b, w, h = hasil
        rasio = "16:9" if w / float(h) > 1.5 else ("1:1" if w == h else "4:5")
        return True, ("Gambar disimpan & dirapikan ke %s (%dx%d). "
                      "Isi gambar tidak dipotong." % (rasio, w, h)), path
    return True, ("Gambar disimpan. (Pillow belum terpasang, rasio belum "
                  "dirapikan otomatis)"), path


def now():
    return DT.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------- database ----------------
def db():
    x = sqlite3.connect(DB_PATH, timeout=20)
    x.row_factory = sqlite3.Row
    return x


def init_store():
    x = db()
    c = x.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS store_user(
        user_id TEXT PRIMARY KEY,
        username TEXT,
        nama TEXT,
        saldo INTEGER DEFAULT 0,
        created TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS produk(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kode TEXT UNIQUE,
        nama TEXT,
        tipe TEXT,
        harga INTEGER,
        hari INTEGER,
        quota TEXT DEFAULT '0',
        iplimit TEXT DEFAULT '0',
        aktif INTEGER DEFAULT 1)""")
    c.execute("""CREATE TABLE IF NOT EXISTS deposit(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT UNIQUE,
        user_id TEXT,
        amount INTEGER,
        status TEXT DEFAULT 'PENDING',
        method TEXT,
        method_name TEXT,
        reference TEXT,
        pay_url TEXT,
        va TEXT,
        qr TEXT,
        created TEXT,
        paid_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS pesanan(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id TEXT UNIQUE,
        user_id TEXT,
        produk_kode TEXT,
        nama_produk TEXT,
        tipe TEXT,
        harga INTEGER,
        akun TEXT,
        password TEXT,
        detail TEXT,
        status TEXT DEFAULT 'AKTIF',
        created TEXT,
        expired TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS settings(
        k TEXT PRIMARY KEY,
        v TEXT)""")
    x.commit()
    _migrasi(x)
    _seed_produk(c)
    x.commit()
    x.close()


def _kolom(c, tabel):
    try:
        return [r[1] for r in c.execute("PRAGMA table_info(%s)" % tabel).fetchall()]
    except Exception:
        return []


def _migrasi(x):
    """Tambah kolom baru tanpa menghapus data lama."""
    c = x.cursor()
    kol = _kolom(c, "pesanan")
    for nama, tipe in (("exp_iso", "TEXT"), ("notif", "TEXT DEFAULT ''"),
                       ("hari", "INTEGER DEFAULT 0"), ("renew_at", "TEXT")):
        if nama not in kol:
            try:
                c.execute("ALTER TABLE pesanan ADD COLUMN %s %s" % (nama, tipe))
            except Exception:
                pass
    # kolom id pesan QR/tagihan pada tabel deposit
    kold = _kolom(c, "deposit")
    for nama in ("chat_id", "msg_id", "proses_id"):
        if nama not in kold:
            try:
                c.execute("ALTER TABLE deposit ADD COLUMN %s TEXT" % nama)
            except Exception:
                pass
    # isi exp_iso dari kolom 'expired' lama (format "20 Okt 2026")
    try:
        for r in c.execute("SELECT id, expired FROM pesanan"
                           " WHERE (exp_iso IS NULL OR exp_iso='') AND expired IS NOT NULL").fetchall():
            d = _parse_tgl_tampil(r[1])
            if d:
                c.execute("UPDATE pesanan SET exp_iso=? WHERE id=?", (d, r[0]))
    except Exception:
        pass
    x.commit()


def _parse_tgl_tampil(s):
    """'20 Okt 2026' -> '2026-10-20' (coba beberapa format)."""
    s = (s or "").strip()
    if not s:
        return None
    for f in ("%d %b %Y", "%d %B %Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return DT.datetime.strptime(s, f).strftime("%Y-%m-%d")
        except Exception:
            continue
    return None


def _seed_produk(c):
    """Semua tipe x masa aktif 3/7/30 hari (seragam)."""
    ada = set()
    try:
        ada = {r[0] for r in c.execute("SELECT kode FROM produk").fetchall()}
    except Exception:
        pass
    for tipe in TIPE_JUAL:
        label = TIPE_LABEL.get(tipe, tipe).replace(" / ", "/")
        for h in HARI_PILIHAN:
            kode = "%s-%d" % (tipe, h)
            if kode in ada:
                continue
            c.execute(
                "INSERT OR IGNORE INTO produk(kode,nama,tipe,harga,hari,quota,iplimit,aktif)"
                " VALUES(?,?,?,?,?,?,?,1)",
                (kode, "%s %d Hari" % (label, h), tipe,
                 HARGA_DEFAULT.get(h, 10000), h, "0", "0"))
    # bersihkan produk lama yang tidak dipakai skema baru (mis. 'tr-30')
    kode_baru = {"%s-%d" % (t, h) for t in TIPE_JUAL for h in HARI_PILIHAN}
    for r in c.execute("SELECT kode FROM produk").fetchall():
        k = r[0]
        if k in kode_baru:
            continue
        dipakai = c.execute("SELECT COUNT(*) FROM pesanan WHERE produk_kode=?", (k,)).fetchone()[0]
        if dipakai:
            c.execute("UPDATE produk SET aktif=0 WHERE kode=?", (k,))
        else:
            c.execute("DELETE FROM produk WHERE kode=?", (k,))


# ---------------- settings ----------------
def set_setting(k, v):
    x = db()
    x.execute("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
              (k, str(v)))
    x.commit()
    x.close()


def get_setting(k, default=""):
    try:
        x = db()
        r = x.execute("SELECT v FROM settings WHERE k=?", (k,)).fetchone()
        x.close()
        if r and r["v"] is not None and str(r["v"]) != "":
            return str(r["v"])
    except Exception:
        pass
    return default


# ---------------- user / saldo ----------------
def get_user(user_id):
    x = db()
    r = x.execute("SELECT * FROM store_user WHERE user_id=?", (str(user_id),)).fetchone()
    x.close()
    return r


def get_or_create_user(user_id, username="", nama=""):
    r = get_user(user_id)
    if r:
        return r
    x = db()
    x.execute("INSERT OR IGNORE INTO store_user(user_id,username,nama,saldo,created)"
              " VALUES(?,?,?,0,?)", (str(user_id), username or "", nama or "", now()))
    x.commit()
    x.close()
    return get_user(user_id)


def saldo_tambah(user_id, jumlah):
    x = db()
    x.execute("UPDATE store_user SET saldo = saldo + ? WHERE user_id=?", (int(jumlah), str(user_id)))
    x.commit()
    x.close()


def saldo_kurang(user_id, jumlah):
    """True kalau saldo cukup & berhasil dipotong."""
    x = db()
    c = x.cursor()
    c.execute("UPDATE store_user SET saldo = saldo - ? WHERE user_id=? AND saldo >= ?",
              (int(jumlah), str(user_id), int(jumlah)))
    ok = c.rowcount > 0
    x.commit()
    x.close()
    return ok


# ---------------- produk ----------------
def produk_by_tipe(tipe, hanya_aktif=True):
    x = db()
    q = "SELECT * FROM produk WHERE tipe=?"
    if hanya_aktif:
        q += " AND aktif=1"
    q += " ORDER BY hari ASC, harga ASC"
    r = x.execute(q, (tipe,)).fetchall()
    x.close()
    return r


def produk_by_tipe_hari(tipe, hari):
    x = db()
    r = x.execute("SELECT * FROM produk WHERE tipe=? AND hari=? AND aktif=1"
                  " ORDER BY harga ASC LIMIT 1", (tipe, int(hari))).fetchone()
    x.close()
    return r


def produk_by_hari(hari, hanya_aktif=True):
    """Semua produk dengan masa aktif tertentu (semua tipe)."""
    x = db()
    q = "SELECT * FROM produk WHERE hari=?"
    if hanya_aktif:
        q += " AND aktif=1"
    r = x.execute(q + " ORDER BY tipe ASC", (int(hari),)).fetchall()
    x.close()
    return r


def set_harga_hari(hari, harga):
    """Set harga SEMUA tipe untuk masa aktif tertentu. Return jumlah paket."""
    x = db()
    c = x.cursor()
    c.execute("UPDATE produk SET harga=? WHERE hari=?", (int(harga), int(hari)))
    n = c.rowcount
    x.commit()
    x.close()
    return n


def ringkas_harga():
    """Ringkasan harga per masa aktif: [(hari, harga_min, harga_max, jumlah)]."""
    x = db()
    r = x.execute("SELECT hari, MIN(harga) a, MAX(harga) b, COUNT(*) n FROM produk"
                  " WHERE aktif=1 GROUP BY hari ORDER BY hari ASC").fetchall()
    x.close()
    return r


def set_harga_tipe_hari(tipe, hari, harga):
    x = db()
    c = x.cursor()
    c.execute("UPDATE produk SET harga=? WHERE tipe=? AND hari=?",
              (int(harga), tipe, int(hari)))
    n = c.rowcount
    x.commit()
    x.close()
    return n


# ---------------- nominal deposit ----------------
def depo_min():
    try:
        return max(100, int(get_setting("depo_min", "1000") or 1000))
    except Exception:
        return 1000


def depo_nominal():
    """Daftar tombol nominal deposit (bisa diatur admin)."""
    raw = str(get_setting("depo_nominal", "1000,2000,5000,10000,20000,50000") or "")
    out = []
    for x in raw.replace(" ", ",").split(","):
        x = x.strip().replace(".", "")
        if x.isdigit() and int(x) > 0:
            v = int(x)
            if v not in out:
                out.append(v)
    if not out:
        out = [1000, 2000, 5000, 10000, 20000, 50000]
    return sorted(out)


def produk_semua():
    x = db()
    urut = " ".join("WHEN '%s' THEN %d" % (t, i) for i, t in enumerate(
        ["ssh", "ovpn", "vmess", "vless", "trojan", "ss", "l2tp"]))
    r = x.execute("SELECT * FROM produk ORDER BY CASE tipe %s ELSE 99 END,"
                  " hari ASC, harga ASC" % urut).fetchall()
    x.close()
    return r


def produk_by_kode(kode):
    x = db()
    r = x.execute("SELECT * FROM produk WHERE kode=?", (kode,)).fetchone()
    x.close()
    return r


def produk_tipe_tersedia():
    x = db()
    r = x.execute("SELECT DISTINCT tipe FROM produk WHERE aktif=1").fetchall()
    x.close()
    urut = ["ssh", "ovpn", "vmess", "vless", "trojan", "ss", "l2tp"]
    ada = [v["tipe"] for v in r]
    return [t for t in urut if t in ada]


# ============================================================
# GoPay Merchant (GoMerch) Payment Gateway
# - QRIS dinamis dibuat lokal dari QR statis merchant
# - Cek pembayaran via /api/history (journal GoBiz)
# - Token di-refresh otomatis via refresh_token
# - Anti rate-limit: cache history 10 detik, refresh cooldown 5 menit
# ============================================================

import threading as _threading

_GM_LOCK = _threading.Lock()
_GM_TOKEN_CACHE = {}          # {"token": ..., "refresh_token": ...}
_GM_TOKEN_LOADED = False
_GM_LAST_REFRESH = 0.0
_GM_RATE_LIMIT_UNTIL = 0.0
_GM_HISTORY_CACHE = None       # (timestamp, data)

_GM_REFRESH_COOLDOWN = 5 * 60   # 5 menit
_GM_HISTORY_TTL = 10            # cache history 10 detik
_GM_RATELIMIT_BACKOFF = 16 * 60 # 16 menit setelah kena 429

_GM_TOKEN_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "gomerch_token.json"
)

# ---- default values (dari config GoPay Merchant) ----
_GM_DEFAULT_BASE_URL    = "http://pgku.stunnelv4.biz.id"
_GM_DEFAULT_STATIC_QR  = (
    "00020101021126610014COM.GO-JEK.WWW01189360091435721787750210"
    "G5721787750303UMI51440014ID.CO.QRIS.WWW0215ID10266233270650303"
    "UMI5204899953033605802ID5918VICTOR ADI TJANDRA6011PROBOLINGGO"
    "61056722962070703A016304A51A"
)
_GM_DEFAULT_TOKEN       = (
    "eyJhbGciOiJkaXIiLCJjdHkiOiJKV1QiLCJlbmMiOiJBMTI4R0NNIiwidHlwIjoiSldUIiwiemlwIjoiREVGIn0"
    "..7xi_3WHxey6FBxag.C-ROHJcVbdUsd1K9GCStqA7z-q9xgC8Ieewse0d_-NtS7eOM8XrVbbQfELFtuTQMPt6"
    "QAJBdcfrHPmV7x5fSPtbR_xOBWhpiVBI3eCF_JsLJ9kuPsBQsyxvbcVswifVBaObBWcUb2uWQ4gBW_KHa-IVu0"
    "FACdJ-5Om16q2WAaTCLyBFtK-JvU9j2CVEBrXYi4O0mCpAbZkJmsmf2VteFdZrRM_4u5HXzEevxKEOe_3SJRgx"
    "hEob61-k7QBAafzk5YfvkYHidlk0Y84wuqrzfNs-1-Zb7lpsmu3S6GWOQV8xWZuw9b0860CkLYMpyfVFmFSsPZ"
    "uy1uhzuP0JAOsZ5nIWsf37p7jd0ZfpIlosSnCisxeO-hvSpmYDOH3A2gKPlpO5GiD5Sa8FGfE9SigvN2PBwdE0"
    "cowLgLSTwM5iSCWp1jJ6xm139iCWYDyMXbOH2M8LFBbwx7MCZDS7V3izmHfMM7RQPt9Ys_-PVplTLABsVav9ia"
    "kH2J0Q1r_wHMGmU8iPd7er51d1LZa00iRSTSTJKO2BaU0PHFf8z-Fm7M2njX2RCEltICGkXlZkAHrlNEwDQ4sR"
    "8JM9pAe2kSFvyWYHWzXpH3ilkUEOgVU3_GCw-LCWBMSevZZQYPZbMwXNI8vWyhRk4bK9juxmtmnEgGDqnpe5wJ"
    "x-t7yl6_zmUTsVcpAAV3PY8d8DbhlUPa9S5qja51hPCnGIUEdi1sUu2XTIMGZscXNgEiDS4-27tKIbku9ByRXtR"
    "dANG3afhNr0H0NbptmCNfWKmWtyY4k0q1B2tu8nc6TV_czdyAlf1qunvAsrIOkF56VyZevnu_JvPYr6bqVuOA_C"
    "1hmnN0YAPGGABQ85414XuA5W9GkwOvUj5a1uG4AsfeUW4cmek2OSVKu4XVFR53qElejspQYJT0A7Nf_-qQcRTIG"
    "cZDMe8Yjh2jfs0hi206Fza6IjLcv0pxKIFfnCFj4XK2MD216SwSII6SaR2S_VgUn1yddVSESVE0In7w5VyySJ95"
    "TgJiizZQDlq2XFcfOr2ttkLvNQc8oPWStoVZCx1lI4kbkPCo1wQOHwELe1iYXn1Oe44BKtUfnf9T4GlTnh-hSM"
    "095x4yndc_ixFhBDjJR0YMSV25M8bPocgBg5GJ35lcIRBaR45sdMXRb_xuOShiLeCAo7fXRIBZhn_nDPfD-7VSrW"
    "Nf5vSQznVZFKIMrHNSHe2ubWgizxL5R3wYWs8Kj0PkgyjPM7_BLFZ9aqA9vH9ZtAnku1Qvj0Kalkk9rg9D7fUoh"
    "F19KGcESZ3qg8BwAbpNRCRaeAoHKvUvavNcpn2VPCeNb9fujeEjn_leCTLNrmtCw6NBJ4QyCKMDNnBvCEsoawmJK"
    "Jph3TR8ttvNYf41sAk7v4FNpc_epWXd0Q9ozOaq9TzhZv6EDY-0-GpBpI1m2jmSCSp8D7LuVG9m7lrXsuTHtXwJ"
    "-yWZcxM0z1NopLN6FC9nNh-eC-85ridrQsQ1iOkvWLobzsjVTxAtJVtNUF2T9uj-zZdTUMBuvDTrCi61qAbVbPBd"
    "XUg7cJPHs8GICVnXYJe02GU-HEaK-UUUJB_oRvBU4jAoI_pN78JXf349U9mo_5yBouNA_eYZGPy2_vtaeutk0W0"
    "mBwpRCyc7STDPoEJLuoiJhSqa2KFnaeTqK1Kw0fR03OzlU3l3_E_3HujG2OocXJW_XTlmqZmNZi8gbxFNIxvrBZ"
    "yK_4XBmz7yeRHy3Vg85pdzvsRX9nDh7gtNhsxYYo_ug8eucwKjmCtXurANp9xsDYuBJIcxM2iFvLj0-CB2NAjZm7"
    "Czal58SiKPaVJf5dE0us0_AjNG2RI-OnGILpqcX8Rk1ldjVGPuub4vrLwL5RYqFC6KGUxp390lTDV9NgWlZ3z1QC"
    "ylIiGb34FNNMQ9WrM9uW-cR9EsvtRP0fyflwnznuOfE2Yr0OFT4c5jpdfAikNYImD9kzqXHYkbCzHCnTC7vQKtN1"
    "-PuyzN8igD8u2zMy0oE-4E33WU0pkA1BAvULHF4Kx799gR6tFEg58B1BaSJzJW6Mfy9KFST4rrdCfX10AnklzhrW"
    "MOIzLlnq4BIC-kKRy6epIyG57uNyYfhRYBIH_bYVkZ2T-i0INsVXwq8caPAayJcWytCyvrI8edETBljJCu1ZjLcb"
    "crbbbjkC9oRcx-U_V2yff1nDNdDqjAWFhcMgjpKx1lcgNNP759zsFLvvGCZAsSb5.q6MTvEOY1yncCE6O4U4ViQ"
)
_GM_DEFAULT_REFRESH_TOKEN = (
    "eyJhbGciOiJkaXIiLCJjdHkiOiJKV1QiLCJlbmMiOiJBMTI4R0NNIiwidHlwIjoiSldUIiwiemlwIjoiREVGIn0"
    "..HGkVWQM8-eZjR1HN.CTvhtuT3xWAphPQNIbVrscfysr-OpfYbS-Krs8Qw_CAePtmFDeVkBw-Mb5rDsozu0UXA"
    "loYPkLbIhroUlTgmtJBFYbFLjw1o3JIiODgJ5PJwuIQYqZz7ilrd3Q7LbUdVEKU5yjggxi7JdbiOusasLIGWLoN"
    "K979S86rw-_qSYXUsI5vrAWD9vARXA9IoQn_kcGtLQH4nUBOHbn4Wc5QAw9ycevTcG_lJfUkzZ3i1_5tTwt2LIT"
    "iz7AveX2NO-i89birXsKhJ87P3NRX5jxcTqpIcP7n9BsG7CoUp6QApsqIQE6Y3OrFsvGdPPWcJVbp-iKKfNR_6o"
    "17MX3Pm-TSsF-gq6TgecLBTmnjC6nyvtJrqyERkMbCNfVAvNV8f4l76yRxyo7xupu1iSbg0HGqd_p7taDL-Mn1r"
    "ChkmsDXrbGkHe_65O-jCCkuLLL0tLjmCjibhfkVDvzVLfsRLA_sbxf9D1kJplLUpSwZsIKh0fArvNFWHzy22y92A"
    "-XNktuSzcZ5_m0feG6oSy8ONyHbKWqigz7m-mO9QdawARZbzhDaMI1eEayxFHIhgT-tmXDxzli3C0nbVNP2vSJUu"
    "hXQRSJJFFJcZG0fyUp7URSMJDavTDlz1.9Mi6RyemRDIRuOs0EmNmMg"
)
_GM_DEFAULT_PHONE = "6281246238773"

# ---- config helpers ----

def gm_base():
    return (get_setting("gomerch_base_url", cfg("GOMERCH_BASE_URL", "")) or
            _GM_DEFAULT_BASE_URL).rstrip("/")


def gm_static_qr():
    return (get_setting("gomerch_static_qr", cfg("GOMERCH_STATIC_QR", "")) or
            _GM_DEFAULT_STATIC_QR).strip()


def gm_phone():
    return (get_setting("gomerch_phone", cfg("GOMERCH_PHONE", "")) or
            _GM_DEFAULT_PHONE).strip()


def dk_ready():
    """Cek apakah GoPay Merchant sudah dikonfigurasi (butuh QR statis)."""
    return bool(gm_static_qr())


def dk_method_name():
    return "QRIS GoPay"


def dk_expiry():
    """Masa berlaku tagihan QRIS (menit), default 10."""
    try:
        v = int(get_setting("expiry_period", "10") or 10)
    except Exception:
        v = 10
    return max(1, min(60, v))


# ---- token management ----

def _gm_load_token():
    global _GM_TOKEN_CACHE, _GM_TOKEN_LOADED
    if _GM_TOKEN_LOADED:
        return
    with _GM_LOCK:
        if _GM_TOKEN_LOADED:
            return
        data = {}
        # 1) baca dari file runtime
        try:
            with open(_GM_TOKEN_FILE, "r") as f:
                data = json.load(f) or {}
        except Exception:
            pass
        # 2) fallback ke setting DB / var.txt
        if not data.get("token"):
            data["token"] = (get_setting("gomerch_token",
                                         cfg("GOMERCH_TOKEN", "")) or "").strip()
        if not data.get("refresh_token"):
            data["refresh_token"] = (get_setting("gomerch_refresh_token",
                                                  cfg("GOMERCH_REFRESH_TOKEN", "")) or "").strip()
        # 3) fallback ke default hardcoded (dari config.js)
        if not data.get("token"):
            data["token"] = _GM_DEFAULT_TOKEN
        if not data.get("refresh_token"):
            data["refresh_token"] = _GM_DEFAULT_REFRESH_TOKEN
        _GM_TOKEN_CACHE = data
        _GM_TOKEN_LOADED = True


def _gm_get_token():
    _gm_load_token()
    return _GM_TOKEN_CACHE.get("token", "")


def _gm_save_token(token, refresh_token=None):
    global _GM_TOKEN_CACHE
    with _GM_LOCK:
        _GM_TOKEN_CACHE["token"] = token
        if refresh_token:
            _GM_TOKEN_CACHE["refresh_token"] = refresh_token
        try:
            tmp = _GM_TOKEN_FILE + ".tmp"
            with open(tmp, "w") as f:
                json.dump(_GM_TOKEN_CACHE, f, indent=2)
            os.replace(tmp, _GM_TOKEN_FILE)
        except Exception as e:
            logging.error("[GoPay] gagal simpan token file: %s", e)
    # Simpan juga ke database settings agar persisten
    try:
        set_setting("gomerch_token", token)
        if refresh_token:
            set_setting("gomerch_refresh_token", refresh_token)
    except Exception:
        pass


def _gm_refresh_token():
    global _GM_LAST_REFRESH
    now = time.time()
    if now - _GM_LAST_REFRESH < _GM_REFRESH_COOLDOWN:
        return None
    _gm_load_token()
    rf = _GM_TOKEN_CACHE.get("refresh_token", "")
    if not rf:
        return None
    try:
        r = requests.get(
            gm_base() + "/auth/refresh/token",
            params={"refresh_token": rf},
            timeout=20,
        )
        data = r.json()
    except Exception as e:
        logging.warning("[GoPay] refresh token gagal: %s", e)
        return None
    if not data.get("success"):
        logging.warning("[GoPay] refresh token ditolak: %s", data)
        return None
    d = data.get("data", {})
    new_token = d.get("access_token") or d.get("token")
    new_rf = d.get("refresh_token")
    if new_token:
        _gm_save_token(new_token, new_rf)
        _GM_LAST_REFRESH = time.time()
        return new_token
    return None


def _gm_is_rate_limited():
    return time.time() < _GM_RATE_LIMIT_UNTIL


def _gm_set_rate_limited():
    global _GM_RATE_LIMIT_UNTIL
    _GM_RATE_LIMIT_UNTIL = time.time() + _GM_RATELIMIT_BACKOFF
    logging.warning("[GoPay] rate limit, jeda 16 menit")


# ---- QRIS builder ----

def _crc16(data: str) -> str:
    crc = 0xFFFF
    for ch in data:
        crc ^= ord(ch) << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return "%04X" % (crc & 0xFFFF)


def gm_build_qris(amount: int) -> str:
    """Buat QRIS dinamis dari QR statis merchant secara lokal."""
    static_qr = gm_static_qr()
    if not static_qr:
        return ""
    # ubah ke mode dinamis (010211 → 010212)
    body = static_qr[:-4].replace("010211", "010212", 1)
    parts = body.split("5802ID")
    amount_str = str(int(amount))
    amount_field = "54" + "%02d" % len(amount_str) + amount_str
    payload = parts[0] + amount_field + "5802ID" + parts[1]
    return payload + _crc16(payload)


# ---- history / payment check ----

def gm_get_history(force=False):
    """Ambil riwayat transaksi GoPay (cache 10 detik)."""
    global _GM_HISTORY_CACHE
    if _gm_is_rate_limited():
        return []
    now = time.time()
    if not force and _GM_HISTORY_CACHE:
        ts, data = _GM_HISTORY_CACHE
        if now - ts < _GM_HISTORY_TTL:
            return data

    token = _gm_get_token()
    if not token:
        return []
    try:
        r = requests.get(gm_base() + "/api/history",
                         params={"token": token}, timeout=20)
    except Exception as e:
        logging.error("[GoPay] history request gagal: %s", e)
        return []

    if r.status_code == 429:
        _gm_set_rate_limited()
        return []
    if r.status_code in (400, 401):
        # token expired → refresh sekali lalu retry
        new_token = _gm_refresh_token()
        if new_token:
            try:
                r = requests.get(gm_base() + "/api/history",
                                 params={"token": new_token}, timeout=20)
            except Exception:
                return []
            if r.status_code == 429:
                _gm_set_rate_limited()
                return []
    try:
        data = r.json()
    except Exception:
        return []
    if not data.get("success"):
        logging.warning("[GoPay] history gagal: %s", data)
        return []
    rows = data.get("data") or []
    _GM_HISTORY_CACHE = (time.time(), rows)
    return rows


def _parse_time(val):
    if not val:
        return 0.0
    if isinstance(val, (int, float)):
        return float(val) if val < 1e11 else float(val) / 1000.0
    s = str(val).strip()
    if "T" in s or s.endswith("Z"):
        try:
            return DT.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()
        except Exception:
            pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return DT.datetime.strptime(s[:19], fmt).astimezone().timestamp()
        except Exception:
            pass
    return 0.0


def gm_check_payment(order_id: str, amount: int) -> bool:
    """Cek apakah tagihan sudah dibayar. Return True kalau lunas.
    Mengikuti pola cekStatusGomerch pada referensi:
    - Verifikasi amount dan status success
    - Verifikasi waktu transaksi >= waktu invoice dibuat (buffer 2 menit)
    - Dedup ID transaksi agar 1 mutasi tidak melunasi 2 invoice
    """
    raw = deposit_by_order(order_id)
    if not raw:
        return False
    dep = dict(raw)

    created_ts = _parse_time(dep.get("created"))
    if not created_ts:
        created_ts = time.time() - 600

    saved_ref = str(dep.get("reference") or "").strip()

    rows = gm_get_history(force=True)
    if not rows:
        return False

    for tx in rows:
        if not isinstance(tx, dict):
            continue

        status = str(tx.get("status") or "").lower()
        if not re.search(r"success|settled|completed", status):
            continue

        try:
            nominal = int(tx.get("amount") or tx.get("nominal") or 0)
        except Exception:
            nominal = 0
        if nominal != int(amount):
            continue

        tx_id = str(tx.get("id") or tx.get("reference_id") or "").strip()
        if not tx_id:
            continue

        # Cek waktu: transaksi harus dibuat setelah invoice dibuat (buffer 2 menit = 120s)
        tx_ts = _parse_time(tx.get("time") or tx.get("date") or tx.get("created_at"))
        if tx_ts and tx_ts < (created_ts - 120):
            continue

        # Jika sudah pernah disimpan di order ini
        if saved_ref and saved_ref == tx_id:
            return True

        # Pastikan belum pernah dipakai order LAIN yang sudah PAID
        x = db()
        dup = x.execute(
            "SELECT order_id FROM deposit WHERE reference=? AND status='PAID' AND order_id!=?",
            (tx_id, order_id)
        ).fetchone()
        x.close()
        if dup:
            continue

        # Match sukses!
        deposit_update(order_id, reference=tx_id)
        logging.info("[GoPay] Order %s LUNAS via TX %s (Rp %d)", order_id, tx_id, nominal)
        return True

    return False


def _err(res):
    """Ambil pesan error yang bisa dibaca."""
    if isinstance(res, dict):
        for k in ("message", "statusMessage", "Message", "_raw"):
            v = res.get(k)
            if v:
                return str(v)
    return "respons tidak dikenal"


def qr_image_url(qrstring, size=600):
    """URL gambar QR (dipakai Telegram untuk kirim foto QRIS)."""
    return ("https://api.qrserver.com/v1/create-qr-code/?size=%dx%d&margin=8&data=%s"
            % (size, size, _urlquote(qrstring or "", safe="")))


def qr_png(qrstring, size=600):
    """Ambil gambar QR (PNG bytes). None kalau gagal."""
    if not qrstring:
        return None
    urls = [
        qr_image_url(qrstring, size),
        "https://quickchart.io/qr?size=%d&text=%s" % (size, _urlquote(qrstring, safe="")),
    ]
    for u in urls:
        try:
            r = requests.get(u, timeout=20)
            if r.status_code == 200 and r.content and len(r.content) > 100:
                return r.content
        except Exception:
            continue
    return None


# ---------------- deposit ----------------
def deposit_baru(order_id, user_id, amount, method, method_name):
    x = db()
    x.execute("INSERT INTO deposit(order_id,user_id,amount,status,method,method_name,created)"
              " VALUES(?,?,?,'PENDING',?,?,?)",
              (order_id, str(user_id), int(amount), method, method_name, now()))
    x.commit()
    x.close()


def deposit_update(order_id, **kw):
    if not kw:
        return
    cols = ", ".join("%s=?" % k for k in kw)
    vals = list(kw.values()) + [order_id]
    x = db()
    x.execute("UPDATE deposit SET %s WHERE order_id=?" % cols, vals)
    x.commit()
    x.close()


def deposit_by_order(order_id):
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE order_id=?", (order_id,)).fetchone()
    x.close()
    return dict(r) if r else None


def deposit_pending(limit=5):
    """Deposit PENDING, yang PALING BARU dulu (yang lama sudah kedaluwarsa)."""
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE status='PENDING'"
                  " ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    x.close()
    return [dict(row) for row in r]


def deposit_pending_tua(menit=30):
    """Deposit PENDING yang dibuat lebih dari `menit` lalu (untuk dibersihkan)."""
    x = db()
    batas = (DT.datetime.now() - DT.timedelta(minutes=int(menit))
             ).strftime("%Y-%m-%d %H:%M:%S")
    r = x.execute("SELECT * FROM deposit WHERE status='PENDING' AND created < ?"
                  " ORDER BY id DESC", (batas,)).fetchall()
    x.close()
    return [dict(row) for row in r]


def deposit_set_pesan(order_id, chat_id=None, msg_id=None, proses_id=None):
    """Simpan id pesan QR/tagihan supaya bisa dihapus setelah dibayar."""
    kw = {}
    if chat_id is not None:
        kw["chat_id"] = str(chat_id)
    if msg_id is not None:
        kw["msg_id"] = str(msg_id)
    if proses_id is not None:
        kw["proses_id"] = str(proses_id)
    if kw:
        deposit_update(order_id, **kw)


def deposit_riwayat(user_id, limit=10):
    x = db()
    r = x.execute("SELECT * FROM deposit WHERE user_id=? ORDER BY id DESC LIMIT ?",
                  (str(user_id), limit)).fetchall()
    x.close()
    return r


# ---------------- pesanan ----------------
def pesanan_baru(order_id, user_id, produk, akun, password, detail, expired, exp_iso=None):
    if not exp_iso:
        exp_iso = _parse_tgl_tampil(expired)
    x = db()
    x.execute("INSERT INTO pesanan(order_id,user_id,produk_kode,nama_produk,tipe,harga,akun,"
              "password,detail,status,created,expired,exp_iso,hari,notif)"
              " VALUES(?,?,?,?,?,?,?,?,?,'AKTIF',?,?,?,?,'')",
              (order_id, str(user_id), produk["kode"], produk["nama"], produk["tipe"],
               int(produk["harga"]), akun, password or "", detail or "", now(), expired,
               exp_iso, int(produk["hari"] or 0)))
    x.commit()
    x.close()


def pesanan_user(user_id, limit=10):
    x = db()
    r = x.execute("SELECT * FROM pesanan WHERE user_id=? ORDER BY id DESC LIMIT ?",
                  (str(user_id), limit)).fetchall()
    x.close()
    return r


def pesanan_semua(limit=20):
    x = db()
    r = x.execute("SELECT * FROM pesanan ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    x.close()
    return r


def pesanan_by_id(pid):
    x = db()
    r = x.execute("SELECT * FROM pesanan WHERE id=?", (pid,)).fetchone()
    x.close()
    return r


def pesanan_hapus(pid):
    p = pesanan_by_id(pid)
    if not p:
        return False
    _hapus_akun(p["tipe"], p["akun"])
    x = db()
    x.execute("DELETE FROM pesanan WHERE id=?", (pid,))
    x.commit()
    x.close()
    return True


# ---------------- hitung akun (sinkron VPS <-> bot) ----------------
# Sumber kebenaran = berkas akun di VPS (bukan database bot),
# supaya angka di panel menu dan di bot SELALU sama.
AKUN_DB = {
    "vmess": "/etc/vmess/.vmess.db",
    "vless": "/etc/vless/.vless.db",
    "trojan": "/etc/trojan/.trojan.db",
    "ss": "/etc/shadowsocks/.shadowsocks.db",
    "l2tp": "/etc/l2tp/.l2tp.db",
}

NAMA_AKUN = {
    "ssh": "SSH/OVPN",
    "vmess": "VMess",
    "vless": "VLESS",
    "trojan": "Trojan",
    "ss": "Shadowsocks",
    "l2tp": "L2TP/IKEv2",
}

URUT_AKUN = ["ssh", "vmess", "vless", "trojan", "ss", "l2tp"]


def _hitung_db(path):
    """Hitung username unik di berkas .db panel (baris berawalan ###)."""
    nama = set()
    try:
        with open(path) as f:
            for l in f:
                if l.startswith("###"):
                    b = l.split()
                    if len(b) >= 2:
                        nama.add(b[1])
    except Exception:
        pass
    return len(nama)


def _hitung_ssh():
    """Hitung akun SSH/OVPN di /etc/passwd (uid >= 1000, shell nologin/false)."""
    n = 0
    coba = (PASSWD_FILE, "/etc/passwd")
    for path in coba:
        try:
            with open(path) as f:
                for l in f:
                    b = l.split(":")
                    if len(b) < 7:
                        continue
                    if b[0] in ("nobody", "root"):
                        continue
                    try:
                        uid = int(b[2])
                    except Exception:
                        continue
                    if uid < 1000:
                        continue
                    shell = b[6].strip()
                    if shell in ("/bin/false", "/sbin/nologin",
                                 "/usr/sbin/nologin", "/bin/nologin"):
                        n += 1
            return n
        except Exception:
            continue
    return n


def hitung_akun_sistem():
    """Jumlah akun per tipe yang BENAR-BENAR ada di VPS.

    SATU sumber kebenaran: _daftar_akun() (passwd / config.json / l2tp db).
    Dulu dihitung dari berkas .db panel, tapi berkas .vless.db, .trojan.db,
    .shadowsocks.db tidak pernah ditulis script panel -> selalu 0 (tidak sinkron).
    """
    h = {t: len(_daftar_akun(t)) for t in URUT_AKUN}
    h["total"] = sum(h[t] for t in URUT_AKUN)
    return h


def hitung_akun_bot():
    """Jumlah akun per tipe menurut database BOT (tabel pesanan)."""
    h = {t: 0 for t in URUT_AKUN}
    try:
        x = db()
        for r in x.execute("SELECT tipe, COUNT(DISTINCT akun) c FROM pesanan"
                           " WHERE akun IS NOT NULL AND akun!='' GROUP BY tipe").fetchall():
            t = r["tipe"]
            if t in h:
                h[t] = int(r["c"])
        x.close()
    except Exception:
        pass
    h["total"] = sum(h[t] for t in URUT_AKUN)
    return h


def rincian_akun():
    """[(tipe, nama, jumlah_di_vps, jumlah_di_bot)] - untuk menu & statistik."""
    v = hitung_akun_sistem()
    b = hitung_akun_bot()
    return [(t, NAMA_AKUN[t], v.get(t, 0), b.get(t, 0)) for t in URUT_AKUN]


def akun_beda():
    """True kalau ada akun yang ada di VPS tapi tidak tercatat di bot (atau sebaliknya)."""
    for _t, _n, v, b in rincian_akun():
        if v != b:
            return True
    return False


# ---------------- masa aktif (expired) ----------------
def exp_date(p):
    """Tanggal expired pesanan -> datetime.date (atau None)."""
    if not p:
        return None
    try:
        iso = p["exp_iso"]
    except Exception:
        iso = None
    if iso:
        try:
            return DT.datetime.strptime(str(iso)[:10], "%Y-%m-%d").date()
        except Exception:
            pass
    try:
        v = _parse_tgl_tampil(p["expired"])
        if v:
            return DT.datetime.strptime(v, "%Y-%m-%d").date()
    except Exception:
        pass
    return None


def sisa_hari(p):
    """Sisa hari menuju expired. Negatif = sudah lewat. None = tak diketahui."""
    d = exp_date(p)
    if not d:
        return None
    return (d - DT.date.today()).days


def exp_tampil(d):
    """date -> '20 Okt 2026'."""
    try:
        return d.strftime("%d %b %Y")
    except Exception:
        return "-"


def status_masa(p):
    """Teks status masa aktif (tanpa emoticon)."""
    s = sisa_hari(p)
    if s is None:
        return "Tidak diketahui"
    if s < 0:
        return "Expired %d hari lalu" % abs(s)
    if s == 0:
        return "Expired hari ini"
    return "Aktif %d hari lagi" % s


def status_singkat(p):
    """Status singkat untuk daftar akun."""
    s = sisa_hari(p)
    if s is None:
        return "?"
    if s < 0:
        return "HABIS"
    if s == 0:
        return "H-0"
    return "AKTIF %dh" % s


def pesanan_update_expired(pid, exp_iso, tambah_hari=None):
    x = db()
    if tambah_hari is None:
        x.execute("UPDATE pesanan SET exp_iso=?, expired=?, notif='', status='AKTIF',"
                  " renew_at=? WHERE id=?",
                  (exp_iso, exp_tampil(DT.datetime.strptime(exp_iso, "%Y-%m-%d").date()),
                   now(), pid))
    else:
        x.execute("UPDATE pesanan SET exp_iso=?, expired=?, notif='', status='AKTIF',"
                  " hari=COALESCE(hari,0)+?, renew_at=? WHERE id=?",
                  (exp_iso, exp_tampil(DT.datetime.strptime(exp_iso, "%Y-%m-%d").date()),
                   int(tambah_hari), now(), pid))
    x.commit()
    x.close()


def pesanan_set_status(pid, status):
    x = db()
    x.execute("UPDATE pesanan SET status=? WHERE id=?", (status, pid))
    x.commit()
    x.close()


def pesanan_aktif():
    """Semua pesanan yang belum ditandai EXPIRED (untuk notifikasi masa aktif)."""
    x = db()
    r = x.execute("SELECT * FROM pesanan WHERE status IS NULL OR status!='EXPIRED'"
                  " ORDER BY id DESC").fetchall()
    x.close()
    return r


def sudah_notif(p, tag):
    try:
        n = (p["notif"] or "")
    except Exception:
        n = ""
    return ("|%s|" % tag) in ("|%s|" % n.replace(",", "|"))


def tandai_notif(pid, tag):
    p = pesanan_by_id(pid)
    if not p:
        return
    try:
        n = (p["notif"] or "").strip()
    except Exception:
        n = ""
    ada = [x for x in n.split(",") if x]
    if tag not in ada:
        ada.append(tag)
    x = db()
    x.execute("UPDATE pesanan SET notif=? WHERE id=?", (",".join(ada), pid))
    x.commit()
    x.close()


# ---------------- perpanjang akun (renew) ----------------
def _kill(p):
    try:
        os.killpg(os.getpgid(p.pid), signal.SIGKILL)
    except Exception:
        try:
            p.kill()
        except Exception:
            pass


def _jalan_script(cmd, jawaban, timeout=45, cek=None, tunda=2):
    """Jalankan script panel yang interaktif.

    Script panel banyak yang diakhiri `menu`/`m-l2tp` yang LOOP tanpa henti
    kalau stdin habis (dipanggil dari bot) -> bikin timeout 120 detik.
    Karena itu:
      - `cek`   : fungsi yang dipanggil tiap 1 detik; kalau True berarti
                  pekerjaan sudah selesai -> proses langsung dimatikan.
      - `tunda` : tunggu sekian detik setelah cek() True (biar tulisan
                  terakhir ke disk selesai).
      - `timeout`: batas maksimal, lalu dimatikan paksa.
    Return (selesai, output).
    """
    data = ("\n".join(str(a) for a in jawaban) + "\n").encode()
    try:
        p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             start_new_session=True)
    except Exception as e:
        return False, str(e)

    try:
        p.stdin.write(data)
        p.stdin.close()
    except Exception:
        pass

    mulai = time.time()
    selesai = False
    while True:
        if p.poll() is not None:
            break
        if time.time() - mulai > timeout:
            _kill(p)
            break
        if cek is not None and not selesai:
            try:
                if cek():
                    selesai = True
                    time.sleep(max(0, tunda))
                    _kill(p)
                    break
            except Exception:
                pass
        time.sleep(1)

    try:
        out = p.stdout.read() if p.stdout else b""
    except Exception:
        out = b""
    try:
        p.wait(timeout=5)
    except Exception:
        pass
    return True, (out or b"").decode("utf-8", "ignore")


def baca_expired_panel(tipe, akun):
    """Baca tanggal expired akun langsung dari sistem panel (YYYY-MM-DD)."""
    if not akun:
        return None
    try:
        if tipe in ("ssh", "ovpn"):
            out = subprocess.check_output(
                "chage -l %s 2>/dev/null" % akun, shell=True,
                stderr=subprocess.DEVNULL, timeout=20).decode("utf-8", "ignore")
            for l in out.splitlines():
                if "expires" in l.lower():
                    v = l.split(":", 1)[-1].strip()
                    if not v or v.lower().startswith("never"):
                        continue
                    for f in ("%b %d, %Y", "%b %d %Y", "%Y-%m-%d", "%d %b %Y"):
                        try:
                            return DT.datetime.strptime(v, f).strftime("%Y-%m-%d")
                        except Exception:
                            continue
        elif tipe == "l2tp":
            out = subprocess.check_output(
                "grep -E '^### %s ' /etc/l2tp/.l2tp.db 2>/dev/null" % akun,
                shell=True, stderr=subprocess.DEVNULL, timeout=20).decode("utf-8", "ignore")
            b = (out or "").split()
            if len(b) >= 3:
                return b[2][:10]
        else:
            tag = TAG_XRAY.get(tipe)
            if tag:
                out = subprocess.check_output(
                    "grep -E '^%s %s ' /etc/xray/config.json 2>/dev/null" % (tag, akun),
                    shell=True, stderr=subprocess.DEVNULL, timeout=20).decode("utf-8", "ignore")
                b = (out or "").split()
                if len(b) >= 3:
                    return b[2][:10]
    except Exception:
        pass
    return None


def hari_perpanjang(tipe, sisa, hari_beli):
    """Hitung angka hari yang harus DIKIRIM ke script renew panel.

    Script panel ada 2 macam:
      - MENAMBAH sisa hari  (vmess/vless/trojan/ss) -> kirim hari_beli saja,
        tapi kalau akun sudah lewat expired, sisa negatif harus dikoreksi.
      - HITUNG ULANG dari hari ini (ssh/l2tp) -> kirim sisa + hari_beli.
    Hasil akhirnya sama: expired baru = max(hari ini, expired lama) + hari_beli.
    """
    hari_beli = int(hari_beli)
    sisa = int(sisa or 0)
    if RENEW_TAMBAH.get(tipe):
        return hari_beli + max(0, -sisa)
    return hari_beli + max(0, sisa)


def renew_akun(tipe, akun, password, hari_beli, sisa, quota="0", iplimit="0"):
    """Perpanjang akun di sistem panel.

    Return (ok, pesan, exp_baru 'YYYY-MM-DD').
    """
    if not akun:
        return False, "Akun kosong.", None
    pass_days = hari_perpanjang(tipe, sisa, hari_beli)
    exp_harap = (DT.date.today() +
                 DT.timedelta(days=int(hari_beli) + max(0, int(sisa or 0)))
                 ).strftime("%Y-%m-%d")

    # ---- SSH/OVPN: langsung (sama dgn renewssh panel terbaru:
    #      usermod -e + passwd -u + usermod -U + hapus flag lock kuota) ----
    if tipe in ("ssh", "ovpn"):
        try:
            r = subprocess.run("usermod -e %s %s" % (exp_harap, akun), shell=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
            if r.returncode != 0:
                return False, (r.stdout or b"").decode("utf-8", "ignore")[-300:], None
            subprocess.run("passwd -u %s" % akun, shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
            subprocess.run("usermod -U %s" % akun, shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
            # hapus flag lock kuota supaya akun bisa login lagi (seperti renewssh panel)
            subprocess.run("rm -f /etc/limit/ssh/%s.lock" % akun, shell=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15)
            return True, "OK", exp_harap
        except Exception as e:
            return False, str(e), None

    # ---- L2TP: langsung (script renew-l2tp panel menggantung di m-l2tp) ----
    if tipe == "l2tp":
        if renew_l2tp(akun, exp_harap, password):
            return True, "OK", exp_harap
        return False, "Akun L2TP tidak ditemukan.", None

    if tipe == "vmess":
        cmd, ans = "renewws", [akun, pass_days, quota, iplimit]
    elif tipe == "vless":
        cmd, ans = "renewvless", [akun, pass_days, quota, iplimit]
    elif tipe == "trojan":
        cmd, ans = "renewtr", [akun, pass_days, quota, iplimit]
    elif tipe == "ss":
        cmd, ans = "renewss", [akun, pass_days]
    else:
        return False, "Tipe tidak dikenal: %s" % tipe, None

    ok, out = _jalan_script(cmd, ans, timeout=40,
                            cek=lambda: (baca_expired_panel(tipe, akun) or "") >= exp_harap)
    if not ok:
        return False, out, None

    # verifikasi: baca ulang dari file panel
    hasil = baca_expired_panel(tipe, akun)
    if hasil:
        try:
            if hasil < exp_harap:
                # script tidak menerapkan yang kita minta -> koreksi langsung
                _koreksi_expired(tipe, akun, password, exp_harap)
                hasil = baca_expired_panel(tipe, akun) or exp_harap
        except Exception:
            pass
    return True, (out or "")[-400:], (hasil or exp_harap)


def _koreksi_expired(tipe, akun, password, exp_iso):
    """Tulis langsung tanggal expired ke file/db panel (cadangan)."""
    try:
        if tipe == "l2tp":
            pw = password or ""
            subprocess.run("sed -i '/^### %s /c\\### %s %s %s' /etc/l2tp/.l2tp.db"
                           % (akun, akun, exp_iso, pw), shell=True, timeout=20)
            return
        tag = TAG_XRAY.get(tipe)
        if not tag:
            return
        subprocess.run("sed -i '/^%s %s /c\\%s %s %s' /etc/xray/config.json"
                       % (tag, akun, tag, akun, exp_iso), shell=True, timeout=20)
        berkas = {"vmess": "/etc/vmess/.vmess.db",
                  "vless": "/root/akun/vless/.vless.conf",
                  "trojan": "/root/akun/trojan/.trojan.conf",
                  "ss": "/root/akun/shadowsocks/.shadowsocks.conf"}.get(tipe)
        if berkas:
            subprocess.run("sed -i '/^%s %s /c\\%s %s %s' %s"
                           % (tag, akun, tag, akun, exp_iso, berkas),
                           shell=True, timeout=20)
        subprocess.run("systemctl restart xray", shell=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=60)
    except Exception:
        pass


# ---------------- pembuat akun ----------------
def _rand(n=5):
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))


def buat_username(tipe):
    pre = {"ssh": "ssh", "ovpn": "ovpn", "vmess": "vm", "vless": "vl",
           "trojan": "tr", "ss": "ss", "l2tp": "l2"}.get(tipe, "us")
    for _ in range(30):
        u = pre + _rand(5)
        if not _username_dipakai(u):
            return u
    return pre + _rand(8)


def _username_dipakai(u):
    x = db()
    r = x.execute("SELECT 1 FROM pesanan WHERE akun=?", (u,)).fetchone()
    x.close()
    if r:
        return True
    try:
        with open("/etc/passwd") as f:
            if re.search(r"^%s:" % re.escape(u), f.read(), re.M):
                return True
    except Exception:
        pass
    return False


def buat_akun(tipe, user, hari, quota="0", iplimit="0", password=None):
    """Bikin akun. L2TP dibuat langsung (script panel-nya menggantung),
    sisanya pakai script panel + pengaman anti-menggantung + verifikasi."""
    hari = str(int(hari))
    quota = str(quota or "0")
    iplimit = str(iplimit or "0")
    pw = password or _rand(8)

    # ---- L2TP: langsung (add-l2tp panel diakhiri m-l2tp yang loop tanpa henti) ----
    if tipe == "l2tp":
        return buat_l2tp(user, pw, hari)

    if tipe in ("ssh", "ovpn"):
        # addssh: Username, Password, Limit IP, Limit Quota, Expired (Days)
        cmd, ans = "addssh", [user, pw, iplimit, quota, hari]
    elif tipe == "vmess":
        cmd, ans = "addws", [user, hari, quota, iplimit]
    elif tipe == "vless":
        cmd, ans = "addvless", [user, hari, quota, iplimit]
    elif tipe == "trojan":
        cmd, ans = "addtr", [user, hari, quota, iplimit]
    elif tipe == "ss":
        # addss diakhiri "menu" -> loop tanpa henti kalau stdin habis.
        # Matikan begitu akun terdeteksi di sistem (tidak perlu tunggu 45 detik).
        ok, out = _jalan_script("addss", [user, hari, quota],
                                timeout=45, cek=lambda: _akun_ada("ss", user))
        if not ok:
            return False, out
        if not _akun_ada("ss", user):
            return False, ((out or "")[-400:] + "\n[akun tidak terbentuk di sistem]")
        return True, out
    else:
        return False, "Tipe tidak dikenal: %s" % tipe

    ok, out = _jalan_script(cmd, ans, timeout=45)
    if not ok:
        return False, out
    if not _akun_ada(tipe, user):
        return False, ((out or "")[-400:] + "\n[akun tidak terbentuk di sistem]")
    return True, out


def _akun_ada(tipe, user):
    """Cek akun benar-benar ada di sistem (verifikasi setelah bikin akun)."""
    if not user:
        return False
    u = re.escape(user)
    try:
        if tipe in ("ssh", "ovpn"):
            with open(PASSWD_FILE) as f:
                return bool(re.search(r"^%s:" % u, f.read(), re.M))
        if tipe == "l2tp":
            return _l2tp_ada(user)
        tag = TAG_XRAY.get(tipe)
        if tag:
            with open(XRAY_CFG) as f:
                return bool(re.search(r"^%s %s " % (re.escape(tag), u), f.read(), re.M))
    except Exception:
        pass
    return False


def _l2tp_ada(user):
    """Akun L2TP ada kalau tercatat di .l2tp.db ATAU chap-secrets."""
    u = re.escape(user)
    for path, pola in ((L2TP_DB, r"^### %s " % u),
                       (L2TP_CHAP, r"^%s[ \t]" % u)):
        try:
            with open(path) as f:
                if re.search(pola, f.read(), re.M):
                    return True
        except Exception:
            continue
    return False


def _daftar_akun(tipe):
    """Daftar semua username untuk 1 tipe (satu sumber kebenaran).

    ssh/ovpn : /etc/passwd  (UID >= 1000, bukan nobody) — sumber paling akurat
    l2tp     : .l2tp.db + chap-secrets (gabungan, tanpa dobel)
    xray     : /etc/xray/config.json per tag (###/#&/#!/#!#), unik
    """
    out = []
    try:
        if tipe in ("ssh", "ovpn"):
            r = subprocess.run(
                "awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd",
                shell=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                timeout=20)
            out = [x.strip() for x in r.stdout.decode("utf-8", "ignore").splitlines()
                   if x.strip()]
        elif tipe == "l2tp":
            nama = set()
            for path, pola in ((L2TP_DB, r"^###\s+(\S+)"),
                               (L2TP_CHAP, r"^([^#\s]\S*)[ \t]")):
                try:
                    with open(path) as f:
                        for m in re.finditer(pola, f.read(), re.M):
                            n = m.group(1).strip()
                            if n and n != "UNDEF" and not n.startswith("#"):
                                nama.add(n)
                except Exception:
                    continue
            out = sorted(nama)
        else:
            tag = TAG_XRAY.get(tipe)
            if tag:
                with open(XRAY_CFG) as f:
                    for m in re.finditer(r"^%s\s+(\S+)(?:\s|$)" % re.escape(tag),
                                         f.read(), re.M):
                        if m.group(1) not in out:
                            out.append(m.group(1))
    except Exception:
        pass
    # buang dobel tapi jaga urutan
    seen = set()
    res = []
    for x in out:
        if x not in seen:
            seen.add(x)
            res.append(x)
    return res


def jumlah_akun(tipe=None):
    """Jumlah akun per tipe (sinkron dengan data server).

    Pembungkus hitung_akun_sistem() supaya SEMUA menu memakai
    SATU sumber kebenaran yang sama.
    tipe=None -> dict semua tipe + 'total'
    """
    h = hitung_akun_sistem()
    if tipe:
        return h.get(tipe, 0)
    return h


# ---------------- L2TP / IKEv2 (langsung, tanpa script panel) ----------------
def _l2tp_bersih(user):
    """Hapus akun L2TP dari semua berkas."""
    u = re.escape(user)
    for path, pola in ((L2TP_DB, r"^### %s " % u),
                       (L2TP_CHAP, r"^%s[ \t]" % u),
                       (L2TP_IPSEC, r"^%s[ \t]*:.*EAP" % u)):
        try:
            with open(path) as f:
                baris = f.readlines()
        except Exception:
            continue
        baru = [l for l in baris if not re.search(pola, l)]
        try:
            with open(path, "w") as f:
                f.writelines(baru)
        except Exception:
            pass


def _l2tp_reload():
    for cmd in ("ipsec rereadsecrets", "ipsec reload", "systemctl restart xl2tpd"):
        try:
            subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=30)
        except Exception:
            pass


def _l2tp_psk():
    """Ambil PSK/IPSec dari beberapa kemungkinan lokasi."""
    for p in ("/etc/l2tp/psk", "/etc/l2tp/psk.txt", "/etc/psk", "/etc/xray/l2tp-psk"):
        try:
            with open(p) as f:
                v = f.read().strip()
            if v:
                return v
        except Exception:
            continue
    # dari /etc/ipsec.secrets :  : PSK "xxxx"
    try:
        with open(L2TP_IPSEC) as f:
            for l in f:
                m = re.search(r':\s*PSK\s*"([^"]+)"', l)
                if m:
                    return m.group(1)
    except Exception:
        pass
    return ""


def _tulis_profil_l2tp(user, pw, hari, exp_iso):
    """Tulis file profil /var/www/html/l2tp-<user>.txt (seperti panel)."""
    dom = cfg("DOMAIN", "")
    psk = _l2tp_psk()
    try:
        d = DT.datetime.strptime(exp_iso, "%Y-%m-%d").date()
    except Exception:
        d = DT.date.today()
    isi = """━━━━━━━━━━━━━━━━━━━━━━━
     L2TP / IKEv2 ACCOUNT
━━━━━━━━━━━━━━━━━━━━━━━
Remarks      : %s
Host / IP    : %s
Username     : %s
Password     : %s
IPSec PSK    : %s
━━━━━━━━━━━━━━━━━━━━━━━
Port L2TP    : 1701
Port IPSec   : 500, 4500
Port IKEv2   : 500, 4500
DNS          : 8.8.8.8, 1.1.1.1
━━━━━━━━━━━━━━━━━━━━━━━
Aktif Selama : %s Hari
Berakhir     : %s
━━━━━━━━━━━━━━━━━━━━━━━
""" % (user, dom, user, pw, psk or "-", hari, exp_tampil(d))
    try:
        os.makedirs(L2TP_WWW, exist_ok=True)
        with open(os.path.join(L2TP_WWW, "l2tp-%s.txt" % user), "w") as f:
            f.write(isi)
    except Exception:
        pass


def buat_l2tp(user, pw, hari):
    """Bikin akun L2TP/IKEv2 langsung. Return (ok, pesan)."""
    try:
        hari = int(hari)
    except Exception:
        hari = 30
    exp = (DT.date.today() + DT.timedelta(days=hari)).strftime("%Y-%m-%d")
    try:
        os.makedirs("/etc/l2tp", exist_ok=True)
        os.makedirs("/etc/ppp", exist_ok=True)
        _l2tp_bersih(user)
        with open(L2TP_CHAP, "a") as f:
            f.write("%s * %s *\n" % (user, pw))
        with open(L2TP_IPSEC, "a") as f:
            f.write('%s : EAP "%s"\n' % (user, pw))
        with open(L2TP_DB, "a") as f:
            f.write("### %s %s %s\n" % (user, exp, pw))
    except Exception as e:
        return False, "Gagal menulis berkas L2TP: %s" % e
    _l2tp_reload()
    _tulis_profil_l2tp(user, pw, hari, exp)
    if not _akun_ada("l2tp", user):
        return False, "Akun L2TP tidak terbentuk."
    return True, "OK"


def hapus_l2tp(user):
    _l2tp_bersih(user)
    _l2tp_reload()
    try:
        os.remove(os.path.join(L2TP_WWW, "l2tp-%s.txt" % user))
    except Exception:
        pass
    return True


def renew_l2tp(user, exp_iso, password=""):
    """Set tanggal expired akun L2TP langsung."""
    try:
        with open(L2TP_DB) as f:
            baris = f.readlines()
    except Exception:
        return False
    baru, ketemu = [], False
    for l in baris:
        if re.match(r"^### %s " % re.escape(user), l):
            b = l.split()
            pw = b[3] if len(b) > 3 else (password or "")
            baru.append("### %s %s %s\n" % (user, exp_iso, pw))
            ketemu = True
        else:
            baru.append(l)
    if not ketemu:
        return False
    try:
        with open(L2TP_DB, "w") as f:
            f.writelines(baru)
    except Exception:
        return False
    _l2tp_reload()
    return True


def _hapus_akun(tipe, user):
    """Hapus akun via script panel.

    Script delete panel (delssh/delws/delvless/deltr/delss) meminta NOMOR
    URUT user (bukan username). Kita cari nomor user pada daftar yang sama
    persis dengan cara script panel menyusunnya, lalu kirim nomor tsb.
    """
    if not user:
        return
    if tipe == "l2tp":
        hapus_l2tp(user)
        return

    MARK = {"ssh": None, "ovpn": None,
            "vmess": "### ", "vless": "#& ", "trojan": "#! ", "ss": "#!# "}.get(tipe)
    if tipe == "ss":
        MARK = "#!# "
    if MARK is None and tipe not in ("ssh", "ovpn"):
        return

    # ---- susun daftar user sama persis seperti script panel ----
    users = []
    try:
        if tipe in ("ssh", "ovpn"):
            out = subprocess.check_output(
                "awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd | sort",
                shell=True, stderr=subprocess.DEVNULL, timeout=15
            ).decode("utf-8", "ignore")
            users = [u for u in out.splitlines() if u.strip()]
        else:
            out = subprocess.check_output(
                "grep -E '^%s' /etc/xray/config.json | awk '{print $2}' | sort -u"
                % MARK.strip(), shell=True, stderr=subprocess.DEVNULL, timeout=15
            ).decode("utf-8", "ignore")
            users = [u for u in out.splitlines() if u.strip()]
    except Exception:
        return

    if user not in users:
        return
    nomor = str(users.index(user) + 1)

    cmd = {"ssh": "delssh", "ovpn": "delssh", "vmess": "delws",
           "vless": "delvless", "trojan": "deltr", "ss": "delss"}.get(tipe)
    if not cmd:
        return
    _jalan_script(cmd, [nomor], timeout=30)


def _hapus_xray_langsung(tipe, user):
    """Hapus akun Xray langsung dari config.json (tanpa script panel).
    Dipakai untuk cleanup trial xray setelah waktu menit habis."""
    tag = TAG_XRAY.get(tipe)
    if not tag or not user:
        return
    try:
        # hapus semua baris blok client (dari "### user exp" sampai "},")
        subprocess.run(
            "sed -i '/^%s %s /,/^},{/d' /etc/xray/config.json"
            % (re.escape(tag), re.escape(user)),
            shell=True, timeout=15)
        # hapus file quota/limit
        for p in ("/etc/%s/%s" % (tipe, user),
                  "/etc/kyt/limit/%s/ip/%s" % (tipe, user)):
            subprocess.run("rm -rf '%s'" % p, shell=True, timeout=10)
        subprocess.run("systemctl restart xray", shell=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=60)
    except Exception:
        pass


def buat_trial_xray(tipe, menit=60):
    """Buat trial VMess/VLESS/Trojan/SS mengikuti script panel terbaru.

    Script trial panel (trialws/trialvless/trialtr/trialss) TIDAK lagi menerima
    input menit — semuanya hardcoded 1 hari (Quota 1GB / IP 10 / SS 5GB).
    Kita jalankan script panel apa adanya, lalu jadwalkan penghapusan akun
    via background thread setelah `menit` menit, agar masa trial sesuai pilihan.
    Return (ok, out).
    """
    cmd = {"vmess": "trialws", "vless": "trialvless",
           "trojan": "trialtr", "ss": "trialss"}.get(tipe)
    if not cmd:
        return False, "Tipe tidak dikenal: %s" % tipe

    ok, out = _jalan_script(cmd, [], timeout=60)
    if not ok:
        return False, out

    # Ambil nama akun trial yang baru dibuat (format "Trial-XX123")
    m = re.search(r"Trial-[A-Za-z]{1,4}\d+", out or "")
    akun_trial = m.group(0) if m else ""
    if not akun_trial:
        m2 = re.search(r"(?:Remarks|Username|Client)\s*:\s*(Trial\S+)", out or "")
        akun_trial = m2.group(1) if m2 else ""

    if akun_trial:
        # Jadwalkan penghapusan setelah `menit` menit
        t = threading.Timer(int(menit) * 60, _hapus_xray_langsung,
                            args=(tipe, akun_trial))
        t.daemon = True
        t.start()
        logging.info("[trial] %s %s dijadwalkan hapus dalam %s menit",
                     tipe, akun_trial, menit)
    return True, out


def buat_allxray(user, password, hari, quota="0", iplimit="0"):
    """Buat SEMUA akun xray (VMess, VLESS, Trojan, Shadowsocks, L2TP) sekaligus.

    Menggunakan script panel /usr/local/sbin/add-allxray yang sudah dilengkapi
    grep shim agar username yang sama tidak bentrok di /etc/xray/config.json.
    Return (berhasil_list, gagal_list, out, links_dict, psk_l2tp).
    """
    hari = str(int(hari))
    quota = str(quota or "0")
    iplimit = str(iplimit or "0")
    pw = password or _rand(8)

    ans = [user, pw, quota, hari, iplimit, "y", ""]
    ok, out = _jalan_script("add-allxray", ans, timeout=75)

    # Verifikasi protokol mana yang berhasil dan gagal
    berhasil = []
    gagal = []
    for tipe, label in (("vmess", "VMess"), ("vless", "VLESS"),
                        ("trojan", "Trojan"), ("ss", "Shadowsocks"),
                        ("l2tp", "L2TP / IKEv2")):
        if _akun_ada(tipe, user):
            berhasil.append(label)
        else:
            gagal.append(label)

    # Ambil link per protokol
    raw_links = ambil_link(out, berlabel=False)
    links_dict = {
        "vmess": [l for l in raw_links if l.startswith("vmess://")],
        "vless": [l for l in raw_links if l.startswith("vless://")],
        "trojan": [l for l in raw_links if l.startswith("trojan://")],
        "ss": [l for l in raw_links if l.startswith("ss://")],
    }
    psk = _l2tp_psk() or "(lihat di panel)"
    return (berhasil, gagal, out, links_dict, psk)


def detail_allxray_parts(user, pw, hari, quota, iplimit, links_dict, psk):
    """Bagi ALL XRAY menjadi 2 bagian yang rapi (< 3800 karakter agar tidak ditolak Telegram):
    Bagian 1: Akun Info + VMess (6 link) + VLESS (6 link)
    Bagian 2: Trojan (5 link) + Shadowsocks (3 link) + L2TP + OpenClash + Catatan
    Keduanya memakai template seragam ui_akun().
    """
    dom = cfg("DOMAIN", "")
    exp = (DT.date.today() + DT.timedelta(days=int(hari))).strftime("%d %b %Y")

    info = [
        ("Username", user),
        ("Password", pw),
        ("Domain", dom),
        ("Quota", "%s GB" % quota if str(quota) not in ("0", "") else "Unlimited"),
        ("Limit IP", "%s" % iplimit if str(iplimit) not in ("0", "") else "Unlimited"),
        ("Expired", exp),
    ]

    # Bagian 1: VMess & VLESS
    blok1 = []
    for tipe, judul in (("vmess", "VMESS (LINK)"), ("vless", "VLESS (LINK)")):
        sublinks = links_dict.get(tipe, [])
        if sublinks:
            blok1.append((judul, "\n".join(link_berlabel(sublinks))))
    part1 = ui_akun("ALL XRAY (1/2) — VMESS & VLESS", info, blok1)

    # Bagian 2: Trojan, SS, L2TP, OpenClash
    blok2 = []
    for tipe, judul in (("trojan", "TROJAN (LINK)"), ("ss", "SHADOWSOCKS (LINK)")):
        sublinks = links_dict.get(tipe, [])
        if sublinks:
            blok2.append((judul, "\n".join(link_berlabel(sublinks))))

    info_l2tp = "\n".join([
        "%-14s: %s" % ("Username", user),
        "%-14s: %s" % ("Password", pw),
        "%-14s: %s" % ("Server", dom),
        "%-14s: %s" % ("IPSec PSK", psk),
        "%-14s: %s" % ("Port", "UDP 500, 4500, 1701"),
    ])
    blok2.append(("L2TP / IKEv2", info_l2tp))

    openclash = "\n".join([
        "VMess      : https://%s:81/vmess-%s.txt" % (dom, user),
        "VLESS      : https://%s:81/vless-%s.txt" % (dom, user),
        "Trojan     : https://%s:81/trojan-%s.txt" % (dom, user),
        "L2TP       : https://%s:81/l2tp-%s.txt" % (dom, user),
    ])
    blok2.append(("OPENCLASH", openclash))

    info_part2 = [
        ("Username", user),
        ("Domain", dom),
        ("Expired", exp),
    ]
    part2 = ui_akun("ALL XRAY (2/2) — TROJAN, SS & L2TP", info_part2, blok2,
                    catatan=["Semua 5 protokol (VMess, VLESS, Trojan, SS, L2TP) aktif",
                             "Pakai salah satu link saja (umum: WS TLS)"])

    return part1, part2


def detail_allxray(user, pw, hari, quota, iplimit, links_dict, psk):
    """Format tampilan output ALL XRAY — gabungan (kompatibilitas)."""
    p1, p2 = detail_allxray_parts(user, pw, hari, quota, iplimit, links_dict, psk)
    return p1 + "\n\n" + p2


def ambil_link(out, berlabel=True):
    """Ambil link akun dari output script panel."""
    # Bersihkan kode escape ANSI (warna terminal) terlebih dahulu
    # agar tidak mengacaukan regex negative lookbehind (misal \x1b[0;32mvmess://)
    clean_out = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', out or "")
    links = []
    for proto in ("vmess", "vless", "trojan", "ss"):
        for m in re.finditer(r"(?<![A-Za-z0-9])" + proto + r"://[^\s`'\"]+", clean_out):
            l = m.group(0).strip().strip("'\"").strip()
            while l and l[-1] in "'\"":
                l = l[:-1]
            if l and l not in links:
                links.append(l)
    if not berlabel:
        return links
    return link_berlabel(links)


NAMA_NET = {
    "ws": "WS", "websocket": "WS",
    "grpc": "gRPC", "gun": "gRPC",
    "httpupgrade": "HTTPUpgrade", "http-upgrade": "HTTPUpgrade",
    "xhttp": "XHTTP", "splithttp": "XHTTP",
    "tcp": "TCP", "h2": "HTTP/2", "http": "HTTP", "quic": "QUIC", "kcp": "mKCP",
}


def _q(s):
    """Parse query string jadi dict (huruf kecil)."""
    d = {}
    q = s.split("?", 1)[1] if "?" in s else ""
    q = q.split("#", 1)[0]
    for kv in q.split("&"):
        if "=" in kv:
            k, _, v = kv.partition("=")
            d[k.lower()] = _urlunquote(v)
    return d


def _port_of(s):
    try:
        host = s.split("://", 1)[1].split("?", 1)[0].split("#", 1)[0]
        host = host.split("@")[-1].split("/")[0]
        if host.startswith("["):
            return host.split("]:", 1)[1]
        if ":" in host:
            return host.rsplit(":", 1)[1]
    except Exception:
        pass
    return ""


def label_link(link):
    """Keterangan jenis link: 'WS TLS 443', 'WS Non-TLS 80', 'gRPC TLS 443',
    'HTTPUpgrade TLS 443', 'XHTTP TLS 443', 'TCP TLS 8543'."""
    s = (link or "").strip()
    if not s:
        return "-"
    low = s.lower()
    net, sec = "", ""
    port = _port_of(s)

    if low.startswith("vmess://"):
        try:
            raw = s[8:].strip()
            raw += "=" * (-len(raw) % 4)
            j = json.loads(base64.b64decode(raw).decode("utf-8", "ignore"))
            net = str(j.get("net", "")).lower()
            sec = str(j.get("tls", "")).lower()
            port = str(j.get("port", port))
        except Exception:
            pass
    elif low.startswith(("vless://", "trojan://", "ss://")):
        p = _q(s)
        net = p.get("type", "")
        sec = p.get("security", "")

    nama = NAMA_NET.get(net, (net or "-").upper())
    tls = "TLS" if sec in ("tls", "xtls", "reality") else "Non-TLS"
    teks = "%s %s" % (nama, tls)
    if port:
        teks += " %s" % port
    return teks


def link_berlabel(links):
    """Ubah daftar link jadi baris berlabel (siap ditampilkan)."""
    baris = []
    for i, l in enumerate(links, 1):
        baris.append("Link %d : %s" % (i, label_link(l)))
        baris.append(l)
        baris.append("")
    if baris:
        baris.append("(pakai salah satu saja — paling umum: WS TLS)")
    return baris


# ============================================================
#  TEMPLATE UI SERAGAM (standar: mengikuti UI VMess)
#  Dipakai SEMUA jenis akun: SSH, VMess, VLESS, Trojan, SS, L2TP
#  dan baik akun reguler maupun TRIAL.
# ============================================================
UI_LEBAR = 21          # panjang garis ━━ (sama dgn UI VMess)
UI_GARIS = "━" * UI_LEBAR


def ui_judul(teks):
    """Buat judul bagian yang diapit dua garis (rata tengah)."""
    t = (teks or "").strip()
    if not t:
        return UI_GARIS
    pad = max(0, (UI_LEBAR - len(t)) // 2)
    return "%s\n%s%s\n%s" % (UI_GARIS, " " * pad, t, UI_GARIS)


def ui_akun(judul, info, blok=None, catatan=None):
    """Template tampilan akun yang SERAGAM untuk semua protokol.

    judul  : misal "VMESS ACCOUNT" / "SSH OVPN ACCOUNT" / "VLESS TRIAL"
    info   : list pasangan (label, nilai) — bagian data akun utama
    blok   : dict {judul_bagian: isi_teks} — bagian tambahan
             (misal PORT, PAYLOAD, FILE OVPN, LINK)
    catatan: list teks catatan di bagian bawah

    Semua bagian diapit garis dan label rata kiri dengan lebar tetap,
    persis seperti UI VMess yang sudah rapi.
    """
    L = UI_GARIS
    LE = 14  # lebar kolom label (misal "Remarks       : ")
    b = []

    # ---- header: judul utama ----
    b.append(ui_judul(judul))

    # ---- bagian INFO ----
    for k, v in (info or []):
        if v is None or str(v).strip() == "":
            v = "-"
        b.append("%-*s: %s" % (LE, k, v))

    # ---- bagian-bagian tambahan ----
    for judul_b, isi in (blok or {}):
        isi = (isi or "").strip("\n")
        if not isi:
            continue
        b.append(ui_judul(judul_b))
        b.append(isi)

    # ---- catatan ----
    if catatan:
        c = "\n".join("- %s" % x for x in catatan if x)
        if c:
            b.append(ui_judul("CATATAN"))
            b.append(c)

    # ---- footer ----
    b.append(L)
    return "\n".join(b)


def detail_ssh(user, pw, expired=None, quota=None, iplimit=None):
    """Tampilan akun SSH — SERAGAM dgn UI VMess (via ui_akun)."""
    dom = cfg("DOMAIN", "")
    info = [("Username", user), ("Password", pw), ("Host", dom)]

    ns = ""
    for p in ("/etc/xray/dns", "/root/slowdns/dns"):
        if os.path.isfile(p):
            try:
                ns = open(p).read().strip()
                if ns:
                    break
            except Exception:
                pass
    if not ns and dom:
        ns = f"ns.{dom}"

    pub = ""
    for p in ("/root/slowdns/server.pub", "/etc/slowdns/server.pub"):
        if os.path.isfile(p):
            try:
                pub = open(p).read().strip()
                if pub:
                    break
            except Exception:
                pass

    dns_dom = ""
    for p in ("/root/slowdns/dns_domain", "/etc/xray/dns_domain"):
        if os.path.isfile(p):
            try:
                dns_dom = open(p).read().strip()
                if dns_dom:
                    break
            except Exception:
                pass
    if not dns_dom:
        dns_dom = dom

    if pub:
        info.append(("Host Slowdns", dns_dom))
        info.append(("Pub Key", pub))
    if expired:
        info.append(("Expired", expired))
    if quota is not None:
        info.append(("Quota", "%s GB" % quota if str(quota) != "0" else "Unlimited"))
    if iplimit is not None:
        info.append(("Limit IP", "%s" % iplimit if str(iplimit) != "0" else "Unlimited"))

    port_lines = [
        "OpenSSH        : 443, 80, 22",
        "Dropbear       : 443, 109",
        "Dropbear WS    : 443, 109",
        "SSH UDP        : 1-65535",
        "SSH WS (nonTLS): 80, 8080, 8081-9999",
        "SSH WSS (TLS)  : 443",
        "HCR            : 8811 (TLS + Plain)",
    ]
    if pub:
        port_lines.append("SlowDNS        : 53, 80, 443")
    port_lines.extend([
        "SSL/TLS        : 400-900",
        "OVPN WS SSL    : 443",
        "OVPN SSL       : 443",
        "OVPN TCP       : 443, 1194",
        "OVPN UDP       : 2200",
        "BadVPN UDP     : 7100, 7200, 7300",
    ])
    port = "\n".join(port_lines)

    payload = "\n".join([
        "[Payload SSH WS]",
        "GET / HTTP/1.1[crlf]Host: %s[crlf]Upgrade: websocket"
        "[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf][crlf]" % dom,
        "",
        "[Payload WS ENHANCED]",
        "PATCH / HTTP/1.1[crlf]Host: [host][crlf]Host: INPUT_YOUR_BUGCDN[crlf]"
        "Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]",
        "",
        "[CF-RAY without proxy & port]",
        "GET / HTTP/1.1[crlf]Host: INPUT_YOUR_BUGCDN[crlf][crlf]CF-RAY / HTTP/1.1[crlf]"
        "Host: %s[crlf]Upgrade: websocket[crlf]Connection: Keep-Alive[crlf]"
        "User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]" % dom,
        "",
        "[Payload WS HTTPS]",
        "GET / HTTP/1.1[crlf]Host: %s[crlf]Upgrade: websocket[crlf][crlf]" % dom,
    ])

    ovpn = "\n".join([
        "OVPN WS SSL    : https://%s:81/ws-ssl.ovpn" % dom,
        "OVPN SSL       : https://%s:81/ssl.ovpn" % dom,
        "OVPN TCP File  : https://%s:81/tcp.ovpn" % dom,
        "OVPN UDP File  : https://%s:81/udp.ovpn" % dom,
    ])

    blok = [
        ("PORT", port),
        ("PAYLOAD", payload),
        ("FILE OVPN", ovpn),
        ("SAVE LINK", "https://%s:81/ssh-%s.txt" % (dom, user)),
    ]

    catatan = [
        "WS (non-TLS) pakai port 80 / 8080 / 8081-9999",
        "WSS (TLS) pakai port 443",
    ]
    if pub:
        catatan.append("SlowDNS (HTTP Custom) centang SlowDNS, isi Nameserver & Pub Key di atas")

    return ui_akun("SSH OVPN ACCOUNT", info, blok, catatan=catatan)


def detail_l2tp(user, pw, expired=None):
    """Tampilan akun L2TP — SERAGAM dgn UI VMess (via ui_akun)."""
    dom = cfg("DOMAIN", "")
    psk = _l2tp_psk()
    info = [("Username", user), ("Password", pw), ("Server", dom),
            ("PSK/IPSec", psk or "(lihat di panel)")]
    if expired:
        info.append(("Expired", expired))
    return ui_akun("L2TP ACCOUNT", info, [
        ("PORT", "UDP 500, 4500, 1701"),
    ], catatan=["Pilih L2TP/IPSec di HP, isi PSK di atas"])


# ---- konfigurasi tampilan tiap protokol Xray (seragam) ----
XRAY_UI = {
    "vmess": {
        "judul": "VMESS ACCOUNT", "net": "WS / gRPC / HTTPUpgrade / XHTTP / TCP",
        "path_ws": "/vmess", "path_grpc": "vmess-grpc", "berkas": "vmess",
        "label_id": "UUID",
    },
    "vless": {
        "judul": "VLESS ACCOUNT", "net": "WS / gRPC / HTTPUpgrade / XHTTP / TCP",
        "path_ws": "/vless", "path_grpc": "vless-grpc", "berkas": "vless",
        "label_id": "UUID",
    },
    "trojan": {
        "judul": "TROJAN ACCOUNT", "net": "WS / gRPC / HTTPUpgrade / XHTTP / TCP",
        "path_ws": "/trojan-ws", "path_grpc": "trojan-grpc", "berkas": "trojan",
        "label_id": "Password/UUID",
    },
    "ss": {
        "judul": "SHADOWSOCKS ACCOUNT", "net": "WS / gRPC",
        "path_ws": "/ss-ws", "path_grpc": "ss-grpc", "berkas": "ss",
        "label_id": "Password",
    },
}


def detail_xray(tipe, user, uuid_or_pw, expired=None, quota=None,
                iplimit=None, links=None, remarks=None):
    """Tampilan akun Xray — SERAGAM mengikuti UI VMess.

    Dipakai SEMUA protokol (VMess/VLESS/Trojan/SS) baik akun reguler
    maupun TRIAL, supaya tampilannya konsisten.
    """
    cfg_ui = XRAY_UI.get(tipe) or XRAY_UI["vmess"]
    dom = cfg("DOMAIN", "")
    judul = cfg_ui["judul"]

    info = [
        ("Remarks", remarks or user),
        ("Domain", dom),
        ("Quota", ("%s GB" % quota if str(quota) not in ("0", "", "None")
                   else "Unlimited")),
        ("Limit IP", ("%s" % iplimit if str(iplimit) not in ("0", "", "None")
                      else "Unlimited")),
    ]
    if expired:
        info.append(("Expired", expired))

    teknis = "\n".join([
        "%-14s: %s" % (cfg_ui["label_id"], uuid_or_pw or "-"),
        "%-14s: %s" % ("Network", cfg_ui["net"]),
        "%-14s: %s" % ("Path WS", cfg_ui["path_ws"]),
        "%-14s: %s" % ("Path gRPC", cfg_ui["path_grpc"]),
        "%-14s: %s" % ("Port TLS", "222-1000"),
        "%-14s: %s" % ("Port NTLS", "80, 8080, 8081-9999"),
        "%-14s: %s" % ("Port gRPC", "443"),
    ])

    blok = [("DETAIL", teknis)]
    if links:
        blok.append(("LINK AKUN", "\n".join(links)))
    blok.append(("OPENCLASH",
                 "https://%s:81/%s-%s.txt" % (dom, cfg_ui["berkas"], user)))

    return ui_akun(judul, info, blok,
                   catatan=["Pakai salah satu link saja (umum: WS TLS)"])
