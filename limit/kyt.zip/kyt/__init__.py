from telethon import *
import datetime as DT
from telethon import *
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import asyncio
import logging
#usr/local/bin/kyt
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

exec(open("kyt/var.txt","r").read())

# ---- bersihkan tanda kutip sisa var.txt lama (DOMAIN='"x"' -> x) ----
for _nama in ("BOT_TOKEN", "ADMIN", "DOMAIN", "PUB", "HOST", "DUITKU_MERCHANT",
              "DUITKU_APIKEY"):
	try:
		_nilai = globals().get(_nama, "")
		if _nilai is not None:
			globals()[_nama] = str(_nilai).strip().strip('"').strip("'").strip()
	except Exception:
		pass

bot = TelegramClient("ddsdswl","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)


def _bersih_id(v):
	"""var.txt kadang ditulis ADMIN='"123"' -> ambil angkanya saja."""
	return str(v).strip().strip('"').strip("'").strip()


try:
	_x = sqlite3.connect("kyt/database.db")
	_c = _x.cursor()
	_c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
	_adm = _bersih_id(ADMIN)
	if _adm and not _c.execute("SELECT 1 FROM admin WHERE user_id=?", (_adm,)).fetchone():
		_c.execute("INSERT INTO admin (user_id) VALUES (?)", (_adm,))
	_x.commit()
	_x.close()
except Exception as _e:
	logging.error("init admin gagal: %s", _e)

def get_db():
	x = sqlite3.connect("kyt/database.db")
	x.row_factory = sqlite3.Row
	return x

def valid(id):
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [_bersih_id(v[0]) for v in x]
	return "true" if _bersih_id(id) in a else "false"

async def safe_send(event, text, buttons=None):
	"""Kirim menu: coba edit (kalau dari tombol), kalau tidak bisa -> reply.
	Menghindari MessageIdInvalidError saat /start atau /menu dikirim sebagai pesan baru.

	PENTING: pesan yang ADA GAMBARNYA (foto QRIS) tidak boleh di-edit,
	karena captionnya akan ketimpa menu (QR jadi nempel di menu)."""
	try:
		m = getattr(event, "message", None)
		if m is not None and getattr(m, "media", None) is not None:
			return await event.reply(text, buttons=buttons)
	except Exception:
		pass
	try:
		x = await event.edit(text, buttons=buttons)
		if x is not None:
			return x
	except Exception:
		pass
	try:
		return await event.reply(text, buttons=buttons)
	except Exception:
		return None

async def safe_send_photo(event, gambar, caption, buttons=None):
	"""Kirim pesan dengan GAMBAR (biar /start tidak polosan).
	gambar = path file lokal (diutamakan) atau URL.
	Kalau gagal -> kirim teks saja (tidak pernah error ke user)."""
	if gambar:
		try:
			return await bot.send_file(event.chat_id, gambar,
			                           caption=caption, buttons=buttons)
		except Exception as e:
			logging.error("kirim gambar start gagal (%s): %s", gambar, e)
			# kalau path lokal rusak, coba sekali lagi sebagai URL/apa adanya
			try:
				if not str(gambar).startswith(("http://", "https://")):
					return await bot.send_file(event.chat_id, str(gambar),
					                           caption=caption, buttons=buttons)
			except Exception as e2:
				logging.error("percobaan kedua gagal: %s", e2)
	return await safe_send(event, caption, buttons)


# ============================================================
#  INPUT DARI USER (pengganti bot.conversation berlapis)
#  Masalah lama: bot.conversation() dipakai 3x berturut-turut.
#  Telethon default exclusive=True -> kalau ada conversation lain
#  yang masih aktif di chat yang sama, muncul AlreadyInConversationError
#  dan bot DIAM tanpa pesan apa pun (ini yang bikin "stuck di Quota").
#  Helper di bawah: exclusive=False, ada timeout, dan SELALU
#  memberi pesan kalau gagal (tidak pernah diam).
# ============================================================
async def balas(event, teks, buttons=None):
	"""Kirim pesan yang pasti sampai (respond -> send_message)."""
	try:
		return await event.respond(teks, buttons=buttons)
	except Exception:
		pass
	try:
		return await bot.send_message(event.chat_id, teks, buttons=buttons)
	except Exception as e:
		logging.error("balas gagal: %s", e)
		return None


async def _kirim_pasti(event, teks):
	"""Kirim pesan lewat SEMUA jalur yang tersedia. Tidak pernah diam.

	Dulu: kalau event.respond() gagal (event sudah tidak valid setelah
	conversation), pesan TIDAK terkirim sama sekali -> bot terlihat DIAM.
	Sekarang dicoba: respond -> bot.send_message -> client.send_message
	(bangun ulang entity dari event.chat_id).
	"""
	for cara in ("respond", "kirim", "client"):
		try:
			if cara == "respond":
				x = await event.respond(teks)
				if x is not None:
					return x
			elif cara == "kirim":
				x = await bot.send_message(event.chat_id, teks)
				if x is not None:
					return x
			else:
				ent = await event.get_input_chat()
				x = await bot.send_message(ent, teks)
				if x is not None:
					return x
		except Exception as e:
			logging.error("_kirim_pasti[%s]: %s", cara, e)
	# usaha terakhir: tanpa tombol & tanpa event
	try:
		return await bot.send_message(int(event.chat_id), teks)
	except Exception as e:
		logging.error("_kirim_pasti[gagal total]: %s", e)
		return None


# ============================================================
#  ANTREAN INPUT PER-USER (TANPA bot.conversation)
#  Kenapa tidak pakai conversation lagi?
#   - conversation() Telethon menyimpan SATU set pending per chat.
#     Kalau dipakai berulang (username -> quota -> tombol hari),
#     pesan yang datang "nyasar" bisa masuk ke conversation yang
#     salah -> pertanyaan berikutnya (tombol hari) HILANG.
#   - Bot juga mengirim notifikasi ke chat yang sama (penjualan,
#     deposit, expired) -> ikut "terbaca" sebagai jawaban.
#  Solusi: setiap tanya() mendaftarkan SATU slot tunggu. Handler
#  global mengisi slot itu HANYA untuk pesan/tombol dari user yang
#  benar-benar sedang ditanya. Tidak ada state yang bertabrakan.
# ============================================================
_TUNGGU = {}          # chat_id -> dict(fut, jenis, uid)
_LOCK_TUNGGU = asyncio.Lock()


def _jawab_tunggu(chat_id, jenis, nilai, uid=None):
    """Isi slot tunggu user (dipanggil handler global)."""
    d = _TUNGGU.get(str(chat_id))
    if not d or d["jenis"] != jenis:
        return False
    if d["fut"].done():
        return False
    # hanya dari user yang sedang ditanya
    if d.get("uid") is not None:
        if uid is None or str(uid) != str(d["uid"]):
            return False
    try:
        d["fut"].set_result(nilai)
        return True
    except Exception:
        return False


def _filter_teks(uid):
    """Filter pesan masuk HANYA dari user ini (filter bawaan Telethon).

    events.NewMessage mendukung incoming=/from_users=.
    Kalau versi telethon tidak mendukung, pakai filter yang lebih longgar
    supaya bot tetap jalan (tidak error).
    """
    try:
        if uid is None:
            return events.NewMessage(incoming=True)
        return events.NewMessage(incoming=True, from_users=uid)
    except Exception as e:
        logging.error("filter teks gagal: %s", e)
        return events.NewMessage(incoming=True)


def _filter_tombol(uid):
    """Filter tombol HANYA dari user ini.

    PENTING: events.CallbackQuery TIDAK punya from_users/incoming
    (hanya chats, data, pattern, func). Jadi dipakai func=.
    """
    try:
        if uid is None:
            return events.CallbackQuery()
        return events.CallbackQuery(func=lambda e: e.sender_id == uid)
    except Exception as e:
        logging.error("filter tombol gagal: %s", e)
        return events.CallbackQuery()


async def tanya(event, pertanyaan, timeout=180, tombol=None, validasi=None,
                boleh_batal=True, pakai_strip=True):
    """Tanya SATU hal ke user.

    CARA KERJA (mengikuti pola yang TERBUKTI di versi lama bot):
      - pakai bot.conversation(exclusive=False)
      - jawaban diambil dengan wait_event + FILTER BAWAAN TELETHON:
            events.NewMessage(incoming=True, from_users=<user>)
            events.CallbackQuery(func=<hanya dari user itu>)
              (CallbackQuery TIDAK punya from_users/incoming)
        Artinya: HANYA pesan MASUK dari USER ITU yang diterima.
        Pesan bot sendiri / notifikasi / user lain otomatis DIABAIKAN
        oleh Telethon -> tidak perlu filter manual (yang rawan salah).

    Tambahan pengaman:
      - exclusive=False  -> tidak bentrok dengan conversation lain
      - timeout          -> tidak menggantung selamanya
      - SELALU ada pesan kalau gagal (tidak pernah diam)
      - pakai_strip      -> '-' bisa berarti BATAL atau nilai sah
    """
    chat = event.chat_id
    try:
        uid = event.sender_id
    except Exception:
        uid = None

    tolak_strip = (lambda t: pakai_strip and t == "-")
    pesan_validasi = ""

    for _ke in range(3):
        try:
            async with bot.conversation(chat, timeout=timeout,
                                        exclusive=False) as conv:
                logging.info("tanya: tanya_ke=%s jenis=%s",
                             _ke + 1, "tombol" if tombol else "teks")
                await conv.send_message(pertanyaan, buttons=tombol)

                if tombol:
                    ev = await conv.wait_event(
                        _filter_tombol(uid),
                        timeout=timeout)
                    try:
                        await ev.answer()
                    except Exception:
                        pass
                    data = ev.data.decode("ascii", "ignore") if ev.data else ""
                    logging.info("tanya: tombol dipilih=%r", data)
                    return data

                msg = await conv.wait_event(
                    _filter_teks(uid),
                    timeout=timeout)
                teks = (msg.raw_text or "").strip()
                logging.info("tanya: jawaban teks=%r", teks[:40])

        except asyncio.TimeoutError:
            await _kirim_pasti(event,
                               "⏱️ Waktu habis. Silakan ulangi dari menu.")
            return None
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logging.error("tanya gagal [%s]: %s",
                          (pertanyaan or "")[:40], repr(e))
            await _kirim_pasti(event,
                               "❌ Gagal memproses input.\n`%s: %s`\n\n"
                               "Silakan ulangi dari menu."
                               % (type(e).__name__, e))
            return None

        if tolak_strip(teks) and boleh_batal:
            await _kirim_pasti(event, "Dibatalkan.")
            return None
        if validasi is None:
            return teks
        try:
            ok, pesan = validasi(teks)
        except Exception:
            ok, pesan = True, ""
        if ok:
            return teks
        logging.info("tanya: validasi tolak %r -> %s", teks[:30], pesan)
        pesan_validasi = pesan
        pertanyaan = "❌ **%s**\n\n%s" % (pesan, pertanyaan)

    await _kirim_pasti(event, "❌ Input masih salah: **%s**\n\n"
                              "Silakan ulangi dari menu."
                       % (pesan_validasi or "tidak valid"))
    return None


async def tunggu_pesan(event, pertanyaan, timeout=300, boleh_batal=True):
    """Tunggu user mengirim PESAN (bisa berisi file/foto). Return event.

    Sama seperti tanya(): memakai wait_event dengan filter Telethon,
    jadi pesan bot sendiri / notifikasi TIDAK ikut terbaca.
    """
    chat = event.chat_id
    try:
        uid = event.sender_id
    except Exception:
        uid = None
    try:
        async with bot.conversation(chat, timeout=timeout,
                                    exclusive=False) as conv:
            await conv.send_message(pertanyaan)
            msg = await conv.wait_event(
                _filter_teks(uid),
                timeout=timeout)
    except asyncio.TimeoutError:
        await _kirim_pasti(event, "⏱️ Waktu habis. Silakan ulangi dari menu.")
        return None
    except asyncio.CancelledError:
        raise
    except Exception as e:
        logging.error("tunggu_pesan gagal: %s", repr(e))
        await _kirim_pasti(event, "❌ Gagal menerima pesan.\n`%s: %s`"
                           % (type(e).__name__, e))
        return None

    if boleh_batal and (getattr(msg, "raw_text", "") or "").strip() == "-":
        await _kirim_pasti(event, "Dibatalkan.")
        return None
    return msg


# ============================================================
#  CATATAN: mekanisme "antrean per-user" (_TUNGGU) SUDAH TIDAK DIPAKAI.
#  Diganti dengan wait_event + filter Telethon (cara lama yang terbukti).
#  Fungsi ini dipertahankan supaya __main__.py lama tidak error.
# ============================================================
def pasang_handler_tanya():
    """Tidak melakukan apa pun (dipertahankan untuk kompatibilitas)."""
    logging.info("tanya(): memakai wait_event + filter (tanpa handler global)")
    return True


# ============================================================



# ============================================================
#  PILIH MASA AKTIF (tombol 3/7/30)
#
#  PENTING - kenapa TIDAK memakai conversation:
#  Tombol MENU bot berfungsi normal (user bisa navigasi), artinya
#  CallbackQuery biasa PASTI sampai ke bot. Yang bermasalah hanya
#  callback yang ditangkap lewat conversation (pesan tampil lalu
#  hilang / tombol tidak terbaca).
#  Jadi di sini tombol dikirim sebagai pesan BIASA dan ditangkap
#  oleh handler callback sementara - mekanisme yang sama dengan menu.
#
#  Bonus: user juga boleh MENGETIK angkanya (3/7/30) kalau tombol
#  tidak muncul. Dua-duanya diterima.
# ============================================================
_HARI_AKTIF = {}     # token -> future


async def pilih_hari(event, judul="**Pilih Masa Aktif**", hari=(3, 7, 30),
                     timeout=300):
    """Tanya masa aktif lewat tombol. Return int hari atau None."""
    token = "%x" % random.getrandbits(64)
    chat = str(event.chat_id)
    uid = str(event.sender_id)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.get_event_loop()
    fut = loop.create_future()
    _HARI_AKTIF[token] = fut

    async def _jawab(nilai, sumber):
        if fut.done():
            return
        try:
            logging.info("pilih_hari: jawaban=%r (dari %s)", nilai, sumber)
            fut.set_result(nilai)
        except Exception:
            pass

    async def _on_cb(ev):
        try:
            if not ev.data:
                return
            data = ev.data.decode("ascii", "ignore")
            if not data.startswith(token + ":"):
                return
            if str(ev.chat_id) != chat:
                return
            try:
                await ev.answer()
            except Exception:
                pass
            await _jawab(data.split(":")[-1], "tombol")
        except Exception as e:
            logging.error("pilih_hari callback: %s", repr(e))

    async def _on_teks(ev):
        try:
            if str(ev.chat_id) != chat:
                return
            if str(ev.sender_id) != uid:
                return
            t = (ev.raw_text or "").strip()
            if t.isdigit() and int(t) in hari:
                await _jawab(t, "teks")
        except Exception as e:
            logging.error("pilih_hari teks: %s", repr(e))

    h_cb = _on_cb
    h_tx = _on_teks
    try:
        bot.add_event_handler(h_cb, events.CallbackQuery())
        bot.add_event_handler(h_tx, events.NewMessage())
    except Exception as e:
        logging.error("pilih_hari: gagal pasang handler: %s", repr(e))

    # ---- kirim tombol sebagai PESAN BIASA ----
    rows, buf = [], []
    for h in hari:
        buf.append(Button.inline("%d HARI" % h, "%s:%d" % (token, h)))
        if len(buf) == 2:
            rows.append(buf)
            buf = []
    if buf:
        rows.append(buf)

    terkirim = False
    for cara in ("respond", "kirim"):
        try:
            if cara == "respond":
                x = await event.respond(judul, buttons=rows)
            else:
                x = await bot.send_message(event.chat_id, judul, buttons=rows)
            if x is not None:
                terkirim = True
                break
        except Exception as e:
            logging.error("pilih_hari: kirim(%s) gagal: %s", cara, repr(e))
    if not terkirim:
        logging.error("pilih_hari: TOMBOL GAGAL DIKIRIM")
        await _kirim_pasti(event,
                           "❌ Bot gagal mengirim pilihan masa aktif.\n"
                           "Silakan ulangi dari menu.")
        return None

    logging.info("pilih_hari: tombol dikirim (token=%s, opsi=%s)", token, hari)

    try:
        nilai = await asyncio.wait_for(fut, timeout=timeout)
    except asyncio.TimeoutError:
        logging.info("pilih_hari: TIMEOUT setelah %ss", timeout)
        await _kirim_pasti(event,
                           "⏱️ Waktu habis (tidak ada pilihan masa aktif).\n"
                           "Silakan ulangi dari menu.")
        return None
    except asyncio.CancelledError:
        return None
    finally:
        _HARI_AKTIF.pop(token, None)
        for h in (h_cb, h_tx):
            try:
                bot.remove_event_handler(h)
            except Exception:
                pass

    try:
        v = int(nilai)
        return v if v in hari else None
    except Exception:
        return None


# ---------------- validasi input ----------------
def cek_username(teks):
	t = (teks or "").strip().lower()
	if not t:
		return False, "Username tidak boleh kosong."
	if not re.match(r"^[a-z0-9][a-z0-9_-]{2,19}$", t):
		return False, ("Username 3-20 karakter, hanya huruf/angka/underscore/"
		               "strip, tanpa spasi. Contoh: budi01")
	return True, ""


def cek_angka(teks, boleh_nol=True):
	t = (teks or "").strip().replace(".", "").replace(",", "")
	if not t.isdigit():
		return False, "Harus angka. Contoh: 0 (unlimited) atau 500"
	if not boleh_nol and int(t) < 1:
		return False, "Harus lebih dari 0."
	return True, ""


def sh_out(cmd, default=""):
	try:
		return subprocess.check_output(cmd, shell=True).decode("ascii", "ignore")
	except Exception:
		return default


def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])

# ---- VPN STORE: inisialisasi tabel database ----
try:
	from kyt import store_lib as _store
	_store.init_store()
except Exception as _e:
	logging.error("store init gagal: %s", _e)
