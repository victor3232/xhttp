from telethon import *
import datetime as DT
from telethon import *
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import logging
#usr/local/bin/kyt
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

exec(open("kyt/var.txt","r").read())
bot = TelegramClient("ddsdswl","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)


def _bersih_id(v):
	"""var.txt kadang ditulis ADMIN='"123"' -> ambil angkanya saja."""
	return str(v).strip().strip('"').strip("'").strip()


try:
	_x = sqlite3.connect("kyt/database.db")
	_c = _x.cursor()
	_c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
	_adm = _bersih_id(ADMIN)
	if _adm and not _c.execute("SELECT 1 FROM admin WHERE user_id=?", (_adm,)).fetchone():
		_c.execute("INSERT INTO admin (user_id) VALUES (?)", (_adm,))
	_x.commit()
	_x.close()
except Exception as _e:
	logging.error("init admin gagal: %s", _e)

def get_db():
	x = sqlite3.connect("kyt/database.db")
	x.row_factory = sqlite3.Row
	return x

def valid(id):
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [_bersih_id(v[0]) for v in x]
	return "true" if _bersih_id(id) in a else "false"

async def safe_send(event, text, buttons=None):
	"""Kirim menu: coba edit (kalau dari tombol), kalau tidak bisa -> reply.
	Menghindari MessageIdInvalidError saat /start atau /menu dikirim sebagai pesan baru."""
	try:
		x = await event.edit(text, buttons=buttons)
		if x is not None:
			return x
	except Exception:
		pass
	try:
		return await event.reply(text, buttons=buttons)
	except Exception:
		return None

async def safe_send_photo(event, gambar, caption, buttons=None):
	"""Kirim pesan dengan GAMBAR (biar /start tidak polosan).
	gambar = URL (catbox/qu.ax dll) atau path file lokal.
	Kalau gagal -> kirim teks saja."""
	if gambar:
		try:
			return await bot.send_file(event.chat_id, gambar,
			                           caption=caption, buttons=buttons)
		except Exception as e:
			logging.error("kirim gambar start gagal: %s", e)
	return await safe_send(event, caption, buttons)


def sh_out(cmd, default=""):
	"""Jalankan perintah shell. Kembalikan default kalau gagal
	(mis. file /etc/xray/city belum ada di VPS baru)."""
	try:
		return subprocess.check_output(cmd, shell=True).decode("ascii", "ignore")
	except Exception:
		return default


def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])

# ---- VPN STORE: inisialisasi tabel database ----
try:
	from kyt import store_lib as _store
	_store.init_store()
except Exception as _e:
	logging.error("store init gagal: %s", _e)
