from telethon import *
import datetime as DT
from telethon import *
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import asyncio
import logging
#usr/local/bin/kyt
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

exec(open("kyt/var.txt","r").read())

# ---- bersihkan tanda kutip sisa var.txt lama (DOMAIN='"x"' -> x) ----
for _nama in ("BOT_TOKEN", "ADMIN", "DOMAIN", "PUB", "HOST", "DUITKU_MERCHANT",
              "DUITKU_APIKEY"):
	try:
		_nilai = globals().get(_nama, "")
		if _nilai is not None:
			globals()[_nama] = str(_nilai).strip().strip('"').strip("'").strip()
	except Exception:
		pass

bot = TelegramClient("ddsdswl","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)


def _bersih_id(v):
	"""var.txt kadang ditulis ADMIN='"123"' -> ambil angkanya saja."""
	return str(v).strip().strip('"').strip("'").strip()


try:
	_x = sqlite3.connect("kyt/database.db")
	_c = _x.cursor()
	_c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
	_adm = _bersih_id(ADMIN)
	if _adm and not _c.execute("SELECT 1 FROM admin WHERE user_id=?", (_adm,)).fetchone():
		_c.execute("INSERT INTO admin (user_id) VALUES (?)", (_adm,))
	_x.commit()
	_x.close()
except Exception as _e:
	logging.error("init admin gagal: %s", _e)

def get_db():
	x = sqlite3.connect("kyt/database.db")
	x.row_factory = sqlite3.Row
	return x

def valid(id):
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [_bersih_id(v[0]) for v in x]
	return "true" if _bersih_id(id) in a else "false"

async def safe_send(event, text, buttons=None):
	"""Kirim menu: coba edit (kalau dari tombol), kalau tidak bisa -> reply.
	Menghindari MessageIdInvalidError saat /start atau /menu dikirim sebagai pesan baru.

	PENTING: pesan yang ADA GAMBARNYA (foto QRIS) tidak boleh di-edit,
	karena captionnya akan ketimpa menu (QR jadi nempel di menu)."""
	try:
		m = getattr(event, "message", None)
		if m is not None and getattr(m, "media", None) is not None:
			return await event.reply(text, buttons=buttons)
	except Exception:
		pass
	try:
		x = await event.edit(text, buttons=buttons)
		if x is not None:
			return x
	except Exception:
		pass
	try:
		return await event.reply(text, buttons=buttons)
	except Exception:
		return None

async def safe_send_photo(event, gambar, caption, buttons=None):
	"""Kirim pesan dengan GAMBAR (biar /start tidak polosan).
	gambar = path file lokal (diutamakan) atau URL.
	Kalau gagal -> kirim teks saja (tidak pernah error ke user)."""
	if gambar:
		try:
			return await bot.send_file(event.chat_id, gambar,
			                           caption=caption, buttons=buttons)
		except Exception as e:
			logging.error("kirim gambar start gagal (%s): %s", gambar, e)
			# kalau path lokal rusak, coba sekali lagi sebagai URL/apa adanya
			try:
				if not str(gambar).startswith(("http://", "https://")):
					return await bot.send_file(event.chat_id, str(gambar),
					                           caption=caption, buttons=buttons)
			except Exception as e2:
				logging.error("percobaan kedua gagal: %s", e2)
	return await safe_send(event, caption, buttons)


# ============================================================
#  INPUT DARI USER (pengganti bot.conversation berlapis)
#  Masalah lama: bot.conversation() dipakai 3x berturut-turut.
#  Telethon default exclusive=True -> kalau ada conversation lain
#  yang masih aktif di chat yang sama, muncul AlreadyInConversationError
#  dan bot DIAM tanpa pesan apa pun (ini yang bikin "stuck di Quota").
#  Helper di bawah: exclusive=False, ada timeout, dan SELALU
#  memberi pesan kalau gagal (tidak pernah diam).
# ============================================================
async def balas(event, teks, buttons=None):
	"""Kirim pesan yang pasti sampai (respond -> send_message)."""
	try:
		return await event.respond(teks, buttons=buttons)
	except Exception:
		pass
	try:
		return await bot.send_message(event.chat_id, teks, buttons=buttons)
	except Exception as e:
		logging.error("balas gagal: %s", e)
		return None


async def _kirim_pasti(event, teks):
	"""Kirim pesan lewat SEMUA jalur yang tersedia. Tidak pernah diam.

	Dulu: kalau event.respond() gagal (event sudah tidak valid setelah
	conversation), pesan TIDAK terkirim sama sekali -> bot terlihat DIAM.
	Sekarang dicoba: respond -> bot.send_message -> client.send_message
	(bangun ulang entity dari event.chat_id).
	"""
	for cara in ("respond", "kirim", "client"):
		try:
			if cara == "respond":
				x = await event.respond(teks)
				if x is not None:
					return x
			elif cara == "kirim":
				x = await bot.send_message(event.chat_id, teks)
				if x is not None:
					return x
			else:
				ent = await event.get_input_chat()
				x = await bot.send_message(ent, teks)
				if x is not None:
					return x
		except Exception as e:
			logging.error("_kirim_pasti[%s]: %s", cara, e)
	# usaha terakhir: tanpa tombol & tanpa event
	try:
		return await bot.send_message(int(event.chat_id), teks)
	except Exception as e:
		logging.error("_kirim_pasti[gagal total]: %s", e)
		return None


# ============================================================
#  ANTREAN INPUT PER-USER (TANPA bot.conversation)
#  Kenapa tidak pakai conversation lagi?
#   - conversation() Telethon menyimpan SATU set pending per chat.
#     Kalau dipakai berulang (username -> quota -> tombol hari),
#     pesan yang datang "nyasar" bisa masuk ke conversation yang
#     salah -> pertanyaan berikutnya (tombol hari) HILANG.
#   - Bot juga mengirim notifikasi ke chat yang sama (penjualan,
#     deposit, expired) -> ikut "terbaca" sebagai jawaban.
#  Solusi: setiap tanya() mendaftarkan SATU slot tunggu. Handler
#  global mengisi slot itu HANYA untuk pesan/tombol dari user yang
#  benar-benar sedang ditanya. Tidak ada state yang bertabrakan.
# ============================================================
_TUNGGU = {}          # chat_id -> dict(fut, jenis, uid)
_LOCK_TUNGGU = asyncio.Lock()


def _jawab_tunggu(chat_id, jenis, nilai, uid=None):
    """Isi slot tunggu user (dipanggil handler global)."""
    d = _TUNGGU.get(str(chat_id))
    if not d or d["jenis"] != jenis:
        return False
    if d["fut"].done():
        return False
    # hanya dari user yang sedang ditanya
    if d.get("uid") is not None:
        if uid is None or str(uid) != str(d["uid"]):
            return False
    try:
        d["fut"].set_result(nilai)
        return True
    except Exception:
        return False


async def tanya(event, pertanyaan, timeout=180, tombol=None, validasi=None,
                boleh_batal=True, pakai_strip=True):
    """Tanya SATU hal ke user (TANPA bot.conversation).

    tombol  : list Button -> tunggu tombol (return data callback)
    validasi: fungsi(teks) -> (ok, pesan_error)
    pakai_strip: True (default) = '-' berarti BATAL.
                 False = '-' diteruskan sebagai nilai sah.
    Return: teks jawaban, data tombol, atau None kalau gagal/batal.

    Fungsi ini TIDAK PERNAH diam: setiap kegagalan diberi pesan.
    """
    tolak_strip = (lambda t: pakai_strip and t == "-")
    chat = str(event.chat_id)
    uid = None
    try:
        uid = str(event.sender_id)
    except Exception:
        pass

    pesan_validasi = ""
    for _ke in range(3):
        # ---- daftarkan slot tunggu ----
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.get_event_loop()
        fut = loop.create_future()
        jenis = "tombol" if tombol else "teks"
        async with _LOCK_TUNGGU:
            lama = _TUNGGU.get(chat)
            if lama and not lama["fut"].done():
                # ada tanya lain yang belum selesai di chat ini
                try:
                    lama["fut"].cancel()
                except Exception:
                    pass
            _TUNGGU[chat] = {"fut": fut, "jenis": jenis, "uid": uid}

        # ---- kirim pertanyaan (dengan tombol kalau ada) ----
        terkirim = False
        for cara in ("respond", "kirim"):
            try:
                if cara == "respond":
                    x = await event.respond(pertanyaan, buttons=tombol)
                else:
                    x = await bot.send_message(event.chat_id, pertanyaan,
                                               buttons=tombol)
                if x is not None:
                    terkirim = True
                    break
            except Exception as e:
                logging.error("tanya: kirim pertanyaan(%s) gagal: %s", cara,
                              repr(e))
        if not terkirim:
            async with _LOCK_TUNGGU:
                _TUNGGU.pop(chat, None)
            await _kirim_pasti(event,
                               "❌ Bot gagal mengirim pertanyaan.\n"
                               "Silakan ulangi dari menu.")
            return None

        # ---- tunggu jawaban ----
        try:
            nilai = await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.CancelledError:
            # dibatalkan karena user mengirim perintah lain (/menu dsb)
            async with _LOCK_TUNGGU:
                if _TUNGGU.get(chat, {}).get("fut") is fut:
                    _TUNGGU.pop(chat, None)
            return None
        except asyncio.TimeoutError:
            async with _LOCK_TUNGGU:
                if _TUNGGU.get(chat, {}).get("fut") is fut:
                    _TUNGGU.pop(chat, None)
            await _kirim_pasti(event,
                               "⏱️ Waktu habis. Silakan ulangi dari menu.")
            return None
        finally:
            async with _LOCK_TUNGGU:
                if _TUNGGU.get(chat, {}).get("fut") is fut:
                    _TUNGGU.pop(chat, None)

        if tombol:
            # nilai = data tombol
            try:
                return str(nilai)
            except Exception:
                return None

        teks = (nilai or "").strip()
        if not teks:
            pertanyaan = "❓ Jawaban kosong. " + pertanyaan
            continue
        if tolak_strip(teks) and boleh_batal:
            await _kirim_pasti(event, "Dibatalkan.")
            return None
        if validasi is None:
            return teks
        try:
            ok, pesan = validasi(teks)
        except Exception:
            ok, pesan = True, ""
        if ok:
            return teks
        pesan_validasi = pesan
        pertanyaan = "❌ **%s**\n\n%s" % (pesan, pertanyaan)

    await _kirim_pasti(event, "❌ Input masih salah: **%s**\n\n"
                              "Silakan ulangi dari menu."
                       % (pesan_validasi or "tidak valid"))
    return None


# ============================================================
#  HANDLER GLOBAL: mengisi antrean jawaban
#  Dipasang di __main__ setelah semua modul dimuat, supaya TIDAK
#  bentrok dengan handler modul lain.
# ============================================================
async def tunggu_pesan(event, pertanyaan, timeout=300, boleh_batal=True):
    """Tunggu user mengirim PESAN (bisa berisi file/foto). Return event pesan.

    Dipakai untuk upload backup / foto /start. Memakai antrean yang sama
    dengan tanya() -> TIDAK memakai bot.conversation.
    """
    chat = str(event.chat_id)
    uid = None
    try:
        uid = str(event.sender_id)
    except Exception:
        pass

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.get_event_loop()
    fut = loop.create_future()
    async with _LOCK_TUNGGU:
        lama = _TUNGGU.get(chat)
        if lama and not lama["fut"].done():
            try:
                lama["fut"].cancel()
            except Exception:
                pass
        _TUNGGU[chat] = {"fut": fut, "jenis": "pesan", "uid": uid}

    terkirim = False
    for cara in ("respond", "kirim"):
        try:
            if cara == "respond":
                x = await event.respond(pertanyaan)
            else:
                x = await bot.send_message(event.chat_id, pertanyaan)
            if x is not None:
                terkirim = True
                break
        except Exception as e:
            logging.error("tunggu_pesan: kirim(%s) gagal: %s", cara, repr(e))
    if not terkirim:
        async with _LOCK_TUNGGU:
            _TUNGGU.pop(chat, None)
        await _kirim_pasti(event, "❌ Bot gagal mengirim pertanyaan.\n"
                                  "Silakan ulangi dari menu.")
        return None

    try:
        msg = await asyncio.wait_for(fut, timeout=timeout)
    except asyncio.CancelledError:
        async with _LOCK_TUNGGU:
            if _TUNGGU.get(chat, {}).get("fut") is fut:
                _TUNGGU.pop(chat, None)
        return None
    except asyncio.TimeoutError:
        await _kirim_pasti(event, "⏱️ Waktu habis. Silakan ulangi dari menu.")
        return None
    finally:
        async with _LOCK_TUNGGU:
            if _TUNGGU.get(chat, {}).get("fut") is fut:
                _TUNGGU.pop(chat, None)

    if boleh_batal and (getattr(msg, "raw_text", "") or "").strip() == "-":
        await _kirim_pasti(event, "Dibatalkan.")
        return None
    return msg


def pasang_handler_tanya():
    """Daftarkan handler NewMessage & CallbackQuery untuk tanya()."""

    @bot.on(events.NewMessage())
    async def _tanya_teks(event):
        # hanya untuk chat yang sedang ditunggu
        try:
            chat = str(event.chat_id)
        except Exception:
            return
        d = _TUNGGU.get(chat)
        if not d:
            return
        try:
            uid = event.sender_id
        except Exception:
            uid = None
        teks = (event.raw_text or "").strip()
        # user mengirim PERINTAH (mis. /menu) -> lepaskan pertanyaan lama
        # supaya perintahnya bisa jalan, tidak "tertelan" sebagai jawaban.
        if teks.startswith("/"):
            try:
                d["fut"].cancel()
            except Exception:
                pass
            return
        if d["jenis"] == "pesan":
            # pemanggil ingin objek pesannya (upload file / foto)
            _jawab_tunggu(chat, "pesan", event, uid)
            return
        if d["jenis"] != "teks":
            return
        _jawab_tunggu(chat, "teks", teks, uid)

    @bot.on(events.CallbackQuery())
    async def _tanya_tombol(event):
        try:
            chat = str(event.chat_id)
        except Exception:
            return
        d = _TUNGGU.get(chat)
        if not d or d["jenis"] != "tombol":
            return
        try:
            await event.answer()
        except Exception:
            pass
        try:
            uid = event.sender_id
        except Exception:
            uid = None
        data = event.data.decode("ascii", "ignore") if event.data else ""
        _jawab_tunggu(chat, "tombol", data, uid)

    logging.info("handler tanya() terpasang (tanpa conversation)")
    return True


async def pilih_hari(event, judul="**Pilih Masa Aktif**", hari=(3, 7, 30)):
	"""Tombol masa aktif. Return int hari atau None.

	PENTING: kalau penekanan tombol tidak terbaca, JANGAN diam.
	Fallback: tanya manual lewat teks ("3" / "7" / "30").
	"""
	rows, buf = [], []
	for h in hari:
		buf.append(Button.inline("%d HARI" % h, str(h)))
		if len(buf) == 2:
			rows.append(buf)
			buf = []
	if buf:
		rows.append(buf)
	try:
		d = await tanya(event, judul, tombol=rows)
	except Exception as e:
		logging.error("pilih_hari gagal: %s", repr(e))
		d = None
	try:
		v = int(d)
		if v in hari:
			return v
	except Exception:
		pass

	# PENTING: jangan tanya ulang dengan teks di sini.
	# Itu menambah satu conversation lagi dan bisa membuat alur
	# makin tersangkut. tanya() sudah pasti memberi pesan ke user.
	return None


# ---------------- validasi input ----------------
def cek_username(teks):
	t = (teks or "").strip().lower()
	if not t:
		return False, "Username tidak boleh kosong."
	if not re.match(r"^[a-z0-9][a-z0-9_-]{2,19}$", t):
		return False, ("Username 3-20 karakter, hanya huruf/angka/underscore/"
		               "strip, tanpa spasi. Contoh: budi01")
	return True, ""


def cek_angka(teks, boleh_nol=True):
	t = (teks or "").strip().replace(".", "").replace(",", "")
	if not t.isdigit():
		return False, "Harus angka. Contoh: 0 (unlimited) atau 500"
	if not boleh_nol and int(t) < 1:
		return False, "Harus lebih dari 0."
	return True, ""


def sh_out(cmd, default=""):
	try:
		return subprocess.check_output(cmd, shell=True).decode("ascii", "ignore")
	except Exception:
		return default


def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])

# ---- VPN STORE: inisialisasi tabel database ----
try:
	from kyt import store_lib as _store
	_store.init_store()
except Exception as _e:
	logging.error("store init gagal: %s", _e)
