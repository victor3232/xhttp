from telethon import *
import datetime as DT
from telethon import *
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import asyncio
import logging
#usr/local/bin/kyt
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

exec(open("kyt/var.txt","r").read())

# ---- bersihkan tanda kutip sisa var.txt lama (DOMAIN='"x"' -> x) ----
for _nama in ("BOT_TOKEN", "ADMIN", "DOMAIN", "PUB", "HOST", "DUITKU_MERCHANT",
              "DUITKU_APIKEY"):
	try:
		_nilai = globals().get(_nama, "")
		if _nilai is not None:
			globals()[_nama] = str(_nilai).strip().strip('"').strip("'").strip()
	except Exception:
		pass

bot = TelegramClient("ddsdswl","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)


def _bersih_id(v):
	"""var.txt kadang ditulis ADMIN='"123"' -> ambil angkanya saja."""
	return str(v).strip().strip('"').strip("'").strip()


try:
	_x = sqlite3.connect("kyt/database.db")
	_c = _x.cursor()
	_c.execute("CREATE TABLE IF NOT EXISTS admin (user_id)")
	_adm = _bersih_id(ADMIN)
	if _adm and not _c.execute("SELECT 1 FROM admin WHERE user_id=?", (_adm,)).fetchone():
		_c.execute("INSERT INTO admin (user_id) VALUES (?)", (_adm,))
	_x.commit()
	_x.close()
except Exception as _e:
	logging.error("init admin gagal: %s", _e)

def get_db():
	x = sqlite3.connect("kyt/database.db")
	x.row_factory = sqlite3.Row
	return x

def valid(id):
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [_bersih_id(v[0]) for v in x]
	return "true" if _bersih_id(id) in a else "false"

async def safe_send(event, text, buttons=None):
	"""Kirim menu: coba edit (kalau dari tombol), kalau tidak bisa -> reply.
	Menghindari MessageIdInvalidError saat /start atau /menu dikirim sebagai pesan baru.

	PENTING: pesan yang ADA GAMBARNYA (foto QRIS) tidak boleh di-edit,
	karena captionnya akan ketimpa menu (QR jadi nempel di menu)."""
	try:
		m = getattr(event, "message", None)
		if m is not None and getattr(m, "media", None) is not None:
			return await event.reply(text, buttons=buttons)
	except Exception:
		pass
	try:
		x = await event.edit(text, buttons=buttons)
		if x is not None:
			return x
	except Exception:
		pass
	try:
		return await event.reply(text, buttons=buttons)
	except Exception:
		return None

async def safe_send_photo(event, gambar, caption, buttons=None):
	"""Kirim pesan dengan GAMBAR (biar /start tidak polosan).
	gambar = path file lokal (diutamakan) atau URL.
	Kalau gagal -> kirim teks saja (tidak pernah error ke user)."""
	if gambar:
		try:
			return await bot.send_file(event.chat_id, gambar,
			                           caption=caption, buttons=buttons)
		except Exception as e:
			logging.error("kirim gambar start gagal (%s): %s", gambar, e)
			# kalau path lokal rusak, coba sekali lagi sebagai URL/apa adanya
			try:
				if not str(gambar).startswith(("http://", "https://")):
					return await bot.send_file(event.chat_id, str(gambar),
					                           caption=caption, buttons=buttons)
			except Exception as e2:
				logging.error("percobaan kedua gagal: %s", e2)
	return await safe_send(event, caption, buttons)


# ============================================================
#  INPUT DARI USER (pengganti bot.conversation berlapis)
#  Masalah lama: bot.conversation() dipakai 3x berturut-turut.
#  Telethon default exclusive=True -> kalau ada conversation lain
#  yang masih aktif di chat yang sama, muncul AlreadyInConversationError
#  dan bot DIAM tanpa pesan apa pun (ini yang bikin "stuck di Quota").
#  Helper di bawah: exclusive=False, ada timeout, dan SELALU
#  memberi pesan kalau gagal (tidak pernah diam).
# ============================================================
async def balas(event, teks, buttons=None):
	"""Kirim pesan yang pasti sampai (respond -> send_message)."""
	try:
		return await event.respond(teks, buttons=buttons)
	except Exception:
		pass
	try:
		return await bot.send_message(event.chat_id, teks, buttons=buttons)
	except Exception as e:
		logging.error("balas gagal: %s", e)
		return None


async def tanya(event, pertanyaan, timeout=180, tombol=None, validasi=None,
                boleh_batal=True):
	"""Tanya SATU hal ke user.

	tombol  : list Button -> tunggu tombol (return data callback)
	validasi: fungsi(teks) -> (ok, pesan_error)
	Return: teks jawaban, data tombol, atau None kalau gagal/batal.
	"""
	chat = event.chat_id
	tanya_ke = 0
	while tanya_ke < 3:
		tanya_ke += 1
		try:
			async with bot.conversation(chat, timeout=timeout,
			                            exclusive=False) as conv:
				await conv.send_message(pertanyaan, buttons=tombol)
				if tombol:
					ev = await conv.wait_event(events.CallbackQuery,
					                           timeout=timeout)
					try:
						await ev.answer()
					except Exception:
						pass
					return ev.data.decode("ascii", "ignore")
				msg = await conv.get_response(timeout=timeout)
				teks = (msg.raw_text or "").strip()
		except asyncio.TimeoutError:
			await balas(event, "⏱️ Waktu habis. Silakan ulangi dari menu.")
			return None
		except Exception as e:
			logging.error("tanya gagal [%s]: %s", (pertanyaan or "")[:40], e)
			await balas(event, "❌ Gagal memproses input.\n`%s`\n\n"
			                   "Silakan ulangi dari menu." % e)
			return None

		if teks == "-" and boleh_batal:
			await balas(event, "Dibatalkan.")
			return None
		if validasi is None:
			return teks
		try:
			ok, pesan = validasi(teks)
		except Exception:
			ok, pesan = True, ""
		if ok:
			return teks
		pertanyaan = "❌ **%s**\n\n%s" % (pesan, pertanyaan)
	return None


async def pilih_hari(event, judul="**Pilih Masa Aktif**", hari=(3, 7, 30)):
	"""Tombol masa aktif. Return int hari atau None."""
	rows, buf = [], []
	for h in hari:
		buf.append(Button.inline("%d HARI" % h, str(h)))
		if len(buf) == 2:
			rows.append(buf)
			buf = []
	if buf:
		rows.append(buf)
	d = await tanya(event, judul, tombol=rows)
	try:
		v = int(d)
		return v if v in hari else None
	except Exception:
		return None


# ---------------- validasi input ----------------
def cek_username(teks):
	t = (teks or "").strip().lower()
	if not t:
		return False, "Username tidak boleh kosong."
	if not re.match(r"^[a-z0-9][a-z0-9_-]{2,19}$", t):
		return False, ("Username 3-20 karakter, hanya huruf/angka/underscore/"
		               "strip, tanpa spasi. Contoh: budi01")
	return True, ""


def cek_angka(teks, boleh_nol=True):
	t = (teks or "").strip().replace(".", "").replace(",", "")
	if not t.isdigit():
		return False, "Harus angka. Contoh: 0 (unlimited) atau 500"
	if not boleh_nol and int(t) < 1:
		return False, "Harus lebih dari 0."
	return True, ""


def sh_out(cmd, default=""):
	try:
		return subprocess.check_output(cmd, shell=True).decode("ascii", "ignore")
	except Exception:
		return default


def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])

# ---- VPN STORE: inisialisasi tabel database ----
try:
	from kyt import store_lib as _store
	_store.init_store()
except Exception as _e:
	logging.error("store init gagal: %s", _e)
