# -*- coding: utf-8 -*-
# ============================================================
#  node_lib.py - daftar server (multi-node) untuk BOT
#
#  Bot berdiri sendiri (tidak membaca database web).
#  Server 1 = rumah (VPS tempat bot dipasang).
#  Server 2, 3, ... = VPS lain yang ditambahkan lewat API Key.
#
#  Semua komunikasi ke node memakai agent HTTPS + HMAC,
#  formatnya sama dengan panel web.
# ============================================================
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import ssl
import time
import urllib.error
import urllib.request
from pathlib import Path

DB_PATH = "kyt/database.db"
KEY_FILE = Path("/etc/kyt-bot-node.key")

# Produk yang dijual bot. SS/L2TP sengaja tidak dipakai.
TIPE_JUAL = ("ssh", "vmess", "vless", "trojan")
HARI_JUAL = (3, 7, 30)
TIPE_LABEL = {
    "ssh": "SSH/OVPN",
    "vmess": "VMess",
    "vless": "VLESS",
    "trojan": "Trojan",
}
HARGA_DEFAULT = {3: 1000, 7: 2500, 30: 10000}

# service/protocol yang dipahami agent node
AGENT_MAP = {
    "ssh": ("ssh", ""),
    "vmess": ("xray", "vmess"),
    "vless": ("xray", "vless"),
    "trojan": ("xray", "trojan"),
}


# ---------------- database ----------------
def db():
    x = sqlite3.connect(DB_PATH, timeout=20)
    x.row_factory = sqlite3.Row
    return x


def _kolom(c, tabel):
    try:
        return [r[1] for r in c.execute("PRAGMA table_info(%s)" % tabel).fetchall()]
    except Exception:
        return []


def _tambah_kolom(c, tabel, nama, definisi):
    if nama not in _kolom(c, tabel):
        try:
            c.execute("ALTER TABLE %s ADD COLUMN %s %s" % (tabel, nama, definisi))
        except Exception:
            pass


def _harga_global(tipe, hari):
    """Ambil harga dari tabel produk lama sebagai titik awal."""
    try:
        x = db()
        r = x.execute("SELECT harga FROM produk WHERE tipe=? AND hari=? LIMIT 1",
                      (tipe, hari)).fetchone()
        x.close()
        if r and int(r["harga"]) > 0:
            return int(r["harga"])
    except Exception:
        pass
    return int(HARGA_DEFAULT.get(hari, 10000))


def seed_products(server_id, sumber_id=0):
    """Isi 4 tipe x 3/7/30 hari untuk sebuah server.

    sumber_id > 0 -> salin harga/limit dari server itu.
    sumber_id = 0 -> pakai harga produk lama / default.
    """
    x = db()
    c = x.cursor()
    for tipe in TIPE_JUAL:
        for hari in HARI_JUAL:
            harga = _harga_global(tipe, hari)
            quota = "0"
            iplimit = "0"
            if sumber_id and int(sumber_id) != int(server_id):
                r = x.execute(
                    "SELECT harga,quota,iplimit FROM server_produk "
                    "WHERE server_id=? AND tipe=? AND hari=?",
                    (int(sumber_id), tipe, hari)).fetchone()
                if r:
                    harga = int(r["harga"])
                    quota = str(r["quota"])
                    iplimit = str(r["iplimit"])
            c.execute(
                "INSERT OR IGNORE INTO server_produk"
                "(server_id,tipe,hari,harga,quota,iplimit,aktif)"
                " VALUES(?,?,?,?,?,?,1)",
                (int(server_id), tipe, int(hari), int(harga), quota, iplimit))
    x.commit()
    x.close()


def init_nodes():
    """Buat tabel server + migrasi pesanan lama. Aman dijalankan berulang."""
    x = db()
    c = x.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS server(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        base_url TEXT NOT NULL DEFAULT '',
        api_key TEXT NOT NULL DEFAULT '',
        secret_enc TEXT NOT NULL DEFAULT '',
        is_home INTEGER NOT NULL DEFAULT 0,
        premium_enabled INTEGER NOT NULL DEFAULT 1,
        free_enabled INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        sort INTEGER NOT NULL DEFAULT 10,
        max_slots INTEGER NOT NULL DEFAULT 0,
        last_seen INTEGER NOT NULL DEFAULT 0,
        last_version TEXT NOT NULL DEFAULT '',
        last_error TEXT NOT NULL DEFAULT '',
        accounts_json TEXT NOT NULL DEFAULT '{}',
        dns_json TEXT NOT NULL DEFAULT '{}',
        created TEXT NOT NULL DEFAULT '')""")
    c.execute("""CREATE TABLE IF NOT EXISTS server_produk(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        server_id INTEGER NOT NULL,
        tipe TEXT NOT NULL,
        hari INTEGER NOT NULL,
        harga INTEGER NOT NULL,
        quota TEXT NOT NULL DEFAULT '0',
        iplimit TEXT NOT NULL DEFAULT '0',
        aktif INTEGER NOT NULL DEFAULT 1,
        UNIQUE(server_id,tipe,hari))""")

    for nama, definisi in (
        ("base_url", "TEXT NOT NULL DEFAULT ''"),
        ("api_key", "TEXT NOT NULL DEFAULT ''"),
        ("secret_enc", "TEXT NOT NULL DEFAULT ''"),
        ("is_home", "INTEGER NOT NULL DEFAULT 0"),
        ("premium_enabled", "INTEGER NOT NULL DEFAULT 1"),
        ("free_enabled", "INTEGER NOT NULL DEFAULT 0"),
        ("active", "INTEGER NOT NULL DEFAULT 1"),
        ("sort", "INTEGER NOT NULL DEFAULT 10"),
        ("max_slots", "INTEGER NOT NULL DEFAULT 0"),
        ("last_seen", "INTEGER NOT NULL DEFAULT 0"),
        ("last_version", "TEXT NOT NULL DEFAULT ''"),
        ("last_error", "TEXT NOT NULL DEFAULT ''"),
        ("accounts_json", "TEXT NOT NULL DEFAULT '{}'"),
        ("dns_json", "TEXT NOT NULL DEFAULT '{}'"),
        ("created", "TEXT NOT NULL DEFAULT ''"),
    ):
        _tambah_kolom(c, "server", nama, definisi)

    # kolom server pada pesanan lama
    _tambah_kolom(c, "pesanan", "server_id", "INTEGER DEFAULT 0")
    _tambah_kolom(c, "pesanan", "server_code", "TEXT DEFAULT ''")
    _tambah_kolom(c, "pesanan", "server_name", "TEXT DEFAULT ''")

    home = c.execute("SELECT * FROM server WHERE is_home=1 ORDER BY id LIMIT 1").fetchone()
    if not home:
        # kalau sudah ada baris bernama 'home', jadikan rumah
        home = c.execute("SELECT * FROM server WHERE code='home' ORDER BY id LIMIT 1").fetchone()
        if home:
            c.execute("UPDATE server SET is_home=1 WHERE id=?", (home["id"],))
        else:
            cur = c.execute(
                "INSERT INTO server(code,name,base_url,is_home,active,sort,created)"
                " VALUES(?,?,?,?,?,?,?)",
                ("home", "VPS Utama", "", 1, 1, 0,
                 time.strftime("%Y-%m-%d %H:%M:%S")))
            home_id = int(cur.lastrowid)
            c.execute("UPDATE server SET is_home=1 WHERE id=?", (home_id,))
            home = c.execute("SELECT * FROM server WHERE id=?", (home_id,)).fetchone()
    home_id = int(home["id"])

    # Kalau agent dipasang di VPS ini, otomatis hubungkan server rumah.
    if not str(home["base_url"] or "").strip():
        try:
            conf = json.load(open("/etc/kyt-node/agent.json"))
            dom = str(conf.get("domain") or "").strip()
            if not dom:
                try:
                    dom = open("/etc/xray/domain").read().strip()
                except Exception:
                    dom = ""
            if dom and conf.get("api_key") and conf.get("secret"):
                url = "https://%s:%s" % (dom, conf.get("port") or 8787)
                c.execute("UPDATE server SET base_url=?, api_key=?, secret_enc=?"
                          " WHERE id=?",
                          (url, conf.get("api_key"),
                           encrypt_secret(conf.get("secret")), home_id))
        except Exception:
            pass

    # pesanan lama dianggap milik rumah
    try:
        c.execute(
            "UPDATE pesanan SET server_id=?, server_code=?, server_name=? "
            "WHERE server_id IS NULL OR server_id=0",
            (home_id, str(home["code"]), str(home["name"])))
    except Exception:
        pass

    x.commit()
    x.close()

    ids = [int(r["id"]) for r in _rows("SELECT id FROM server ORDER BY id")]
    for sid in ids:
        seed_products(sid, sumber_id=(home_id if sid != home_id else 0))
    return home_id


def _rows(sql, params=()):
    x = db()
    try:
        return x.execute(sql, params).fetchall()
    finally:
        x.close()


# ---------------- enkripsi secret ----------------
def _fernet():
    from cryptography.fernet import Fernet
    try:
        key = KEY_FILE.read_bytes().strip()
    except FileNotFoundError:
        key = Fernet.generate_key()
        KEY_FILE.write_bytes(key + b"\n")
        try:
            os.chmod(KEY_FILE, 0o600)
        except Exception:
            pass
    return Fernet(key)


def encrypt_secret(secret):
    if not secret:
        return ""
    return _fernet().encrypt(str(secret).encode("utf-8")).decode("ascii")


def decrypt_secret(token):
    if not token:
        return ""
    return _fernet().decrypt(str(token).encode("ascii")).decode("utf-8")


# ---------------- daftar server ----------------
def servers(only_active=False):
    sql = "SELECT * FROM server"
    if only_active:
        sql += " WHERE active=1"
    sql += " ORDER BY is_home DESC, sort, id"
    return _rows(sql)


def server_by_id(sid):
    r = _rows("SELECT * FROM server WHERE id=?", (int(sid),))
    return r[0] if r else None


def home_server():
    r = _rows("SELECT * FROM server WHERE is_home=1 ORDER BY id LIMIT 1")
    if r:
        return r[0]
    r = _rows("SELECT * FROM server ORDER BY id LIMIT 1")
    return r[0] if r else None


def _kode_unik(code, sid=0):
    code = re.sub(r"[^A-Za-z0-9_-]", "-", str(code or "")).strip("-")[:40]
    if not code:
        code = "node"
    asal = code
    n = 2
    while True:
        r = _rows("SELECT id FROM server WHERE code=? AND id<>?", (code, int(sid or 0)))
        if not r:
            return code
        code = "%s-%d" % (asal, n)
        n += 1


def add_server(name, base_url, api_key, secret, code="", premium=1, free=0,
               max_slots=0, sort=10):
    home = home_server()
    sid_sumber = int(home["id"]) if home else 0
    code = _kode_unik(code or name)
    x = db()
    try:
        cur = x.execute(
            "INSERT INTO server(code,name,base_url,api_key,secret_enc,"
            "premium_enabled,free_enabled,active,sort,max_slots,created)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (code, str(name)[:80], str(base_url).rstrip("/"), str(api_key),
             encrypt_secret(secret), int(bool(premium)), int(bool(free)), 1,
             int(sort), int(max_slots), time.strftime("%Y-%m-%d %H:%M:%S")))
        sid = int(cur.lastrowid)
        x.commit()
    finally:
        x.close()
    seed_products(sid, sumber_id=sid_sumber)
    return sid


def update_server(sid, **kw):
    izin = {"name", "base_url", "api_key", "code", "premium_enabled",
            "free_enabled", "active", "sort", "max_slots", "is_home"}
    setar, nilai = [], []
    for k, v in kw.items():
        if k == "secret":
            setar.append("secret_enc=?")
            nilai.append(encrypt_secret(v))
        elif k in izin:
            if k == "base_url":
                v = str(v).rstrip("/")
            if k == "code":
                v = _kode_unik(v, sid)
            setar.append("%s=?" % k)
            nilai.append(v)
    if not setar:
        return False
    nilai.append(int(sid))
    x = db()
    try:
        x.execute("UPDATE server SET %s WHERE id=?" % ",".join(setar), nilai)
        x.commit()
        return True
    finally:
        x.close()


def delete_server(sid):
    s = server_by_id(sid)
    if not s:
        return False, "Server tidak ada."
    if int(s["is_home"] or 0) == 1:
        return False, "Server utama tidak boleh dihapus."
    x = db()
    try:
        x.execute("DELETE FROM server_produk WHERE server_id=?", (int(sid),))
        x.execute("DELETE FROM server WHERE id=?", (int(sid),))
        x.commit()
        return True, "Server dihapus. Akun di VPS tetap aman."
    finally:
        x.close()


def set_home(sid):
    """Jadikan sebuah server sebagai rumah."""
    s = server_by_id(sid)
    if not s:
        return False, "Server tidak ada."
    x = db()
    try:
        x.execute("UPDATE server SET is_home=0")
        x.execute("UPDATE server SET is_home=1, active=1 WHERE id=?", (int(sid),))
        x.commit()
        return True, "Server utama diganti."
    finally:
        x.close()


# ---------------- produk per server ----------------
def server_products(sid, only_active=False):
    sql = "SELECT * FROM server_produk WHERE server_id=?"
    if only_active:
        sql += " AND aktif=1"
    sql += " ORDER BY CASE tipe WHEN 'ssh' THEN 1 WHEN 'vmess' THEN 2 WHEN 'vless' THEN 3 WHEN 'trojan' THEN 4 ELSE 9 END, hari"
    return _rows(sql, (int(sid),))


def server_product(sid, tipe, hari):
    r = _rows("SELECT * FROM server_produk WHERE server_id=? AND tipe=? AND hari=?",
              (int(sid), str(tipe), int(hari)))
    return r[0] if r else None


def set_server_product(sid, tipe, hari, harga=None, quota=None, iplimit=None,
                       aktif=None):
    s = server_by_id(sid)
    if not s:
        return False, "Server tidak ada."
    if tipe not in TIPE_JUAL or int(hari) not in HARI_JUAL:
        return False, "Produk tidak dikenal."
    x = db()
    try:
        x.execute(
            "INSERT OR IGNORE INTO server_produk(server_id,tipe,hari,harga,quota,iplimit,aktif)"
            " VALUES(?,?,?,?,?,?,1)",
            (int(sid), tipe, int(hari), int(_harga_global(tipe, hari)), "0", "0"))
        setar, nilai = [], []
        if harga is not None:
            setar.append("harga=?")
            nilai.append(max(0, int(harga)))
        if quota is not None:
            setar.append("quota=?")
            nilai.append(str(max(0, int(quota))))
        if iplimit is not None:
            setar.append("iplimit=?")
            nilai.append(str(max(0, min(100, int(iplimit)))))
        if aktif is not None:
            setar.append("aktif=?")
            nilai.append(1 if aktif else 0)
        if setar:
            nilai += [int(sid), tipe, int(hari)]
            x.execute("UPDATE server_produk SET %s WHERE server_id=? AND tipe=? AND hari=?"
                      % ",".join(setar), nilai)
        x.commit()
        return True, "Produk disimpan."
    finally:
        x.close()


def copy_products(dari_sid, ke_sid):
    dari = server_products(dari_sid)
    if not dari:
        return False, "Server sumber belum punya produk."
    for p in dari:
        set_server_product(ke_sid, p["tipe"], int(p["hari"]), int(p["harga"]),
                           int(p["quota"] or 0), int(p["iplimit"] or 0),
                           int(p["aktif"] or 0))
    return True, "Produk disalin dari node %s." % dari_sid


def produk_tersedia(sid):
    """Tipe yang punya minimal satu produk aktif."""
    out = []
    for tipe in TIPE_JUAL:
        if _rows("SELECT 1 FROM server_produk WHERE server_id=? AND tipe=? AND aktif=1 LIMIT 1",
                 (int(sid), tipe)):
            out.append(tipe)
    return out


# ---------------- HTTP agent ----------------
class NodeError(Exception):
    pass


def _perbarui(sid, **kw):
    if not kw:
        return
    setar = ",".join("%s=?" % k for k in kw)
    nilai = list(kw.values()) + [int(sid)]
    x = db()
    try:
        x.execute("UPDATE server SET %s WHERE id=?" % setar, nilai)
        x.commit()
    except Exception:
        pass
    finally:
        x.close()


def node_request(server, method, path, payload=None, timeout=20,
                 idempotency_key=""):
    """Panggil agent node dengan API Key + HMAC (sama seperti web)."""
    base = str(server["base_url"] or "").rstrip("/")
    if not base.startswith("https://"):
        raise NodeError("URL agent harus https://")
    secret = decrypt_secret(server["secret_enc"])
    if not secret:
        raise NodeError("Secret server belum diisi.")
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8") \
        if payload is not None else b""
    ts = str(int(time.time()))
    nonce = secrets.token_hex(16)
    digest = hashlib.sha256(body).hexdigest()
    canonical = "\n".join([method, path, ts, nonce, digest])
    signature = hmac.new(secret.encode("utf-8"), canonical.encode("utf-8"),
                         hashlib.sha256).hexdigest()
    headers = {
        "X-Kyt-Api-Key": str(server["api_key"] or ""),
        "X-Kyt-Node": str(server["code"] or ""),
        "X-Kyt-Timestamp": ts,
        "X-Kyt-Nonce": nonce,
        "X-Kyt-Signature": signature,
        "Content-Type": "application/json",
        "User-Agent": "kyt-bot-node/2.0",
    }
    if idempotency_key:
        headers["Idempotency-Key"] = str(idempotency_key)[:128]
    req = urllib.request.Request(base + path,
                                 data=body if method != "GET" else None,
                                 method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout,
                                    context=ssl.create_default_context()) as resp:
            raw = resp.read().decode("utf-8", "replace")
            data = json.loads(raw or "{}")
            _perbarui(int(server["id"]), last_seen=int(time.time()), last_error="",
                      last_version=str(data.get("version") or "")[:30])
            return data
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace")
        try:
            data = json.loads(raw or "{}")
        except Exception:
            data = {}
        pesan = str(data.get("error") or ("HTTP %s" % exc.code))
        _perbarui(int(server["id"]), last_error=pesan[:200])
        raise NodeError(pesan)
    except urllib.error.URLError as exc:
        pesan = "tidak bisa menghubungi node: %s" % (getattr(exc, "reason", exc),)
        _perbarui(int(server["id"]), last_error=pesan[:200])
        raise NodeError(pesan)
    except Exception as exc:
        pesan = "gagal memanggil node: %s" % (exc,)
        _perbarui(int(server["id"]), last_error=pesan[:200])
        raise NodeError(pesan)


def test_credentials(base_url, api_key, secret, code="test", timeout=12):
    """Tes koneksi sebelum server disimpan (tanpa menulis DB)."""
    sementara = {
        "id": 0, "code": code or "test", "base_url": str(base_url).rstrip("/"),
        "api_key": api_key, "secret_enc": encrypt_secret(secret),
    }
    # node_request akan mencoba UPDATE server id=0; aman karena tidak ada.
    return node_request(sementara, "GET", "/v1/health", timeout=timeout)


def local_online():
    return (os.path.exists("/usr/local/sbin/addssh")
            and (os.path.exists("/usr/local/sbin/addws")
                 or os.path.exists("/usr/local/sbin/addvless")))


def check_server(sid, timeout=10):
    s = server_by_id(sid)
    if not s:
        return {"ok": False, "error": "Server tidak ada."}
    if not str(s["base_url"] or "").strip():
        ok = local_online()
        akun = {}
        try:
            from kyt import store_lib as S
            akun = S.jumlah_akun()
        except Exception:
            akun = {}
        _perbarui(int(sid), last_seen=int(time.time()),
                  last_error="" if ok else "script panel lokal tidak lengkap",
                  last_version="local",
                  accounts_json=json.dumps(akun, separators=(",", ":")))
        return {"ok": ok, "local": True, "version": "local",
                "accounts": akun, "error": "" if ok else "script panel lokal tidak lengkap"}
    try:
        data = node_request(s, "GET", "/v1/health", timeout=timeout)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    akun = data.get("accounts") or {}
    dns = data.get("dns") or {}
    _perbarui(int(sid),
              accounts_json=json.dumps(akun, separators=(",", ":")),
              dns_json=json.dumps(dns, separators=(",", ":")),
              last_version=str(data.get("version") or "")[:30])
    return {"ok": True, "version": data.get("version") or "",
            "accounts": akun, "max_slots": data.get("max_slots") or 0,
            "location": data.get("location") or {}}


def check_all(timeout=8):
    hasil = {}
    for s in servers(only_active=True):
        hasil[int(s["id"])] = check_server(int(s["id"]), timeout=timeout)
    return hasil


def server_online(s, max_age=180):
    if not s:
        return False
    if not int(s["active"] or 0):
        return False
    if not str(s["base_url"] or "").strip():
        return local_online()
    return int(s["last_seen"] or 0) >= int(time.time()) - int(max_age)


def akun_server(s):
    try:
        d = json.loads(s["accounts_json"] or "{}")
    except Exception:
        d = {}
    return d if isinstance(d, dict) else {}

def dns_info_from(d, kind):
    """Ubah dict dns agent menjadi baris Host/PubKey sesuai layanan."""
    if not isinstance(d, dict):
        d = {}
    mode = str(d.get("mode") or "").lower()
    host = str(d.get("host") or "").strip()
    pub = str(d.get("pubkey") or "").strip()
    label = ""
    if kind == "ssh":
        if mode != "ssh":
            return []
    else:
        label = {
            "xray-tls": "Xray TLS (443)",
            "xray-auto": "Xray AUTO (80+443)",
            "xray-ntls": "Xray NTLS (80)",
        }.get(mode, "")
        if not label:
            return []
    if not host and not pub:
        return []
    out = []
    if host:
        out.append(("Host Slowdns", host))
    if pub:
        out.append(("Public Key", pub))
    if label:
        out.append(("Mode SlowDNS", label))
    return out

def server_dns_info(s, kind):
    """Info SlowDNS dari node (atau lokal) untuk layanan kind."""
    if not s:
        return []
    if not str(s["base_url"] or "").strip():
        try:
            from kyt import store_lib as S
            return S.slowdns_info(kind)
        except Exception:
            return []
    try:
        d = json.loads(s["dns_json"] or "{}")
    except Exception:
        d = {}
    return dns_info_from(d, kind)


# ---------------- akun via agent ----------------
def _map(tipe):
    if tipe not in AGENT_MAP:
        raise NodeError("Tipe %s tidak didukung di node." % tipe)
    return AGENT_MAP[tipe]


def create_account(s, tipe, user, days, quota_gb=0, ip_limit=0, order_id=""):
    service, protocol = _map(tipe)
    payload = {
        "service": service, "protocol": protocol, "username": user,
        "days": int(days), "quota_gb": int(quota_gb or 0),
        "ip_limit": int(ip_limit or 0),
    }
    return node_request(s, "POST", "/v1/accounts", payload, timeout=180,
                        idempotency_key=order_id or "")


def renew_account(s, tipe, user, days, quota_gb=None, ip_limit=None, order_id=""):
    service, protocol = _map(tipe)
    payload = {"days": int(days)}
    if quota_gb is not None:
        payload["quota_gb"] = int(quota_gb)
    if ip_limit is not None:
        payload["ip_limit"] = int(ip_limit)
    path = "/v1/accounts/%s/%s/%s/renew" % (service, protocol, user)
    return node_request(s, "POST", path, payload, timeout=120,
                        idempotency_key=order_id or "")


def delete_account(s, tipe, user):
    service, protocol = _map(tipe)
    path = "/v1/accounts/%s/%s/%s" % (service, protocol, user)
    return node_request(s, "DELETE", path, timeout=60)


def account_status(s, tipe, user):
    service, protocol = _map(tipe)
    path = "/v1/accounts/%s/%s/%s" % (service, protocol, user)
    return node_request(s, "GET", path, timeout=30)
