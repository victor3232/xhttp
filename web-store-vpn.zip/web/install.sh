#!/usr/bin/env bash
# ============================================================
#  VPN Store - Installer
#  Pakai:  bash install.sh
#  (jalankan di VPS panel, sebagai root)
# ============================================================
set -e
RED='\033[1;31m'; GRN='\033[1;32m'; YEL='\033[1;33m'; CYN='\033[1;36m'; NC='\033[0m'
say(){ echo -e "${CYN}==>${NC} $*"; }
ok(){  echo -e "${GRN}  ✔${NC} $*"; }
warn(){ echo -e "${YEL}  !${NC} $*"; }
die(){ echo -e "${RED}  ✘${NC} $*"; exit 1; }

[ "$(id -u)" = "0" ] || die "Jalankan sebagai root."
SRC="$(cd "$(dirname "$0")" && pwd)"
[ -d "$SRC/public" ] || die "Jalankan dari dalam folder web/ (install.sh)."

# ---------- Input ----------
DEF_DOMAIN="$(cat /etc/xray/domain 2>/dev/null || echo '')"
read -rp "Domain web store (mis. store.domain.com): " STORE_DOMAIN
[ -z "$STORE_DOMAIN" ] && die "Domain wajib diisi."
read -rp "Email untuk SSL (Let's Encrypt): " SSL_EMAIL
read -rp "Nama brand [VPN Store]: " BRAND; BRAND=${BRAND:-VPN Store}
read -rp "Nama database [vpnstore]: " DB_NAME; DB_NAME=${DB_NAME:-vpnstore}
read -rp "User database [vpnstore]: " DB_USER; DB_USER=${DB_USER:-vpnstore}
DB_PASS="$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 16)"
read -rp "Email admin: " ADMIN_EMAIL
read -rsp "Password admin: " ADMIN_PASS; echo
read -rp "Duitku environment (sandbox/production) [sandbox]: " DK_ENV; DK_ENV=${DK_ENV:-sandbox}
read -rp "Duitku Merchant Code (boleh dikosongkan): " DK_MERCHANT
read -rsp "Duitku API Key (boleh dikosongkan): " DK_KEY; echo

# ---------- Paket ----------
say "Install paket (nginx, php-fpm, mariadb, certbot)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null
apt-get install -y nginx mariadb-server php-fpm php-mysql php-curl php-mbstring php-xml \
  php-zip curl unzip certbot python3-certbot-nginx >/dev/null
PHPV="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo 8.3)"
ok "PHP $PHPV"

# ---------- Database ----------
say "Siapkan database..."
systemctl enable --now mariadb >/dev/null 2>&1 || true
mysql -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -e "CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';"
mysql -e "ALTER USER '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';"
mysql -e "GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost'; FLUSH PRIVILEGES;"
mysql "$DB_NAME" < "$SRC/sql/schema.sql"
ok "Database $DB_NAME siap."

# ---------- Admin default ----------
HASH="$(php -r 'echo password_hash($argv[1], PASSWORD_DEFAULT);' "$ADMIN_PASS")"
mysql "$DB_NAME" -e "INSERT INTO users (name,email,password,role,balance) VALUES ('Admin','$ADMIN_EMAIL','$HASH','admin',0)
  ON DUPLICATE KEY UPDATE password=VALUES(password), role='admin';"
mysql "$DB_NAME" -e "UPDATE settings SET value='$BRAND' WHERE \`key\`='brand';"
ok "Admin: $ADMIN_EMAIL"

# ---------- Deploy aplikasi ----------
WEBROOT="/var/www/vpnstore"
say "Deploy aplikasi ke $WEBROOT..."
mkdir -p "$WEBROOT"
cp -r "$SRC/public" "$SRC/app" "$SRC/views" "$WEBROOT/"
cp -r "$SRC/sql" "$WEBROOT/" 2>/dev/null || true

cat > "$WEBROOT/app/config.local.php" <<PHP
<?php
return [
    'db_name'         => '$DB_NAME',
    'db_user'         => '$DB_USER',
    'db_pass'         => '$DB_PASS',
    'base_url'        => 'https://$STORE_DOMAIN',
    'brand'           => '$BRAND',
    'duitku_env'      => '$DK_ENV',
    'duitku_merchant' => '$DK_MERCHANT',
    'duitku_key'      => '$DK_KEY',
];
PHP
chown -R www-data:www-data "$WEBROOT"
find "$WEBROOT" -type d -exec chmod 755 {} \;
find "$WEBROOT" -type f -exec chmod 644 {} \;
ok "Aplikasi terpasang."

# ---------- vpnctl ----------
say "Pasang vpnctl (manajer akun)..."
install -m 0755 "$SRC/bin/vpnctl" /usr/local/sbin/vpnctl
cat > /etc/sudoers.d/vpnstore <<'SUDO'
www-data ALL=(root) NOPASSWD: /usr/local/sbin/vpnctl
SUDO
chmod 440 /etc/sudoers.d/vpnstore
ok "vpnctl + sudoers siap."

# ---------- Nginx vhost ----------
say "Buat vhost nginx untuk $STORE_DOMAIN..."
cat > /etc/nginx/sites-available/vpnstore <<NGINX
server {
    listen 80;
    listen [::]:80;
    server_name $STORE_DOMAIN;
    root $WEBROOT/public;
    index index.php;
    location / { try_files \$uri /index.php?\$query_string; }
    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php$PHPV-fpm.sock;
    }
    location ~ /\.(?!well-known).* { deny all; }
}
NGINX
ln -sf /etc/nginx/sites-available/vpnstore /etc/nginx/sites-enabled/vpnstore
nginx -t && systemctl reload nginx
ok "vhost aktif (HTTP)."

# ---------- SSL ----------
if [ -n "$SSL_EMAIL" ]; then
  say "Pasang SSL Let's Encrypt..."
  certbot --nginx -d "$STORE_DOMAIN" --non-interactive --agree-tos -m "$SSL_EMAIL" --redirect || \
    warn "SSL gagal — pastikan DNS $STORE_DOMAIN sudah mengarah ke IP VPS ini, lalu jalankan: certbot --nginx -d $STORE_DOMAIN"
else
  warn "SSL dilewati (email kosong)."
fi

echo
echo -e "${GRN}============================================${NC}"
echo -e "${GRN}  VPN STORE SELESAI TERPASANG${NC}"
echo -e "${GRN}============================================${NC}"
echo -e "  URL         : https://$STORE_DOMAIN"
echo -e "  Admin login : $ADMIN_EMAIL"
echo -e "  Database    : $DB_NAME / $DB_USER"
echo
echo -e "${YEL}Langkah berikutnya:${NC}"
echo -e "  1. Isi Duitku Merchant Code + API Key di: https://$STORE_DOMAIN/admin/settings"
echo -e "  2. Set Callback URL di dashboard Duitku ke: https://$STORE_DOMAIN/callback"
echo -e "  3. Set Return URL ke: https://$STORE_DOMAIN/pay/return"
echo -e "  4. Ubah harga produk di menu Produk."
echo
