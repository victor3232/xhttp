# VPN Store

Web jualan akun VPN (SSH, OpenVPN, VMess, VLESS, Trojan, Shadowsocks, L2TP/IKEv2)
dengan payment gateway **Duitku**. Model **wallet/deposit**: user deposit saldo →
beli akun pakai saldo.

Stack: **PHP (native) + MySQL/MariaDB + nginx**. Ringan, tanpa build, langsung jalan.

---

## Fitur

**Pengguna**
- Daftar / login (password di-hash bcrypt)
- Dashboard: saldo, jumlah akun aktif, pesanan terakhir
- Beli akun: pilih produk → akun dibuat otomatis di VPS → detail muncul
- Deposit saldo via Duitku (QRIS, Virtual Account, e-wallet, retail)
- Halaman tagihan (nomor VA / QR / link bayar) + cek status
- Riwayat pembelian, riwayat deposit, riwayat saldo (mutasi)

**Admin** (`/admin`)
- Dashboard statistik (user, order, akun aktif, total deposit)
- Kelola produk (nama, tipe, hari, kuota, limit IP, harga, aktif)
- Kelola pengguna (tambah/kurangi saldo, ban/unban)
- Lihat & hapus pesanan (sekaligus hapus akun di server)
- Lihat deposit + tandai lunas manual
- Pengaturan (brand, Telegram, min deposit, kredensial Duitku)

---

## Instalasi

1. Upload folder `web/` ke VPS (mis. `/root/web`).
2. Jalankan installer sebagai root:
   ```bash
   cd /root/web && bash install.sh
   ```
3. Ikuti pertanyaan (domain, email SSL, kredensial DB, admin, Duitku).
4. Buka `https://<domain>/` → login admin → isi kredensial Duitku di **Pengaturan**.

### Callback Duitku
Di dashboard Duitku, set:
- **Callback URL** : `https://<domain>/callback`
- **Return URL**   : `https://<domain>/pay/return`

---

## Struktur

```
web/
├── app/            # core PHP
│   ├── config.php        # konfigurasi (default)
│   ├── db.php            # koneksi + helper query
│   ├── helpers.php       # session, csrf, view, format
│   ├── auth.php          # login/register/role
│   ├── duitku.php        # integrasi Duitku
│   ├── vpn.php           # jembatan ke vpnctl + generator link akun
│   ├── service.php       # saldo, order, deposit
│   └── admin.php         # routing admin
├── public/         # document root
│   ├── index.php         # router utama
│   └── assets/           # css & js
├── views/          # template
├── bin/vpnctl      # manajer akun (Python, non-interaktif)
├── sql/schema.sql  # skema + produk contoh
└── install.sh      # installer otomatis
```

## Cara kerja pembuatan akun

`vpnctl` (Python) menulis akun **langsung ke file panel yang sama** dengan menu:
- SSH → `useradd` + `/etc/ssh/.ssh.db`
- VMess → `/etc/xray/config.json` (marker `#vmess*`) + `/etc/vmess/.vmess.db`
- VLESS → marker `#vless*` + `#vlextls` + `/etc/vless/.vless.db`
- Trojan → marker `#trojan*` + `/etc/trojan/.trojan.db`
- Shadowsocks → marker `#ssws/#ssgrpc` + `/etc/shadowsocks/.shadowsocks.db`
- L2TP/IKEv2 → `/etc/ppp/chap-secrets`, `/etc/ipsec.secrets`, `/etc/l2tp/.l2tp.db`

Karena formatnya identik, **akun dari web & dari menu panel saling sinkron**
(bisa dilihat/dihapus dari keduanya). Setiap perubahan `config.json`
divalidasi otomatis — kalau tidak valid, perubahan dibatalkan.

OpenVPN memakai akun SSH yang sama (login pakai username & password SSH).

## Uji vpnctl tanpa VPS

```bash
export VPNCTL_ROOT=/tmp/sandbox     # prefix path untuk testing
mkdir -p $VPNCTL_ROOT/etc/xray && cp limit/config.json $VPNCTL_ROOT/etc/xray/
bin/vpnctl add vmess --user tes --days 30 --quota 10 --iplimit 1
bin/vpnctl validate
bin/vpnctl del vmess --user tes
```
