<?php
/**
 * Helper umum: session, CSRF, flash, format, render view.
 */
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

/** URL absolut dari path relatif. */
function url(string $path = ''): string {
    global $CFG;
    return rtrim($CFG['base_url'], '/') . '/' . ltrim($path, '/');
}

/** Redirect lalu stop. */
function redirect(string $path): void {
    header('Location: ' . (preg_match('#^https?://#', $path) ? $path : url($path)));
    exit;
}

/** Ambil nilai input POST/GET. */
function input(string $key, $default = '') {
    $v = $_POST[$key] ?? $_GET[$key] ?? $default;
    return is_string($v) ? trim($v) : $v;
}

/** Escape HTML. */
function e($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/** Format rupiah. */
function rupiah($n): string {
    return 'Rp' . number_format((float)$n, 0, ',', '.');
}

/** Token CSRF. */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    $t = $_POST['_csrf'] ?? '';
    if (!hash_equals($_SESSION['csrf'] ?? '', $t)) {
        http_response_code(419);
        exit('CSRF token tidak valid. Muat ulang halaman.');
    }
}

/** Flash message. */
function flash(string $msg = null, string $type = 'info') {
    if ($msg === null) {
        $f = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $f;
    }
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
    return null;
}

/** Render view dengan layout. */
function view(string $name, array $data = [], string $layout = 'layout'): void {
    global $CFG;
    extract($data, EXTR_SKIP);
    $__view = __DIR__ . '/../views/' . $name . '.php';
    if (!is_file($__view)) {
        http_response_code(500);
        exit('View tidak ditemukan: ' . e($name));
    }
    ob_start();
    require $__view;
    $content = ob_get_clean();
    if ($layout === null) {
        echo $content;
        return;
    }
    require __DIR__ . '/../views/' . $layout . '.php';
}

/** Render view tanpa layout (untuk AJAX/partial). */
function partial(string $name, array $data = []): void {
    view($name, $data, null);
}

/** JSON response. */
function json_out($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/** Kode acak unik. */
function gen_code(string $prefix = 'TRX'): string {
    return $prefix . strtoupper(bin2hex(random_bytes(5)));
}

/** Normalisasi nomor HP Indonesia ke 08xxxx. */
function normalize_phone(string $p): string {
    $p = preg_replace('/[^0-9+]/', '', $p);
    if (strpos($p, '+62') === 0) $p = '0' . substr($p, 3);
    elseif (strpos($p, '62') === 0) $p = '0' . substr($p, 2);
    return $p;
}
