<?php
/**
 * Manajer akun VPN — jembatan PHP -> vpnctl (Python).
 */
require_once __DIR__ . '/helpers.php';

/** Domain panel. */
function vpn_domain(): string
{
    global $CFG;
    $d = setting('domain', '');
    if (!$d) $d = $CFG['domain'] ?? '';
    if (!$d && is_file('/etc/xray/domain')) {
        $d = trim(@file_get_contents('/etc/xray/domain'));
    }
    return $d ?: ($_SERVER['HTTP_HOST'] ?? 'localhost');
}

/** Panggil vpnctl dan kembalikan hasil JSON. */
function vpnctl(array $args): array
{
    global $CFG;
    $bin = $CFG['vpnctl'] ?? '/usr/local/sbin/vpnctl';
    if (!is_file($bin)) {
        return ['ok' => false, 'error' => 'vpnctl tidak ditemukan di ' . $bin];
    }
    $cmd = escapeshellcmd($bin);
    foreach ($args as $a) {
        $cmd .= ' ' . escapeshellarg((string)$a);
    }
    if (!empty($CFG['vpnctl_sudo'])) {
        $cmd = 'sudo -n ' . $cmd;
    }
    $out = shell_exec($cmd . ' 2>&1');
    $json = json_decode((string)$out, true);
    if (!is_array($json)) {
        return ['ok' => false, 'error' => 'Respons vpnctl tidak valid: ' . trim((string)$out)];
    }
    return $json;
}

/** Buat akun. $type: ssh|vmess|vless|trojan|ss|l2tp|ovpn */
function vpn_create(string $type, array $o): array
{
    $real = ($type === 'ovpn') ? 'ssh' : $type; // OpenVPN memakai akun SSH
    $args = ['add', $real, '--user', $o['user'], '--days', (string)($o['days'] ?? 30)];
    if (!empty($o['pass']))     $args[] = '--pass';
    if (!empty($o['pass']))     $args[] = $o['pass'];
    if (isset($o['quota']))     { $args[] = '--quota';   $args[] = (string)$o['quota']; }
    if (isset($o['iplimit']))   { $args[] = '--iplimit'; $args[] = (string)$o['iplimit']; }
    if (!empty($o['uuid']))     { $args[] = '--uuid';    $args[] = $o['uuid']; }
    if (!empty($o['cipher']))   { $args[] = '--cipher';  $args[] = $o['cipher']; }
    $res = vpnctl($args);
    if (!empty($res['ok'])) {
        $res['type'] = $type; // simpan tipe asli (ovpn)
    }
    return $res;
}

/** Hapus akun. */
function vpn_delete(string $type, string $user): array
{
    $real = ($type === 'ovpn') ? 'ssh' : $type;
    return vpnctl(['del', $real, '--user', $user]);
}

/** Daftar akun. */
function vpn_list(string $type): array
{
    $real = ($type === 'ovpn') ? 'ssh' : $type;
    return vpnctl(['list', $real]);
}

/** Label tipe. */
function type_label(string $t): string
{
    return [
        'ssh'    => 'SSH',
        'ovpn'   => 'OpenVPN',
        'vmess'  => 'VMess',
        'vless'  => 'VLESS',
        'trojan' => 'Trojan',
        'ss'     => 'Shadowsocks',
        'l2tp'   => 'L2TP / IKEv2',
    ][$t] ?? strtoupper($t);
}

/**
 * Susun detail koneksi akun (link/config).
 * Kembalikan array ['info' => [...], 'links' => [ ['label','value'], ... ]]
 */
function vpn_links(string $type, array $a): array
{
    $domain = vpn_domain();
    $ip     = $a['server_ip'] ?? '';
    $user   = $a['username'] ?? '';
    $pass   = $a['password'] ?? '';
    $uuid   = $a['uuid'] ?? '';
    $links  = [];
    $info   = [];

    switch ($type) {
        case 'ssh':
        case 'ovpn':
            $info = [
                'Host'        => $domain,
                'Username'    => $user,
                'Password'    => $pass,
                'Port OpenSSH'=> '443, 80, 22',
                'Port Dropbear' => '443, 109',
                'Port SSH WS' => '80, 8080, 8081-9999',
                'Port SSL/TLS' => '443',
            ];
            $links = [
                ['label' => 'Payload WS (Cloudflare/SNI)', 'value' =>
                    "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf]Connection: Keep-Alive[crlf][crlf]"],
                ['label' => 'Payload WSS', 'value' =>
                    "GET wss://BUG.COM/ HTTP/1.1[crlf]Host: $domain[crlf]Upgrade: websocket[crlf][crlf]"],
            ];
            if ($type === 'ovpn') {
                $links[] = ['label' => 'Download OpenVPN (.ovpn)', 'value' => "https://$domain:81/"];
            }
            break;

        case 'vmess':
            $mk = function ($net, $path, $port, $tls, $svc = '') use ($user, $domain, $uuid) {
                $o = ['v' => '2', 'ps' => $user, 'add' => $domain, 'port' => (string)$port,
                      'id' => $uuid, 'aid' => '0', 'scy' => 'auto', 'net' => $net,
                      'type' => 'none', 'host' => $domain, 'path' => $path, 'tls' => $tls];
                if ($svc) $o['path'] = $svc;
                return 'vmess://' . base64_encode(json_encode($o));
            };
            $links = [
                ['label' => 'VMess WS TLS (443)', 'value' => $mk('ws', '/vmess', 443, 'tls')],
                ['label' => 'VMess WS Non-TLS (80)', 'value' => $mk('ws', '/vmess', 80, '')],
                ['label' => 'VMess gRPC (443)', 'value' => $mk('grpc', 'vmess-grpc', 443, 'tls')],
                ['label' => 'VMess HTTPUpgrade (443)', 'value' => $mk('httpupgrade', '/vmess-hu', 443, 'tls')],
                ['label' => 'VMess XHTTP (443)', 'value' => $mk('xhttp', '/vmess-xhttp', 443, 'tls')],
                ['label' => 'VMess TCP TLS (8543)', 'value' => $mk('tcp', '', 8543, 'tls')],
            ];
            $info = ['Host' => $domain, 'UUID' => $uuid, 'AlterID' => '0'];
            break;

        case 'vless':
            $links = [
                ['label' => 'VLESS WS TLS (443)', 'value' => "vless://$uuid@$domain:443?path=/vless&security=tls&encryption=none&type=ws#$user"],
                ['label' => 'VLESS WS Non-TLS (80)', 'value' => "vless://$uuid@$domain:80?path=/vless&encryption=none&type=ws#$user"],
                ['label' => 'VLESS gRPC (443)', 'value' => "vless://$uuid@$domain:443?mode=gun&security=tls&encryption=none&type=grpc&serviceName=vless-grpc&sni=$domain#$user"],
                ['label' => 'VLESS HTTPUpgrade (443)', 'value' => "vless://$uuid@$domain:443?path=/vless-hu&security=tls&encryption=none&type=httpupgrade&sni=$domain#$user"],
                ['label' => 'VLESS XHTTP (443)', 'value' => "vless://$uuid@$domain:443?path=/vless-xhttp&security=tls&encryption=none&type=xhttp&sni=$domain#$user"],
                ['label' => 'VLESS XTLS-Vision (8443)', 'value' => "vless://$uuid@$domain:8443?type=tcp&security=tls&encryption=none&flow=xtls-rprx-vision&sni=$domain#$user"],
            ];
            $info = ['Host' => $domain, 'UUID' => $uuid];
            break;

        case 'trojan':
            $links = [
                ['label' => 'Trojan WS TLS (443)', 'value' => "trojan://$uuid@$domain:443?path=%2Ftrojan-ws&security=tls&host=$domain&type=ws&sni=$domain#$user"],
                ['label' => 'Trojan gRPC (443)', 'value' => "trojan://$uuid@$domain:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni=$domain#$user"],
                ['label' => 'Trojan HTTPUpgrade (443)', 'value' => "trojan://$uuid@$domain:443?path=%2Ftrojan-hu&security=tls&host=$domain&type=httpupgrade&sni=$domain#$user"],
                ['label' => 'Trojan XHTTP (443)', 'value' => "trojan://$uuid@$domain:443?path=%2Ftrojan-xhttp&security=tls&host=$domain&type=xhttp&sni=$domain#$user"],
                ['label' => 'Trojan TCP TLS (8643)', 'value' => "trojan://$uuid@$domain:8643?security=tls&type=tcp&sni=$domain#$user"],
            ];
            $info = ['Host' => $domain, 'Password' => $uuid];
            break;

        case 'ss':
            $b64 = base64_encode("aes-128-gcm:$uuid");
            $links = [
                ['label' => 'Shadowsocks WS (443)', 'value' => "ss://$b64@$domain:443?path=/ss-ws&type=ws&host=$domain&sni=$domain#$user"],
                ['label' => 'Shadowsocks gRPC (443)', 'value' => "ss://$b64@$domain:443?mode=gun&type=grpc&serviceName=ss-grpc&sni=$domain#$user"],
            ];
            $info = ['Host' => $domain, 'Method' => 'aes-128-gcm', 'Password' => $uuid];
            break;

        case 'l2tp':
            $psk = is_file('/etc/l2tp/psk') ? trim(file_get_contents('/etc/l2tp/psk')) : '';
            $info = [
                'Host'     => $domain,
                'Username' => $user,
                'Password' => $pass,
                'IPSec PSK'=> $psk,
                'Port L2TP'=> '1701',
                'Port IPSec' => '500, 4500',
                'Port IKEv2' => '500, 4500',
            ];
            break;
    }

    return ['info' => $info, 'links' => $links];
}
