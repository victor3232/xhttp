<?php
/**
 * Konfigurasi utama VPN Store.
 * JANGAN taruh kredensial rahasia di sini — taruh di config.local.php
 * (file itu dibuat otomatis oleh install.sh dan tidak ikut ke repo).
 */
date_default_timezone_set('Asia/Jakarta');

$CONFIG = [
    // ---- Database ----
    'db_host' => '127.0.0.1',
    'db_port' => 3306,
    'db_name' => 'vpnstore',
    'db_user' => 'vpnstore',
    'db_pass' => '',

    // ---- Aplikasi ----
    'base_url'    => '',            // mis. https://store.domain.com  (kosong = auto)
    'brand'       => 'VPN Store',
    'contact_telegram' => '',
    'currency'    => 'Rp',
    'min_deposit' => 10000,

    // ---- Duitku ----
    'duitku_env'      => 'sandbox', // sandbox | production
    'duitku_merchant' => '',        // Merchant Code
    'duitku_key'      => '',        // API Key
    'duitku_expiry'   => 60,        // menit

    // ---- Akun panel / vpnctl ----
    'vpnctl'      => '/usr/local/sbin/vpnctl',
    'vpnctl_sudo' => true,          // jalankan vpnctl via sudo (www-data -> root)
    'domain'      => '',            // domain panel (auto dari /etc/xray/domain)

    // ---- Debug ----
    'debug' => false,
];

// Override rahasia (tidak ikut repo)
if (is_file(__DIR__ . '/config.local.php')) {
    $local = require __DIR__ . '/config.local.php';
    if (is_array($local)) {
        $CONFIG = array_merge($CONFIG, $local);
    }
}

// Domain panel otomatis
if (empty($CONFIG['domain']) && is_file('/etc/xray/domain')) {
    $CONFIG['domain'] = trim(@file_get_contents('/etc/xray/domain'));
}

// base_url otomatis dari request
if (empty($CONFIG['base_url']) && PHP_SAPI !== 'cli' && !empty($_SERVER['HTTP_HOST'])) {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $CONFIG['base_url'] = $scheme . '://' . $_SERVER['HTTP_HOST'];
}

if ($CONFIG['debug']) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
}

return $CONFIG;
