<?php
/**
 * Integrasi Duitku (Payment Gateway).
 *  - createInvoice  : buat tagihan (VA / QRIS / e-wallet / retail)
 *  - transactionStatus : cek status transaksi (untuk return URL)
 *  - callback       : verifikasi notifikasi dari Duitku
 *
 * Dokumentasi: https://docs.duitku.com
 */
require_once __DIR__ . '/helpers.php';

class Duitku
{
    private array $cfg;
    private string $base;
    private string $merchant;
    private string $apiKey;

    public function __construct(array $cfg = null)
    {
        global $CFG;
        $this->cfg      = $cfg ?: $CFG;
        // Utamakan nilai dari halaman Pengaturan (DB), fallback ke config.local.php
        $env            = (string)(setting('duitku_env', '') ?: ($this->cfg['duitku_env'] ?? 'sandbox'));
        $this->base     = ($env === 'production')
            ? 'https://api-prod.duitku.com'
            : 'https://sandbox.duitku.com';
        $this->merchant = (string)(setting('duitku_merchant', '') ?: ($this->cfg['duitku_merchant'] ?? ''));
        $this->apiKey   = (string)(setting('duitku_key', '') ?: ($this->cfg['duitku_key'] ?? ''));
    }

    public function configured(): bool
    {
        return $this->merchant !== '' && $this->apiKey !== '';
    }

    private function post(string $url, array $body)
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($body),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json'],
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($res === false) {
            return ['_error' => 'Koneksi ke Duitku gagal: ' . $err];
        }
        $json = json_decode($res, true);
        if (!is_array($json)) {
            return ['_error' => 'Respons Duitku tidak valid', '_http' => $code, '_raw' => $res];
        }
        return $json;
    }

    /** Buat tagihan. */
    public function createInvoice(array $p): array
    {
        $orderId = $p['order_id'];
        $amount  = (int)$p['amount'];
        $method  = $p['method'] ?? '';
        $sig     = md5($this->merchant . $orderId . $amount . $this->apiKey);

        $body = [
            'merchantCode'    => $this->merchant,
            'paymentAmount'   => $amount,
            'paymentMethod'   => $method,
            'merchantOrderId' => $orderId,
            'productDetails'  => $p['product'] ?? 'Deposit Saldo',
            'additionalParam' => '',
            'merchantUserInfo'=> '',
            'customerVaName'  => $p['name'] ?? 'Customer',
            'email'           => $p['email'] ?? '',
            'phoneNumber'     => $p['phone'] ?? '',
            'callbackUrl'     => $p['callback_url'],
            'returnUrl'       => $p['return_url'],
            'signature'       => $sig,
            'expiryPeriod'    => (int)($this->cfg['duitku_expiry'] ?? 60),
            'itemDetails'     => [[
                'name'     => $p['product'] ?? 'Deposit Saldo',
                'price'    => $amount,
                'quantity' => 1,
            ]],
            'customerDetail'  => [
                'firstName'   => $p['name'] ?? 'Customer',
                'lastName'    => '',
                'email'       => $p['email'] ?? '',
                'phoneNumber' => $p['phone'] ?? '',
                'address'     => '',
                'city'        => '',
                'postalCode'  => '',
                'countryCode' => 'ID',
            ],
        ];

        return $this->post($this->base . '/api/merchant/createInvoice', $body);
    }

    /** Cek status transaksi. */
    public function transactionStatus(string $orderId): array
    {
        $sig  = md5($this->merchant . $orderId . $this->apiKey);
        $body = [
            'merchantCode'    => $this->merchant,
            'merchantOrderId' => $orderId,
            'signature'       => $sig,
        ];
        return $this->post($this->base . '/api/merchant/transactionStatus', $body);
    }

    /** Verifikasi signature callback. */
    public function verifyCallback(array $post): bool
    {
        if (($post['merchantCode'] ?? '') !== $this->merchant) return false;
        $expected = md5($this->merchant . ($post['amount'] ?? '') . ($post['merchantOrderId'] ?? '') . $this->apiKey);
        return hash_equals($expected, (string)($post['signature'] ?? ''));
    }

    /** Daftar metode pembayaran dari Duitku (fallback: daftar statis). */
    public function paymentMethods(int $amount): array
    {
        $url  = 'https://passport.duitku.com/webapi/api/merchant/paymentmethod/getpaymentmethod';
        $body = [
            'merchantcode' => $this->merchant,
            'amount'       => $amount,
            'datetime'     => date('Y-m-d H:i:s'),
        ];
        $res = $this->post($url, $body);
        if (!empty($res['paymentFee']) || !empty($res['responseCode'])) {
            $list = $res['paymentFee'] ?? [];
            if ($list) {
                return array_map(fn($m) => [
                    'code' => $m['paymentMethod'] ?? '',
                    'name' => $m['paymentName'] ?? '',
                    'fee'  => (int)($m['totalFee'] ?? 0),
                ], $list);
            }
        }
        return self::fallbackMethods();
    }

    public static function fallbackMethods(): array
    {
        return [
            ['code' => 'SP', 'name' => 'QRIS (semua e-wallet)', 'fee' => 0],
            ['code' => 'BC', 'name' => 'BCA Virtual Account', 'fee' => 0],
            ['code' => 'M2', 'name' => 'Mandiri Virtual Account', 'fee' => 0],
            ['code' => 'I1', 'name' => 'BNI Virtual Account', 'fee' => 0],
            ['code' => 'B1', 'name' => 'BRI Virtual Account (BRIVA)', 'fee' => 0],
            ['code' => 'BT', 'name' => 'Permata Virtual Account', 'fee' => 0],
            ['code' => 'C1', 'name' => 'CIMB Niaga Virtual Account', 'fee' => 0],
            ['code' => 'VA', 'name' => 'Maybank Virtual Account', 'fee' => 0],
            ['code' => 'A1', 'name' => 'ATM Bersama / Prima', 'fee' => 0],
            ['code' => 'OV', 'name' => 'OVO', 'fee' => 0],
            ['code' => 'DA', 'name' => 'DANA', 'fee' => 0],
            ['code' => 'SA', 'name' => 'ShopeePay', 'fee' => 0],
            ['code' => 'LF', 'name' => 'LinkAja', 'fee' => 0],
            ['code' => 'IR', 'name' => 'Indomaret', 'fee' => 0],
            ['code' => 'FT', 'name' => 'Fastpay', 'fee' => 0],
        ];
    }
}

/** Kode hasil sukses dari Duitku. */
function duitku_is_success(string $resultCode): bool
{
    return $resultCode === '00';
}
