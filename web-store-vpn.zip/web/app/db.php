<?php
/**
 * Koneksi database + helper query sederhana.
 */
$CFG = require __DIR__ . '/config.php';

try {
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        $CFG['db_host'], $CFG['db_port'], $CFG['db_name']);
    $pdo = new PDO($dsn, $CFG['db_user'], $CFG['db_pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Koneksi database gagal: ' . ($CFG['debug'] ? $e->getMessage() : 'periksa konfigurasi.'));
}

/** Jalankan query dengan parameter, kembalikan PDOStatement. */
function q(string $sql, array $params = []): PDOStatement {
    global $pdo;
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st;
}

/** Ambil satu baris. */
function q_one(string $sql, array $params = []): ?array {
    $r = q($sql, $params)->fetch();
    return $r === false ? null : $r;
}

/** Ambil semua baris. */
function q_all(string $sql, array $params = []): array {
    return q($sql, $params)->fetchAll();
}

/** Insert dan kembalikan ID terakhir. */
function q_insert(string $sql, array $params = []): int {
    global $pdo;
    q($sql, $params);
    return (int)$pdo->lastInsertId();
}

/** Ambil nilai setting. */
function setting(string $key, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (q_all('SELECT `key`,`value` FROM settings') as $r) {
            $cache[$r['key']] = $r['value'];
        }
    }
    return $cache[$key] ?? $default;
}

/** Simpan setting. */
function setting_set(string $key, $value): void {
    q('INSERT INTO settings (`key`,`value`) VALUES (?,?)
       ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)', [$key, $value]);
}
