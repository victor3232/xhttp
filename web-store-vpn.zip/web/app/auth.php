<?php
/**
 * Autentikasi & otorisasi.
 */
require_once __DIR__ . '/helpers.php';

/** Pengguna yang sedang login (atau null). */
function current_user(): ?array {
    static $u = false;
    if ($u !== false) return $u;
    if (empty($_SESSION['uid'])) return $u = null;
    $u = q_one('SELECT * FROM users WHERE id=?', [$_SESSION['uid']]);
    if (!$u || $u['status'] !== 'active') {
        unset($_SESSION['uid']);
        return $u = null;
    }
    return $u;
}

function is_logged_in(): bool {
    return current_user() !== null;
}

function is_admin(): bool {
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

/** Wajib login. */
function require_login(): array {
    $u = current_user();
    if (!$u) redirect('login');
    return $u;
}

/** Wajib admin. */
function require_admin(): array {
    $u = require_login();
    if ($u['role'] !== 'admin') {
        http_response_code(403);
        exit('Akses ditolak.');
    }
    return $u;
}

/** Login dengan email + password. */
function auth_login(string $email, string $password): array {
    $u = q_one('SELECT * FROM users WHERE email=?', [$email]);
    if (!$u || !password_verify($password, $u['password'])) {
        return ['ok' => false, 'error' => 'Email atau password salah.'];
    }
    if ($u['status'] !== 'active') {
        return ['ok' => false, 'error' => 'Akun diblokir.'];
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    return ['ok' => true, 'user' => $u];
}

/** Daftar akun baru. */
function auth_register(string $name, string $email, string $password, string $phone = ''): array {
    if (strlen($name) < 3)  return ['ok' => false, 'error' => 'Nama minimal 3 karakter.'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return ['ok' => false, 'error' => 'Email tidak valid.'];
    if (strlen($password) < 6) return ['ok' => false, 'error' => 'Password minimal 6 karakter.'];
    if (q_one('SELECT id FROM users WHERE email=?', [$email])) {
        return ['ok' => false, 'error' => 'Email sudah terdaftar.'];
    }
    $id = q_insert('INSERT INTO users (name,email,phone,password,role) VALUES (?,?,?,?,?)',
        [$name, $email, normalize_phone($phone), password_hash($password, PASSWORD_DEFAULT), 'user']);
    session_regenerate_id(true);
    $_SESSION['uid'] = $id;
    return ['ok' => true, 'id' => $id];
}

function auth_logout(): void {
    $_SESSION = [];
    session_destroy();
}
