<?php
/**
 * Panel Admin.
 */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/service.php';

function admin_route(string $method, string $path): void
{
    $u = require_admin();
    $route = "$method $path";

    switch ($route) {
        // ---------- Dashboard ----------
        case 'GET /admin':
            $s = [
                'users'    => (int)q_one('SELECT COUNT(*) c FROM users WHERE role="user"')['c'],
                'orders'   => (int)q_one('SELECT COUNT(*) c FROM orders')['c'],
                'active'   => (int)q_one('SELECT COUNT(*) c FROM orders WHERE status="active"')['c'],
                'revenue'  => (int)(q_one('SELECT COALESCE(SUM(amount),0) s FROM deposits WHERE status="paid"')['s']),
                'pending'  => (int)q_one('SELECT COUNT(*) c FROM deposits WHERE status="pending"')['c'],
            ];
            $recent = q_all('SELECT d.*, u.name uname FROM deposits d JOIN users u ON u.id=d.user_id
                             ORDER BY d.id DESC LIMIT 8');
            view('admin/dashboard', ['u' => $u, 's' => $s, 'recent' => $recent, 'title' => 'Admin'], 'admin/layout');
            break;

        // ---------- Produk ----------
        case 'GET /admin/products':
            $products = q_all('SELECT * FROM products ORDER BY sort,id');
            view('admin/products', ['u' => $u, 'products' => $products, 'title' => 'Produk'], 'admin/layout');
            break;

        case 'POST /admin/products/save':
            $id    = (int)input('id');
            $data  = [
                input('code'), input('name'), input('type'), (int)input('days'),
                (int)input('quota'), (int)input('iplimit'), (int)input('price'),
                (int)(bool)input('active'), (int)input('sort'), input('note'),
            ];
            if ($id) {
                q('UPDATE products SET code=?,name=?,type=?,days=?,quota=?,iplimit=?,price=?,active=?,sort=?,note=? WHERE id=?',
                    array_merge($data, [$id]));
            } else {
                q('INSERT INTO products (code,name,type,days,quota,iplimit,price,active,sort,note) VALUES (?,?,?,?,?,?,?,?,?,?)', $data);
            }
            flash('Produk disimpan.', 'success');
            redirect('admin/products');
            break;

        case 'POST /admin/products/delete':
            q('DELETE FROM products WHERE id=?', [(int)input('id')]);
            flash('Produk dihapus.', 'success');
            redirect('admin/products');
            break;

        // ---------- Pengguna ----------
        case 'GET /admin/users':
            $users = q_all('SELECT * FROM users ORDER BY id DESC');
            view('admin/users', ['u' => $u, 'users' => $users, 'title' => 'Pengguna'], 'admin/layout');
            break;

        case 'POST /admin/users/balance':
            $uid = (int)input('id');
            $amt = (int)preg_replace('/\D/', '', (string)input('amount'));
            $op  = input('op', 'add');
            $amt = ($op === 'sub') ? -abs($amt) : abs($amt);
            balance_add($uid, $amt, 'adjust', '', 'Penyesuaian admin');
            flash('Saldo diperbarui.', 'success');
            redirect('admin/users');
            break;

        case 'POST /admin/users/status':
            $uid = (int)input('id');
            $st  = input('status') === 'banned' ? 'banned' : 'active';
            q('UPDATE users SET status=? WHERE id=?', [$st, $uid]);
            flash('Status pengguna diperbarui.', 'success');
            redirect('admin/users');
            break;

        // ---------- Pesanan ----------
        case 'GET /admin/orders':
            $orders = q_all('SELECT o.*, u.name uname, u.email uemail, p.name pname
                             FROM orders o JOIN users u ON u.id=o.user_id
                             LEFT JOIN products p ON p.id=o.product_id ORDER BY o.id DESC LIMIT 500');
            view('admin/orders', ['u' => $u, 'orders' => $orders, 'title' => 'Pesanan'], 'admin/layout');
            break;

        case 'POST /admin/orders/delete':
            $o = q_one('SELECT * FROM orders WHERE id=?', [(int)input('id')]);
            if ($o && $o['username']) {
                vpn_delete($o['type'], $o['username']);
            }
            if ($o) q('DELETE FROM orders WHERE id=?', [$o['id']]);
            flash('Pesanan & akun dihapus.', 'success');
            redirect('admin/orders');
            break;

        // ---------- Deposit ----------
        case 'GET /admin/deposits':
            $rows = q_all('SELECT d.*, u.name uname, u.email uemail FROM deposits d
                           JOIN users u ON u.id=d.user_id ORDER BY d.id DESC LIMIT 500');
            view('admin/deposits', ['u' => $u, 'rows' => $rows, 'title' => 'Deposit'], 'admin/layout');
            break;

        case 'POST /admin/deposits/paid':
            $dep = q_one('SELECT * FROM deposits WHERE id=?', [(int)input('id')]);
            if ($dep) deposit_mark_paid($dep);
            flash('Deposit ditandai lunas.', 'success');
            redirect('admin/deposits');
            break;

        // ---------- Pengaturan ----------
        case 'GET /admin/settings':
            view('admin/settings', ['u' => $u, 'title' => 'Pengaturan'], 'admin/layout');
            break;

        case 'POST /admin/settings':
            foreach (['brand', 'contact_telegram', 'duitku_env', 'duitku_merchant', 'duitku_key', 'min_deposit', 'domain'] as $k) {
                if (isset($_POST[$k])) setting_set($k, trim((string)$_POST[$k]));
            }
            flash('Pengaturan disimpan.', 'success');
            redirect('admin/settings');
            break;

        default:
            http_response_code(404);
            exit('Halaman admin tidak ditemukan.');
    }
}
