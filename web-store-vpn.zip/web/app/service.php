<?php
/**
 * Logika bisnis: saldo, order, deposit.
 */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/vpn.php';

/** Tambah/kurangi saldo + catat mutasi. */
function balance_add(int $userId, int $amount, string $type, string $ref = '', string $note = ''): int
{
    $u = q_one('SELECT balance FROM users WHERE id=?', [$userId]);
    if (!$u) {
        return 0;
    }
    $new = (int)$u['balance'] + $amount;
    q('UPDATE users SET balance=? WHERE id=?', [$new, $userId]);
    q_insert('INSERT INTO mutations (user_id,type,amount,balance_after,ref,note) VALUES (?,?,?,?,?,?)',
        [$userId, $type, $amount, $new, $ref, $note]);
    return $new;
}

/** Buat username akun yang belum dipakai. */
function gen_username(string $name): string
{
    $base = strtolower(preg_replace('/[^a-z0-9]/i', '', $name));
    $base = substr($base ?: 'user', 0, 6);
    for ($i = 0; $i < 12; $i++) {
        $u = $base . random_int(100, 9999);
        if (!q_one('SELECT id FROM orders WHERE username=?', [$u])) {
            return $u;
        }
    }
    return $base . random_int(10000, 99999);
}

/** Beli produk -> buat akun VPN + potong saldo. */
function create_order(array $user, array $product): array
{
    $price = (int)$product['price'];
    if ((int)$user['balance'] < $price) {
        return ['ok' => false, 'error' => 'Saldo tidak cukup. Silakan deposit terlebih dahulu.'];
    }

    $username = gen_username($user['name']);
    $password = bin2hex(random_bytes(4));
    $days     = (int)$product['days'];
    $quota    = (int)$product['quota'];
    $iplimit  = (int)$product['iplimit'];

    $res = vpn_create($product['type'], [
        'user'    => $username,
        'pass'    => $password,
        'days'    => $days,
        'quota'   => $quota,
        'iplimit' => $iplimit,
    ]);
    if (empty($res['ok'])) {
        return ['ok' => false, 'error' => 'Gagal membuat akun: ' . ($res['error'] ?? 'unknown')];
    }

    $code   = gen_code('INV');
    $server = json_encode($res);
    $oid = q_insert(
        'INSERT INTO orders (code,user_id,product_id,type,days,quota,iplimit,price,status,username,password,uuid,expires_at,server)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [$code, $user['id'], $product['id'], $product['type'], $days, $quota, $iplimit, $price,
         'active', $username, $res['password'] ?? $password, $res['uuid'] ?? null, $res['exp'] ?? null, $server]
    );

    balance_add((int)$user['id'], -$price, 'purchase', $code, 'Pembelian ' . $product['name']);

    return ['ok' => true, 'order_id' => $oid, 'code' => $code, 'account' => $res];
}

/** Tandai deposit lunas + tambah saldo (idempotent). */
function deposit_mark_paid(array $dep, string $reference = ''): bool
{
    if ($dep['status'] === 'paid') return true; // sudah diproses

    q('UPDATE deposits SET status=?, paid_at=NOW(), reference=? WHERE id=?',
        ['paid', $reference ?: $dep['reference'], $dep['id']]);
    balance_add((int)$dep['user_id'], (int)$dep['amount'], 'deposit', $dep['code'], 'Deposit saldo');
    return true;
}

/** Ambil produk aktif. */
function products_active(): array
{
    return q_all('SELECT * FROM products WHERE active=1 ORDER BY sort,id');
}
