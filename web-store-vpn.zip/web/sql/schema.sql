-- ============================================================
--  VPN Store - Skema Database (MySQL / MariaDB)
--  Import:  mysql -u root -p vpnstore < schema.sql
-- ============================================================
SET NAMES utf8mb4;

-- ---------- Pengguna ----------
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(64)  NOT NULL,
  email         VARCHAR(128) NOT NULL UNIQUE,
  phone         VARCHAR(32)  DEFAULT NULL,
  password      VARCHAR(255) NOT NULL,
  role          ENUM('user','admin') DEFAULT 'user',
  balance       BIGINT DEFAULT 0,
  status        ENUM('active','banned') DEFAULT 'active',
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Produk ----------
CREATE TABLE IF NOT EXISTS products (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  code      VARCHAR(32)  NOT NULL UNIQUE,
  name      VARCHAR(128) NOT NULL,
  type      ENUM('ssh','vmess','vless','trojan','ss','l2tp','ovpn') NOT NULL,
  days      INT DEFAULT 30,
  quota     INT DEFAULT 0,      -- GB (0 = unlimited)
  iplimit   INT DEFAULT 0,      -- 0 = unlimited
  price     BIGINT NOT NULL,
  active    TINYINT DEFAULT 1,
  sort      INT DEFAULT 0,
  note      VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Pesanan / akun ----------
CREATE TABLE IF NOT EXISTS orders (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  code       VARCHAR(32) NOT NULL UNIQUE,
  user_id    INT NOT NULL,
  product_id INT NOT NULL,
  type       VARCHAR(16) NOT NULL,
  days       INT NOT NULL,
  quota      INT DEFAULT 0,
  iplimit    INT DEFAULT 0,
  price      BIGINT NOT NULL,
  status     ENUM('pending','active','failed','expired') DEFAULT 'pending',
  username   VARCHAR(64) DEFAULT NULL,
  password   VARCHAR(64) DEFAULT NULL,
  uuid       VARCHAR(64) DEFAULT NULL,
  expires_at DATE DEFAULT NULL,
  server     JSON DEFAULT NULL,
  note       VARCHAR(255) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_orders_user (user_id),
  INDEX idx_orders_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Deposit ----------
CREATE TABLE IF NOT EXISTS deposits (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  code        VARCHAR(32) NOT NULL UNIQUE,   -- merchantOrderId ke Duitku
  user_id     INT NOT NULL,
  amount      BIGINT NOT NULL,
  fee         BIGINT DEFAULT 0,
  total       BIGINT NOT NULL,
  method      VARCHAR(16) DEFAULT NULL,
  status      ENUM('pending','paid','failed','expired') DEFAULT 'pending',
  reference   VARCHAR(64) DEFAULT NULL,
  va_number   VARCHAR(64) DEFAULT NULL,
  qr_string   TEXT DEFAULT NULL,
  payment_url TEXT DEFAULT NULL,
  raw         MEDIUMTEXT DEFAULT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  paid_at     DATETIME DEFAULT NULL,
  INDEX idx_dep_user (user_id),
  INDEX idx_dep_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Mutasi saldo ----------
CREATE TABLE IF NOT EXISTS mutations (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  type          ENUM('deposit','purchase','refund','adjust') NOT NULL,
  amount        BIGINT NOT NULL,   -- + masuk, - keluar
  balance_after BIGINT NOT NULL,
  ref           VARCHAR(64) DEFAULT NULL,
  note          VARCHAR(255) DEFAULT NULL,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_mut_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------- Pengaturan ----------
CREATE TABLE IF NOT EXISTS settings (
  `key`   VARCHAR(64) PRIMARY KEY,
  `value` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO settings (`key`,`value`) VALUES
 ('brand','VPN Store'),
 ('domain',''),
 ('duitku_merchant',''),
 ('duitku_key',''),
 ('duitku_env','sandbox'),
 ('min_deposit','10000'),
 ('contact_telegram','');

-- ---------- Produk contoh (harga bisa diubah di admin) ----------
INSERT IGNORE INTO products (code,name,type,days,quota,iplimit,price,sort) VALUES
 ('ssh-30','SSH 30 Hari',           'ssh',   30, 0, 1, 10000, 1),
 ('ssh-7', 'SSH 7 Hari',            'ssh',    7, 0, 1,  5000, 2),
 ('ovpn-30','OpenVPN 30 Hari',      'ovpn',  30, 0, 1, 12000, 3),
 ('vmess-30','VMess 30 Hari',       'vmess', 30, 0, 1, 15000, 4),
 ('vless-30','VLESS 30 Hari',       'vless', 30, 0, 1, 15000, 5),
 ('trojan-30','Trojan 30 Hari',     'trojan',30, 0, 1, 15000, 6),
 ('ss-30','Shadowsocks 30 Hari',    'ss',    30, 0, 0, 12000, 7),
 ('l2tp-30','L2TP / IKEv2 30 Hari', 'l2tp',  30, 0, 0, 15000, 8);
