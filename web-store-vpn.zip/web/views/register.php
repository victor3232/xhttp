<div class="auth-wrap">
  <div class="card auth-card">
    <h2>Daftar</h2>
    <form method="post" action="<?= url('register') ?>">
      <?= csrf_field() ?>
      <label>Nama
        <input type="text" name="name" value="<?= e(input('name')) ?>" required autofocus>
      </label>
      <label>Email
        <input type="email" name="email" value="<?= e(input('email')) ?>" required>
      </label>
      <label>No. HP (opsional)
        <input type="text" name="phone" value="<?= e(input('phone')) ?>" placeholder="08xxxxxxxxxx">
      </label>
      <label>Password
        <input type="password" name="password" required minlength="6">
      </label>
      <button class="btn full" type="submit">Daftar</button>
    </form>
    <p class="muted center">Sudah punya akun? <a href="<?= url('login') ?>">Masuk</a></p>
  </div>
</div>
