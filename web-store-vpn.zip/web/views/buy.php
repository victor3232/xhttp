<h2 class="section-title">Beli Akun</h2>
<p class="muted">Saldo kamu: <b><?= rupiah($u['balance']) ?></b> · <a href="<?= url('deposit') ?>">Deposit dulu</a> jika kurang.</p>

<div class="grid">
  <?php foreach ($products as $p): ?>
    <div class="card product">
      <div class="product-head">
        <span class="tag"><?= e(type_label($p['type'])) ?></span>
        <h3><?= e($p['name']) ?></h3>
      </div>
      <ul class="specs">
        <li>Masa aktif <b><?= (int)$p['days'] ?> hari</b></li>
        <li>Kuota <b><?= (int)$p['quota'] > 0 ? (int)$p['quota'] . ' GB' : 'Unlimited' ?></b></li>
        <li>Limit IP <b><?= (int)$p['iplimit'] > 0 ? (int)$p['iplimit'] . ' IP' : 'Unlimited' ?></b></li>
      </ul>
      <div class="product-foot">
        <span class="price"><?= rupiah($p['price']) ?></span>
        <form method="post" action="<?= url('buy') ?>" onsubmit="return confirm('Beli <?= e($p['name']) ?> seharga <?= rupiah($p['price']) ?>?')">
          <?= csrf_field() ?>
          <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
          <button class="btn" type="submit" <?= ((int)$u['balance'] < (int)$p['price']) ? 'disabled' : '' ?>>
            <?= ((int)$u['balance'] < (int)$p['price']) ? 'Saldo Kurang' : 'Beli' ?>
          </button>
        </form>
      </div>
    </div>
  <?php endforeach; ?>
</div>
