<div class="row-between">
  <h2 class="section-title">Tagihan Deposit</h2>
  <a href="<?= url('deposits') ?>" class="btn-sm ghost">Riwayat Deposit</a>
</div>

<div class="card invoice">
  <div class="kv">
    <div><span>Kode</span><b><code><?= e($dep['code']) ?></code></b></div>
    <div><span>Nominal</span><b><?= rupiah($dep['amount']) ?></b></div>
    <div><span>Metode</span><b><?= e($dep['method']) ?></b></div>
    <div><span>Status</span><b><span class="badge <?= e($dep['status']) ?>"><?= e($dep['status']) ?></span></b></div>
  </div>

  <?php if ($dep['status'] === 'paid'): ?>
    <div class="alert alert-success">Pembayaran berhasil. Saldo sudah ditambahkan.</div>
    <a class="btn full" href="<?= url('dashboard') ?>">Ke Dashboard</a>
  <?php else: ?>
    <?php if (!empty($dep['va_number'])): ?>
      <div class="pay-box">
        <span>Nomor Virtual Account</span>
        <b class="copyable big" data-copy="<?= e($dep['va_number']) ?>"><?= e($dep['va_number']) ?></b>
        <button class="btn-sm copy" data-copy="<?= e($dep['va_number']) ?>">Copy</button>
      </div>
    <?php endif; ?>
    <?php if (!empty($dep['qr_string'])): ?>
      <div class="pay-box">
        <span>QRIS / QR String</span>
        <textarea readonly rows="3" onclick="this.select()"><?= e($dep['qr_string']) ?></textarea>
        <button class="btn-sm copy" data-copy="<?= e($dep['qr_string']) ?>">Copy</button>
      </div>
    <?php endif; ?>
    <?php if (!empty($dep['payment_url'])): ?>
      <a class="btn full" href="<?= e($dep['payment_url']) ?>" target="_blank" rel="noopener">Buka Halaman Pembayaran</a>
    <?php endif; ?>
    <p class="muted">Selesaikan pembayaran sebelum tagihan kedaluwarsa. Status akan otomatis berubah setelah dibayar.</p>
    <a class="btn ghost full" href="<?= url('invoice?code=' . urlencode($dep['code'])) ?>">🔄 Cek Status Pembayaran</a>
  <?php endif; ?>
</div>
