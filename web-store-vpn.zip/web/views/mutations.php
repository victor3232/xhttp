<h2 class="section-title">Riwayat Saldo</h2>
<div class="table-wrap">
<table>
  <thead><tr><th>Tanggal</th><th>Jenis</th><th>Jumlah</th><th>Saldo Akhir</th><th>Keterangan</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $m): ?>
    <tr>
      <td><?= e($m['created_at']) ?></td>
      <td><span class="badge"><?= e($m['type']) ?></span></td>
      <td class="<?= (int)$m['amount'] < 0 ? 'neg' : 'pos' ?>"><?= ((int)$m['amount'] < 0 ? '-' : '+') . rupiah(abs((int)$m['amount'])) ?></td>
      <td><?= rupiah($m['balance_after']) ?></td>
      <td class="muted"><?= e($m['note']) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="5" class="muted center">Belum ada mutasi.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
