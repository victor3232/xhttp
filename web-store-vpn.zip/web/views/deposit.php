<h2 class="section-title">Deposit Saldo</h2>
<p class="muted">Saldo saat ini: <b><?= rupiah($u['balance']) ?></b></p>

<div class="card">
  <form method="post" action="<?= url('deposit') ?>" class="form-grid">
    <?= csrf_field() ?>
    <label>Nominal Deposit
      <input type="number" name="amount" min="<?= (int)$min ?>" step="1000"
             value="<?= e(input('amount', $min)) ?>" required>
    </label>
    <div class="quick-amounts">
      <?php foreach ([10000, 20000, 50000, 100000, 200000] as $a): ?>
        <button type="button" class="chip" data-amount="<?= $a ?>"><?= rupiah($a) ?></button>
      <?php endforeach; ?>
    </div>

    <label>Metode Pembayaran
      <select name="method" required>
        <?php foreach ($methods as $m): ?>
          <option value="<?= e($m['code']) ?>"><?= e($m['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </label>

    <p class="muted">Minimal deposit <?= rupiah($min) ?>. Saldo masuk otomatis setelah pembayaran terkonfirmasi.</p>
    <button class="btn full" type="submit">Buat Tagihan</button>
  </form>
</div>
