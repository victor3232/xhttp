<?php /** Layout admin */ ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'Admin') ?> — <?= e(setting('brand', 'VPN Store')) ?></title>
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body>
<header class="nav">
  <div class="nav-inner">
    <a class="brand" href="<?= url('admin') ?>">🛠 Admin · <?= e(setting('brand', 'VPN Store')) ?></a>
    <nav class="nav-links">
      <a href="<?= url('/') ?>">Lihat Toko</a>
      <a href="<?= url('logout') ?>" class="btn-sm ghost">Keluar</a>
    </nav>
  </div>
</header>

<div class="admin-shell">
  <aside class="sidebar">
    <a href="<?= url('admin') ?>">📊 Dashboard</a>
    <a href="<?= url('admin/products') ?>">📦 Produk</a>
    <a href="<?= url('admin/users') ?>">👥 Pengguna</a>
    <a href="<?= url('admin/orders') ?>">🧾 Pesanan</a>
    <a href="<?= url('admin/deposits') ?>">💰 Deposit</a>
    <a href="<?= url('admin/settings') ?>">⚙️ Pengaturan</a>
  </aside>
  <main class="admin-main">
    <?php if ($f = flash()): ?>
      <div class="alert alert-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
    <?php endif; ?>
    <?= $content ?>
  </main>
</div>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>
