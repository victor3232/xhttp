<h2 class="section-title">Deposit</h2>
<div class="table-wrap">
<table>
  <thead><tr><th>Kode</th><th>User</th><th>Nominal</th><th>Metode</th><th>Status</th><th>Ref</th><th>Dibuat</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $d): ?>
    <tr>
      <td><code><?= e($d['code']) ?></code></td>
      <td><?= e($d['uname']) ?><br><span class="muted"><?= e($d['uemail']) ?></span></td>
      <td><?= rupiah($d['amount']) ?></td>
      <td><?= e($d['method']) ?></td>
      <td><span class="badge <?= e($d['status']) ?>"><?= e($d['status']) ?></span></td>
      <td class="muted"><?= e($d['reference']) ?></td>
      <td><?= e($d['created_at']) ?></td>
      <td>
        <?php if ($d['status'] !== 'paid'): ?>
        <form method="post" action="<?= url('admin/deposits/paid') ?>" onsubmit="return confirm('Tandai deposit ini lunas & tambah saldo user?')">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
          <button class="btn-sm" type="submit">Tandai Lunas</button>
        </form>
        <?php else: ?>✅<?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="8" class="muted center">Belum ada deposit.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
