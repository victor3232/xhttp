<h2 class="section-title">Dashboard</h2>
<div class="stats">
  <div class="card stat"><span class="stat-label">Pengguna</span><span class="stat-value"><?= $s['users'] ?></span></div>
  <div class="card stat"><span class="stat-label">Total Pesanan</span><span class="stat-value"><?= $s['orders'] ?></span></div>
  <div class="card stat"><span class="stat-label">Akun Aktif</span><span class="stat-value"><?= $s['active'] ?></span></div>
  <div class="card stat"><span class="stat-label">Total Deposit (paid)</span><span class="stat-value"><?= rupiah($s['revenue']) ?></span></div>
  <div class="card stat"><span class="stat-label">Deposit Pending</span><span class="stat-value"><?= $s['pending'] ?></span></div>
</div>

<h3>Deposit Terbaru</h3>
<div class="table-wrap">
<table>
  <thead><tr><th>Kode</th><th>User</th><th>Nominal</th><th>Status</th><th>Tanggal</th></tr></thead>
  <tbody>
  <?php foreach ($recent as $d): ?>
    <tr>
      <td><code><?= e($d['code']) ?></code></td>
      <td><?= e($d['uname']) ?></td>
      <td><?= rupiah($d['amount']) ?></td>
      <td><span class="badge <?= e($d['status']) ?>"><?= e($d['status']) ?></span></td>
      <td><?= e($d['created_at']) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$recent): ?><tr><td colspan="5" class="muted center">Belum ada data.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
