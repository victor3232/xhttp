<h2 class="section-title">Pengguna</h2>
<div class="table-wrap">
<table>
  <thead><tr><th>ID</th><th>Nama</th><th>Email</th><th>HP</th><th>Saldo</th><th>Role</th><th>Status</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($users as $x): ?>
    <tr>
      <td><?= (int)$x['id'] ?></td>
      <td><?= e($x['name']) ?></td>
      <td><?= e($x['email']) ?></td>
      <td><?= e($x['phone']) ?></td>
      <td><?= rupiah($x['balance']) ?></td>
      <td><?= e($x['role']) ?></td>
      <td><span class="badge <?= $x['status'] === 'active' ? 'active' : 'failed' ?>"><?= e($x['status']) ?></span></td>
      <td class="nowrap">
        <form method="post" action="<?= url('admin/users/balance') ?>" class="inline-form">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
          <select name="op"><option value="add">+</option><option value="sub">-</option></select>
          <input type="number" name="amount" value="10000" style="width:100px">
          <button class="btn-sm" type="submit">Set</button>
        </form>
        <form method="post" action="<?= url('admin/users/status') ?>" style="display:inline">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
          <input type="hidden" name="status" value="<?= $x['status'] === 'active' ? 'banned' : 'active' ?>">
          <button class="btn-sm <?= $x['status'] === 'active' ? 'danger' : '' ?>" type="submit">
            <?= $x['status'] === 'active' ? 'Ban' : 'Unban' ?>
          </button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
