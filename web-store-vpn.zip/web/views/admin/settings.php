<h2 class="section-title">Pengaturan</h2>
<div class="card">
  <form method="post" action="<?= url('admin/settings') ?>" class="form-grid two">
    <?= csrf_field() ?>
    <label>Nama Brand <input name="brand" value="<?= e(setting('brand')) ?>"></label>
    <label>Telegram Admin <input name="contact_telegram" value="<?= e(setting('contact_telegram')) ?>" placeholder="@username"></label>
    <label>Minimal Deposit <input type="number" name="min_deposit" value="<?= e(setting('min_deposit')) ?>"></label>
    <label>Domain Panel <input name="domain" value="<?= e(setting('domain')) ?>" placeholder="panel.domain.com"></label>
    <label>Duitku Environment
      <select name="duitku_env">
        <option value="sandbox" <?= setting('duitku_env') === 'sandbox' ? 'selected' : '' ?>>Sandbox</option>
        <option value="production" <?= setting('duitku_env') === 'production' ? 'selected' : '' ?>>Production</option>
      </select>
    </label>
    <label>Duitku Merchant Code <input name="duitku_merchant" value="<?= e(setting('duitku_merchant')) ?>"></label>
    <label>Duitku API Key <input name="duitku_key" value="<?= e(setting('duitku_key')) ?>"></label>
    <div class="form-actions"><button class="btn" type="submit">Simpan Pengaturan</button></div>
  </form>
  <p class="muted">Callback URL untuk Duitku: <code><?= e(url('callback')) ?></code><br>
     Return URL: <code><?= e(url('pay/return')) ?></code></p>
</div>
