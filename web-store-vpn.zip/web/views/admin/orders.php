<h2 class="section-title">Pesanan</h2>
<div class="table-wrap">
<table>
  <thead><tr><th>Kode</th><th>User</th><th>Produk</th><th>Akun</th><th>Harga</th><th>Status</th><th>Berakhir</th><th>Aksi</th></tr></thead>
  <tbody>
  <?php foreach ($orders as $o): ?>
    <tr>
      <td><code><?= e($o['code']) ?></code></td>
      <td><?= e($o['uname']) ?><br><span class="muted"><?= e($o['uemail']) ?></span></td>
      <td><?= e($o['pname'] ?? type_label($o['type'])) ?></td>
      <td><code><?= e($o['username']) ?></code><br><span class="muted"><?= e($o['password']) ?></span></td>
      <td><?= rupiah($o['price']) ?></td>
      <td><span class="badge <?= e($o['status']) ?>"><?= e($o['status']) ?></span></td>
      <td><?= e($o['expires_at']) ?></td>
      <td>
        <form method="post" action="<?= url('admin/orders/delete') ?>" onsubmit="return confirm('Hapus pesanan & akun ini dari server?')">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
          <button class="btn-sm danger" type="submit">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$orders): ?><tr><td colspan="8" class="muted center">Belum ada pesanan.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
