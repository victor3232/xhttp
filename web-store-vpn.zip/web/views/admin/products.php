<h2 class="section-title">Produk</h2>

<div class="card">
  <h3>Tambah / Edit Produk</h3>
  <form method="post" action="<?= url('admin/products/save') ?>" class="form-grid two">
    <?= csrf_field() ?>
    <input type="hidden" name="id" id="p_id">
    <label>Kode <input name="code" id="p_code" required placeholder="vmess-30"></label>
    <label>Nama <input name="name" id="p_name" required placeholder="VMess 30 Hari"></label>
    <label>Tipe
      <select name="type" id="p_type">
        <?php foreach (['ssh','ovpn','vmess','vless','trojan','ss','l2tp'] as $t): ?>
          <option value="<?= $t ?>"><?= e(type_label($t)) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Hari <input type="number" name="days" id="p_days" value="30" min="1"></label>
    <label>Kuota GB (0=unlimited) <input type="number" name="quota" id="p_quota" value="0" min="0"></label>
    <label>Limit IP (0=unlimited) <input type="number" name="iplimit" id="p_iplimit" value="0" min="0"></label>
    <label>Harga <input type="number" name="price" id="p_price" value="10000" min="0"></label>
    <label>Urutan <input type="number" name="sort" id="p_sort" value="0"></label>
    <label>Status
      <select name="active" id="p_active"><option value="1">Aktif</option><option value="0">Nonaktif</option></select>
    </label>
    <label>Catatan <input name="note" id="p_note"></label>
    <div class="form-actions"><button class="btn" type="submit">Simpan</button>
      <button class="btn ghost" type="reset" onclick="document.getElementById('p_id').value=''">Reset</button></div>
  </form>
</div>

<div class="table-wrap">
<table>
  <thead><tr><th>Kode</th><th>Nama</th><th>Tipe</th><th>Hari</th><th>Kuota</th><th>IP</th><th>Harga</th><th>Aktif</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($products as $p): ?>
    <tr>
      <td><code><?= e($p['code']) ?></code></td>
      <td><?= e($p['name']) ?></td>
      <td><?= e(type_label($p['type'])) ?></td>
      <td><?= (int)$p['days'] ?></td>
      <td><?= (int)$p['quota'] ?></td>
      <td><?= (int)$p['iplimit'] ?></td>
      <td><?= rupiah($p['price']) ?></td>
      <td><?= (int)$p['active'] ? '✅' : '❌' ?></td>
      <td class="nowrap">
        <button class="btn-sm" onclick='editProduct(<?= e(json_encode($p)) ?>)'>Edit</button>
        <form method="post" action="<?= url('admin/products/delete') ?>" style="display:inline"
              onsubmit="return confirm('Hapus produk ini?')">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
          <button class="btn-sm danger" type="submit">Hapus</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>

<script>
function editProduct(p){
  const f=id=>document.getElementById(id);
  f('p_id').value=p.id; f('p_code').value=p.code; f('p_name').value=p.name;
  f('p_type').value=p.type; f('p_days').value=p.days; f('p_quota').value=p.quota;
  f('p_iplimit').value=p.iplimit; f('p_price').value=p.price; f('p_sort').value=p.sort;
  f('p_active').value=p.active; f('p_note').value=p.note||'';
  window.scrollTo({top:0,behavior:'smooth'});
}
</script>
