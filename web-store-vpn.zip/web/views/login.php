<div class="auth-wrap">
  <div class="card auth-card">
    <h2>Masuk</h2>
    <form method="post" action="<?= url('login') ?>">
      <?= csrf_field() ?>
      <label>Email
        <input type="email" name="email" value="<?= e(input('email')) ?>" required autofocus>
      </label>
      <label>Password
        <input type="password" name="password" required>
      </label>
      <button class="btn full" type="submit">Masuk</button>
    </form>
    <p class="muted center">Belum punya akun? <a href="<?= url('register') ?>">Daftar</a></p>
  </div>
</div>
