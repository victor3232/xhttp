<?php /** Layout utama */ ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? '') ?> — <?= e(setting('brand', 'VPN Store')) ?></title>
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body>
<header class="nav">
  <div class="nav-inner">
    <a class="brand" href="<?= url('/') ?>">⚡ <?= e(setting('brand', 'VPN Store')) ?></a>
    <nav class="nav-links">
      <?php if (is_logged_in()): $cu = current_user(); ?>
        <a href="<?= url('dashboard') ?>">Dashboard</a>
        <a href="<?= url('buy') ?>">Beli Akun</a>
        <a href="<?= url('orders') ?>">Pesanan</a>
        <a href="<?= url('deposits') ?>">Deposit</a>
        <?php if (is_admin()): ?><a href="<?= url('admin') ?>" class="accent">Admin</a><?php endif; ?>
        <span class="balance"><?= rupiah($cu['balance']) ?></span>
        <a href="<?= url('logout') ?>" class="btn-sm ghost">Keluar</a>
      <?php else: ?>
        <a href="<?= url('login') ?>">Masuk</a>
        <a href="<?= url('register') ?>" class="btn-sm">Daftar</a>
      <?php endif; ?>
    </nav>
  </div>
</header>

<main class="container">
  <?php if ($f = flash()): ?>
    <div class="alert alert-<?= e($f['type']) ?>"><?= e($f['msg']) ?></div>
  <?php endif; ?>
  <?= $content ?>
</main>

<footer class="footer">
  <div class="container">
    <p>&copy; <?= date('Y') ?> <?= e(setting('brand', 'VPN Store')) ?>.
    <?php $tg = setting('contact_telegram'); if ($tg): ?>
      · <a href="https://t.me/<?= e(ltrim($tg, '@')) ?>" target="_blank">Telegram</a>
    <?php endif; ?>
    </p>
  </div>
</footer>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>
