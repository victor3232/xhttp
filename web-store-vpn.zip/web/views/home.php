<section class="hero">
  <h1>Internet Cepat &amp; Aman</h1>
  <p>Beli akun VPN (SSH, VMess, VLESS, Trojan, Shadowsocks, L2TP) — aktif otomatis, bayar pakai QRIS / Virtual Account / e-wallet.</p>
  <div class="hero-actions">
    <a href="<?= url('register') ?>" class="btn">Mulai Sekarang</a>
    <a href="#produk" class="btn ghost">Lihat Harga</a>
  </div>
</section>

<h2 id="produk" class="section-title">Daftar Produk</h2>
<div class="grid">
  <?php foreach ($products as $p): ?>
    <div class="card product">
      <div class="product-head">
        <span class="tag"><?= e(type_label($p['type'])) ?></span>
        <h3><?= e($p['name']) ?></h3>
      </div>
      <ul class="specs">
        <li>Masa aktif <b><?= (int)$p['days'] ?> hari</b></li>
        <li>Kuota <b><?= (int)$p['quota'] > 0 ? (int)$p['quota'] . ' GB' : 'Unlimited' ?></b></li>
        <li>Limit IP <b><?= (int)$p['iplimit'] > 0 ? (int)$p['iplimit'] . ' IP' : 'Unlimited' ?></b></li>
      </ul>
      <div class="product-foot">
        <span class="price"><?= rupiah($p['price']) ?></span>
        <a class="btn" href="<?= url('buy') ?>">Beli</a>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (!$products): ?><p class="muted">Belum ada produk.</p><?php endif; ?>
</div>

<section class="features">
  <div class="card"><h4>⚡ Aktif Otomatis</h4><p>Akun langsung dibuat begitu pembelian berhasil.</p></div>
  <div class="card"><h4>🔒 Pembayaran Aman</h4><p>Diproses oleh Duitku (QRIS, VA, e-wallet, retail).</p></div>
  <div class="card"><h4>📱 Multi Platform</h4><p>Support semua aplikasi tunnel populer.</p></div>
</section>
