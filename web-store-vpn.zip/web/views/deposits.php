<h2 class="section-title">Riwayat Deposit</h2>
<div class="table-wrap">
<table>
  <thead><tr><th>Kode</th><th>Nominal</th><th>Metode</th><th>Status</th><th>Tanggal</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $d): ?>
    <tr>
      <td><code><?= e($d['code']) ?></code></td>
      <td><?= rupiah($d['amount']) ?></td>
      <td><?= e($d['method']) ?></td>
      <td><span class="badge <?= e($d['status']) ?>"><?= e($d['status']) ?></span></td>
      <td><?= e($d['created_at']) ?></td>
      <td><?php if ($d['status'] === 'pending'): ?><a href="<?= url('invoice?code=' . urlencode($d['code'])) ?>">Bayar</a><?php endif; ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="6" class="muted center">Belum ada deposit. <a href="<?= url('deposit') ?>">Deposit sekarang</a>.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
