<div class="row-between">
  <h2 class="section-title">Detail Pesanan</h2>
  <a href="<?= url('orders') ?>" class="btn-sm ghost">← Kembali</a>
</div>

<div class="card">
  <div class="kv">
    <div><span>Kode</span><b><code><?= e($o['code']) ?></code></b></div>
    <div><span>Produk</span><b><?= e($o['pname'] ?? type_label($o['type'])) ?></b></div>
    <div><span>Status</span><b><span class="badge <?= e($o['status']) ?>"><?= e($o['status']) ?></span></b></div>
    <div><span>Berakhir</span><b><?= e($o['expires_at']) ?></b></div>
  </div>
</div>

<h3>Informasi Akun</h3>
<div class="card">
  <div class="kv">
    <?php foreach ($details['info'] as $k => $v): ?>
      <div><span><?= e($k) ?></span><b class="copyable" data-copy="<?= e($v) ?>"><?= e($v) ?></b></div>
    <?php endforeach; ?>
  </div>
</div>

<?php if (!empty($details['links'])): ?>
<h3>Link / Config</h3>
<div class="card">
  <?php foreach ($details['links'] as $l): ?>
    <div class="link-row">
      <div class="link-label"><?= e($l['label']) ?></div>
      <div class="link-value">
        <input type="text" readonly value="<?= e($l['value']) ?>" onclick="this.select()">
        <button class="btn-sm copy" data-copy="<?= e($l['value']) ?>">Copy</button>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($o['type'] === 'ovpn' || $o['type'] === 'ssh'): ?>
<p class="muted">Tip: akun SSH bisa juga dipakai untuk OpenVPN (login pakai username &amp; password yang sama).</p>
<?php endif; ?>
