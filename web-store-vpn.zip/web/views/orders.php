<h2 class="section-title">Pesanan Saya</h2>
<div class="table-wrap">
<table>
  <thead><tr><th>Kode</th><th>Produk</th><th>Akun</th><th>Harga</th><th>Status</th><th>Berakhir</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($orders as $o): ?>
    <tr>
      <td><code><?= e($o['code']) ?></code></td>
      <td><?= e($o['pname'] ?? type_label($o['type'])) ?></td>
      <td><code><?= e($o['username']) ?></code></td>
      <td><?= rupiah($o['price']) ?></td>
      <td><span class="badge <?= e($o['status']) ?>"><?= e($o['status']) ?></span></td>
      <td><?= e($o['expires_at']) ?></td>
      <td><a href="<?= url('order?code=' . urlencode($o['code'])) ?>">Detail</a></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$orders): ?><tr><td colspan="7" class="muted center">Belum ada pesanan. <a href="<?= url('buy') ?>">Beli sekarang</a>.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
