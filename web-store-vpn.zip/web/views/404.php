<div class="auth-wrap">
  <div class="card center">
    <h1>404</h1>
    <p class="muted">Halaman yang kamu cari tidak ditemukan.</p>
    <a class="btn" href="<?= url('/') ?>">Kembali ke Beranda</a>
  </div>
</div>
