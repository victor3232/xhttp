<h2 class="section-title">Halo, <?= e($u['name']) ?> 👋</h2>

<div class="stats">
  <div class="card stat"><span class="stat-label">Saldo</span><span class="stat-value"><?= rupiah($u['balance']) ?></span>
    <a href="<?= url('deposit') ?>" class="btn-sm">Deposit</a></div>
  <div class="card stat"><span class="stat-label">Total Pesanan</span><span class="stat-value"><?= $stats['orders'] ?></span></div>
  <div class="card stat"><span class="stat-label">Akun Aktif</span><span class="stat-value"><?= $stats['active'] ?></span></div>
  <div class="card stat"><span class="stat-label">Deposit Sukses</span><span class="stat-value"><?= $stats['deposits'] ?></span></div>
</div>

<div class="row-between">
  <h3>Pesanan Terakhir</h3>
  <a href="<?= url('buy') ?>" class="btn">+ Beli Akun</a>
</div>
<div class="table-wrap">
<table>
  <thead><tr><th>Kode</th><th>Produk</th><th>Akun</th><th>Status</th><th>Berakhir</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($orders as $o): ?>
    <tr>
      <td><code><?= e($o['code']) ?></code></td>
      <td><?= e($o['pname'] ?? type_label($o['type'])) ?></td>
      <td><code><?= e($o['username']) ?></code></td>
      <td><span class="badge <?= e($o['status']) ?>"><?= e($o['status']) ?></span></td>
      <td><?= e($o['expires_at']) ?></td>
      <td><a href="<?= url('order?code=' . urlencode($o['code'])) ?>">Detail</a></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$orders): ?><tr><td colspan="6" class="muted center">Belum ada pesanan.</td></tr><?php endif; ?>
  </tbody>
</table>
</div>
