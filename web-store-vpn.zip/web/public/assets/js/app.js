// VPN Store - interaksi kecil (copy & quick amount)
document.addEventListener('click', function (e) {
  var el = e.target.closest('[data-copy]');
  if (el) {
    var val = el.getAttribute('data-copy');
    navigator.clipboard.writeText(val).then(function () {
      var old = el.textContent;
      el.textContent = 'Tersalin!';
      setTimeout(function () { el.textContent = old; }, 1200);
    }).catch(function () {
      // fallback
      var t = document.createElement('textarea');
      t.value = val; document.body.appendChild(t); t.select();
      try { document.execCommand('copy'); } catch (err) {}
      document.body.removeChild(t);
    });
  }

  var chip = e.target.closest('[data-amount]');
  if (chip) {
    var inp = document.querySelector('input[name="amount"]');
    if (inp) inp.value = chip.getAttribute('data-amount');
  }
});
