<?php
/**
 * VPN Store - Front Controller / Router
 */
require_once __DIR__ . '/../app/helpers.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/duitku.php';
require_once __DIR__ . '/../app/vpn.php';
require_once __DIR__ . '/../app/service.php';

// ---------- Routing dasar ----------
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
if ($base && $base !== '/' && strpos($path, $base) === 0) {
    $path = substr($path, strlen($base));
}
$path   = '/' . trim($path, '/');
$method = $_SERVER['REQUEST_METHOD'];

// CSRF untuk semua POST kecuali callback Duitku
if ($method === 'POST' && $path !== '/callback') {
    csrf_check();
}

$route = "$method $path";

// ============================================================
//  Halaman publik
// ============================================================

function page_home(): void
{
    view('home', [
        'products' => products_active(),
        'title'    => 'Beranda',
    ]);
}

function page_login(): void
{
    if (is_logged_in()) redirect('dashboard');
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $r = auth_login(input('email'), (string)($_POST['password'] ?? ''));
        if ($r['ok']) redirect('dashboard');
        flash($r['error'], 'error');
    }
    view('login', ['title' => 'Masuk']);
}

function page_register(): void
{
    if (is_logged_in()) redirect('dashboard');
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $r = auth_register(input('name'), input('email'), (string)($_POST['password'] ?? ''), input('phone'));
        if ($r['ok']) { flash('Pendaftaran berhasil. Selamat datang!', 'success'); redirect('dashboard'); }
        flash($r['error'], 'error');
    }
    view('register', ['title' => 'Daftar']);
}

function page_dashboard(): void
{
    $u = require_login();
    $stats = [
        'orders'   => (int)q_one('SELECT COUNT(*) c FROM orders WHERE user_id=?', [$u['id']])['c'],
        'active'   => (int)q_one("SELECT COUNT(*) c FROM orders WHERE user_id=? AND status='active'", [$u['id']])['c'],
        'deposits' => (int)q_one("SELECT COUNT(*) c FROM deposits WHERE user_id=? AND status='paid'", [$u['id']])['c'],
    ];
    $orders = q_all('SELECT o.*, p.name pname FROM orders o LEFT JOIN products p ON p.id=o.product_id
                     WHERE o.user_id=? ORDER BY o.id DESC LIMIT 5', [$u['id']]);
    view('dashboard', compact('u', 'stats', 'orders') + ['title' => 'Dashboard']);
}

function page_buy(): void
{
    $u = require_login();
    $products = products_active();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $pid = (int)input('product_id');
        $p = q_one('SELECT * FROM products WHERE id=? AND active=1', [$pid]);
        if (!$p) { flash('Produk tidak ditemukan.', 'error'); redirect('buy'); }
        $r = create_order($u, $p);
        if (!$r['ok']) { flash($r['error'], 'error'); redirect('buy'); }
        flash('Akun berhasil dibuat! Detail akun bisa dilihat di halaman pesanan.', 'success');
        redirect('order?code=' . urlencode($r['code']));
    }

    view('buy', ['u' => $u, 'products' => $products, 'title' => 'Beli Akun']);
}

function page_orders(): void
{
    $u = require_login();
    $orders = q_all('SELECT o.*, p.name pname FROM orders o LEFT JOIN products p ON p.id=o.product_id
                     WHERE o.user_id=? ORDER BY o.id DESC', [$u['id']]);
    view('orders', ['u' => $u, 'orders' => $orders, 'title' => 'Pesanan Saya']);
}

function page_order(): void
{
    $u = require_login();
    $code = input('code');
    $o = q_one('SELECT o.*, p.name pname FROM orders o LEFT JOIN products p ON p.id=o.product_id
                WHERE o.code=? AND o.user_id=?', [$code, $u['id']]);
    if (!$o) { http_response_code(404); exit('Pesanan tidak ditemukan.'); }
    $acc = json_decode($o['server'] ?? '{}', true) ?: [];
    $acc['username'] = $o['username'];
    $acc['password'] = $o['password'];
    $acc['uuid']     = $o['uuid'];
    $details = vpn_links($o['type'], $acc);
    view('order', ['u' => $u, 'o' => $o, 'details' => $details, 'title' => 'Detail Pesanan']);
}

function page_deposit(): void
{
    $u = require_login();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $amount = (int)preg_replace('/\D/', '', (string)input('amount'));
        $method = input('method');
        $min    = (int)setting('min_deposit', 10000);
        if ($amount < $min) { flash('Minimal deposit ' . rupiah($min) . '.', 'error'); redirect('deposit'); }

        $d = new Duitku();
        if (!$d->configured()) {
            flash('Payment gateway belum dikonfigurasi. Hubungi admin.', 'error');
            redirect('deposit');
        }

        $code = gen_code('DEP');
        $inv  = $d->createInvoice([
            'order_id'     => $code,
            'amount'       => $amount,
            'method'       => $method,
            'product'      => 'Deposit Saldo ' . setting('brand', 'VPN Store'),
            'name'         => $u['name'],
            'email'        => $u['email'],
            'phone'        => $u['phone'] ?? '',
            'callback_url' => url('callback'),
            'return_url'   => url('pay/return?code=' . $code),
        ]);

        if (!empty($inv['_error']) || empty($inv['reference'])) {
            flash('Gagal membuat tagihan: ' . ($inv['_error'] ?? ($inv['statusMessage'] ?? 'unknown')), 'error');
            redirect('deposit');
        }

        q_insert('INSERT INTO deposits (code,user_id,amount,fee,total,method,status,reference,va_number,qr_string,payment_url,raw)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
            [$code, $u['id'], $amount, 0, $amount, $method, 'pending',
             $inv['reference'] ?? '', $inv['vaNumber'] ?? '', $inv['qrString'] ?? '', $inv['paymentUrl'] ?? '',
             json_encode($inv)]);

        redirect('invoice?code=' . urlencode($code));
    }

    view('deposit', [
        'u'        => $u,
        'methods'  => Duitku::fallbackMethods(),
        'min'      => (int)setting('min_deposit', 10000),
        'title'    => 'Deposit Saldo',
    ]);
}

function page_invoice(): void
{
    $u = require_login();
    $code = input('code');
    $dep = q_one('SELECT * FROM deposits WHERE code=? AND user_id=?', [$code, $u['id']]);
    if (!$dep) { http_response_code(404); exit('Tagihan tidak ditemukan.'); }

    // Cek status ke Duitku bila masih pending (untuk jaga-jaga callback telat)
    if ($dep['status'] === 'pending') {
        $d = new Duitku();
        if ($d->configured()) {
            $st = $d->transactionStatus($dep['code']);
            if (($st['statusCode'] ?? '') === '00' || ($st['resultCode'] ?? '') === '00') {
                deposit_mark_paid($dep, $st['reference'] ?? '');
                $dep['status'] = 'paid';
            }
        }
    }
    view('invoice', ['u' => $u, 'dep' => $dep, 'title' => 'Tagihan Deposit']);
}

function page_deposits(): void
{
    $u = require_login();
    $rows = q_all('SELECT * FROM deposits WHERE user_id=? ORDER BY id DESC', [$u['id']]);
    view('deposits', ['u' => $u, 'rows' => $rows, 'title' => 'Riwayat Deposit']);
}

function page_mutations(): void
{
    $u = require_login();
    $rows = q_all('SELECT * FROM mutations WHERE user_id=? ORDER BY id DESC LIMIT 200', [$u['id']]);
    view('mutations', ['u' => $u, 'rows' => $rows, 'title' => 'Riwayat Saldo']);
}

/** Callback dari Duitku (POST, tanpa login). */
function page_callback(): void
{
    header('Content-Type: text/plain');
    $post = $_POST ?: json_decode(file_get_contents('php://input'), true) ?: [];
    $d = new Duitku();
    if (!$d->verifyCallback($post)) {
        http_response_code(400);
        echo 'Bad signature';
        return;
    }
    $dep = q_one('SELECT * FROM deposits WHERE code=?', [$post['merchantOrderId'] ?? '']);
    if (!$dep) { http_response_code(404); echo 'Not found'; return; }

    if (duitku_is_success((string)($post['resultCode'] ?? ''))) {
        deposit_mark_paid($dep, $post['reference'] ?? '');
    } else {
        q('UPDATE deposits SET status=? WHERE id=? AND status=?', ['failed', $dep['id'], 'pending']);
    }
    echo 'OK';
}

/** Return URL dari Duitku (user kembali dari halaman bayar). */
function page_return(): void
{
    $u = require_login();
    $code = input('code');
    $dep = q_one('SELECT * FROM deposits WHERE code=? AND user_id=?', [$code, $u['id']]);
    if ($dep && $dep['status'] === 'pending') {
        $d = new Duitku();
        if ($d->configured()) {
            $st = $d->transactionStatus($code);
            if (($st['statusCode'] ?? '') === '00' || ($st['resultCode'] ?? '') === '00') {
                deposit_mark_paid($dep, $st['reference'] ?? '');
                flash('Deposit berhasil. Saldo sudah ditambahkan.', 'success');
            } else {
                flash('Pembayaran belum terkonfirmasi. Silakan cek riwayat deposit.', 'info');
            }
        }
    }
    redirect('deposits');
}

// ============================================================
//  Dispatch
// ============================================================
switch ($route) {
    case 'GET /':            page_home(); break;
    case 'GET /login':       page_login(); break;
    case 'POST /login':      page_login(); break;
    case 'GET /register':    page_register(); break;
    case 'POST /register':   page_register(); break;
    case 'GET /logout':      auth_logout(); redirect('/'); break;
    case 'GET /dashboard':   page_dashboard(); break;
    case 'GET /buy':         page_buy(); break;
    case 'POST /buy':        page_buy(); break;
    case 'GET /orders':      page_orders(); break;
    case 'GET /order':       page_order(); break;
    case 'GET /deposit':     page_deposit(); break;
    case 'POST /deposit':    page_deposit(); break;
    case 'GET /invoice':     page_invoice(); break;
    case 'GET /deposits':    page_deposits(); break;
    case 'GET /mutations':   page_mutations(); break;
    case 'POST /callback':   page_callback(); break;
    case 'GET /pay/return':  page_return(); break;
    default:
        if (strpos($path, '/admin') === 0) {
            require __DIR__ . '/../app/admin.php';
            admin_route($method, $path);
        } else {
            http_response_code(404);
            view('404', ['title' => 'Tidak ditemukan']);
        }
}
